package th.donut;

import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.block.Sign;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.sign.Side;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.SignChangeEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DonutSMP extends JavaPlugin implements Listener, TabExecutor {


    static class Gui implements InventoryHolder {
        final String type;
        Inventory inv;
        int page;
        List<Order> orders = new ArrayList<>();
        List<Listing> shown = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<Material> mats = new ArrayList<>();
        SpawnerData sp;
        Order ord;
        String filter;
        List<Integer> counts = new ArrayList<>();
        List<UUID> uuids = new ArrayList<>();
        List<List<ItemStack>> goods = new ArrayList<>();
        List<Long> prices = new ArrayList<>();
        Map<Integer, Integer> slotIdx = new HashMap<>();
        Gui(String type) { this.type = type; }
        @Override public Inventory getInventory() { return inv; }
    }

    static class Order {
        final int id; final UUID owner; final Material mat; int left; int delivered; final double price;
        Order(int id, UUID owner, Material mat, int left, double price) {
            this.id = id; this.owner = owner; this.mat = mat; this.left = left; this.price = price;
        }
    }

    static class Listing {
        final int id; final UUID seller; final ItemStack item; final double price; final long time;
        Listing(int id, UUID seller, ItemStack item, double price, long time) {
            this.id = id; this.seller = seller; this.item = item; this.price = price; this.time = time;
        }
    }

    static class TpaReq {
        final UUID from; final boolean here; final long expire;
        TpaReq(UUID from, boolean here, long expire) { this.from = from; this.here = here; this.expire = expire; }
    }

    static class SpawnerData {
        final String id, world; final UUID owner; final EntityType type; final int x, y, z;
        int stack = 1; long xp = 0;
        final Map<Material, Long> items = new HashMap<>();
        final Set<Material> disabled = new HashSet<>();
        SpawnerData(UUID owner, EntityType type, String world, int x, int y, int z) {
            this.owner = owner; this.type = type; this.world = world; this.x = x; this.y = y; this.z = z;
            this.id = world + ":" + x + "," + y + "," + z;
        }
    }

    private final Map<String, SpawnerData> spawners = new HashMap<>();
    private final Map<UUID, Double> money = new HashMap<>();
    private final Map<UUID, Long> shards = new HashMap<>();
    private final Map<UUID, Double> bounties = new HashMap<>();   // /dounty: target -> total bounty on their head
    private final Map<UUID, Long> playSeconds = new HashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, Map<String, Integer>> claims = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Map<UUID, TpaReq> tpaReqs = new HashMap<>();
    private final Map<UUID, String> teamInvites = new HashMap<>();
    private int nextOrderId = 1;
    private int nextListingId = 1;
    private final Map<UUID, Long> mined = new HashMap<>();
    private final Map<UUID, Long> placed = new HashMap<>();
    private final Map<UUID, Integer> orderSort = new HashMap<>();
    private final Map<UUID, String> orderSearch = new HashMap<>();
    private final LinkedHashSet<UUID> rtpQueue = new LinkedHashSet<>();
    private File dataFile;
    private YamlConfiguration data;


    @Override
    public void onEnable() {

        File cf = new File(getDataFolder(), "config.yml");
        if (cf.exists() && YamlConfiguration.loadConfiguration(cf).getInt("config-version", 1) < 30) {
            File old = new File(getDataFolder(), "config-old.yml");
            if (old.exists()) old.delete();
            cf.renameTo(old);
        }
        saveDefaultConfig();
        loadData();
        loadKnownNames();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("shop", "sell", "order", "ah", "rtp", "sethome", "home", "delhome",
                "balance", "pay", "tpa", "tphere", "tpaccept", "tpdeny", "tpauto", "settings", "nv", "team", "eco", "rules", "spawner", "shardshop", "shards", "help-smp", "givera", "fly", "gmst", "gmse", "offend", "unoffend", "settingmn", "settingall", "sus", "afk", "tpgui", "rtpq", "baltop", "stats", "dounty")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
        long siv = Math.max(1, getConfig().getLong("spawner.interval-seconds", 10)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, this::produceAll, siv, siv);
        Bukkit.getOnlinePlayers().forEach(this::setupBoard);
        Bukkit.getOnlinePlayers().forEach(this::refreshStaffPerms);
    }

    @Override
    public void onDisable() {
        for (UUID sid : new ArrayList<>(signPrompts.keySet())) restoreSign(sid);
        saveData();
    }

    // progress towards the next Shard (0..1) - at the AFK spot it fills 10x faster than anywhere else
    private final Map<UUID, Double> shardProgress = new HashMap<>();

    boolean atAfkSpot(Player p, Location afk) {
        if (afk == null || afk.getWorld() == null || !afk.getWorld().equals(p.getWorld())) return false;
        double r = getConfig().getDouble("shards.afk-radius", 50);
        return p.getLocation().distanceSquared(afk) <= r * r;
    }

    void tick() {
        double normal = getConfig().getDouble("shards.per-minutes", 10) * 60;
        double afkMin = getConfig().getDouble("shards.afk-minutes", 1) * 60;
        long amt = getConfig().getLong("shards.amount", 1);
        Location afk = data.getLocation("afk");
        for (Player p : Bukkit.getOnlinePlayers()) {
            playSeconds.merge(p.getUniqueId(), 1L, Long::sum);
            double need = atAfkSpot(p, afk) ? afkMin : normal;
            if (need > 0) {
                double prog = shardProgress.merge(p.getUniqueId(), 1.0 / need, Double::sum);
                if (prog >= 1.0) {
                    shardProgress.put(p.getUniqueId(), prog - 1.0);
                    shards.merge(p.getUniqueId(), amt, Long::sum);
                    if (getConfig().getBoolean("shards.notify", true) && need >= normal)
                        msg(p, "You earned " + amt + (amt == 1 ? " Shard" : " Shards") + " for playing the server");
                }
            }
            updateBoard(p);
            if (setting(p.getUniqueId(), "tpauto", false))
                p.sendActionBar(Component.text("TPA Auto-Accept: ON", NamedTextColor.GREEN));
        }
    }

    // ---------- Utility ----------
    String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    // every plugin chat message is plain white (colour codes are stripped)
    String w(String m) { return ChatColor.WHITE + ChatColor.stripColor(c(m)); }

    void msg(CommandSender s, String m) { s.sendMessage(w(getConfig().getString("prefix", "") + m)); }

    static String pretty(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String part : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    String goodName(ItemStack it) {
        EntityType stype = spawnerType(it);
        if (stype != null) return nice(stype) + " Spawner";
        ItemMeta m = it.getItemMeta();
        if (m != null && m.hasDisplayName()) return ChatColor.stripColor(LegacyComponentSerializer.legacySection().serialize(m.displayName()));
        return pretty(it.getType());
    }

    double bal(UUID id) { return money.getOrDefault(id, 0.0); }

    void add(UUID id, double amt) { money.put(id, Math.max(0, bal(id) + amt)); }

    boolean take(UUID id, double amt) {
        if (bal(id) < amt) return false;
        money.put(id, bal(id) - amt);
        return true;
    }

    static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        if (i == 0) return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
        String s = String.format(Locale.US, "%.1f", v);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    static String fullMoney(double v) {
        long whole = (long) Math.floor(Math.max(0, v));
        return String.format(Locale.US, "%,d", whole).replace(',', '.') + " (" + fmt(v) + ")";
    }

    static String dh(long s) { return (s / 86400) + "d " + (s % 86400 / 3600) + "h"; }

    String lineKey(String l) {
        for (String k : new String[]{"money", "shards", "kills", "deaths", "playtime", "team"})
            if (l.contains("{" + k + "}")) return k;
        return null;
    }

    static String shortTime(long s) {
        long d = s / 86400, h = s % 86400 / 3600, m = s % 3600 / 60;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }

    static String hms(long s) { return (s / 3600) + "h " + (s % 3600 / 60) + "m " + (s % 60) + "s"; }

    double parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) mul = 1e3;
            else if (s.endsWith("m")) mul = 1e6;
            else if (s.endsWith("b")) mul = 1e9;
            if (mul != 1) s = s.substring(0, s.length() - 1);
            double v = Double.parseDouble(s) * mul;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? -1 : v;
        } catch (Exception e) { return -1; }
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta mt = it.getItemMeta();
        mt.setDisplayName(c(name));
        if (lore.length > 0) mt.setLore(Arrays.stream(lore).map(this::c).collect(Collectors.toList()));
        it.setItemMeta(mt);
        return it;
    }

    boolean setting(UUID id, String key, boolean def) { return data.getBoolean("settings." + id + "." + key, def); }

    void setSetting(UUID id, String key, boolean v) { data.set("settings." + id + "." + key, v); }

    // ---------- Known players (anyone who has ever joined, online or offline) ----------
    final Set<String> knownNames = new java.util.concurrent.ConcurrentSkipListSet<>(String.CASE_INSENSITIVE_ORDER);
    static final Set<String> SELECTORS = Set.of("a", "e", "n", "p", "r", "s");

    void loadKnownNames() {
        for (OfflinePlayer op : Bukkit.getOfflinePlayers()) if (op.getName() != null) knownNames.add(op.getName());
        for (UUID u : new HashSet<>(money.keySet())) {
            String nn = Bukkit.getOfflinePlayer(u).getName();
            if (nn != null) knownNames.add(nn);
        }
    }

    // find a player who has joined before (case-insensitive, works while they are offline); null if unknown
    OfflinePlayer findPlayer(String name) {
        if (name == null || name.isBlank()) return null;
        if (name.startsWith("@")) name = name.substring(1);
        Player on = Bukkit.getPlayerExact(name);
        if (on != null) return on;
        String real = knownNames.ceiling(name);
        if (real != null && real.equalsIgnoreCase(name)) return Bukkit.getOfflinePlayer(real);
        OfflinePlayer c = Bukkit.getOfflinePlayerIfCached(name);
        if (c != null && c.getName() != null) { knownNames.add(c.getName()); return c; }
        return null;
    }

    // tab-complete every known player (online + offline). If the player typed "@", suggest "@Name" so the list still shows.
    List<String> allNames(String typed) {
        boolean at = typed.startsWith("@");
        String pre = (at ? typed.substring(1) : typed).toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String nm : knownNames) {
            if (nm.toLowerCase(Locale.ROOT).startsWith(pre)) out.add(at ? "@" + nm : nm);
            if (out.size() >= 200) break;
        }
        for (Player pl : Bukkit.getOnlinePlayers()) {
            String nm = pl.getName();
            String sug = at ? "@" + nm : nm;
            if (nm.toLowerCase(Locale.ROOT).startsWith(pre) && !out.contains(sug)) out.add(sug);
        }
        return out;
    }

    List<String> names(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).collect(Collectors.toList());
    }

    List<String> mobs(String prefix) {
        return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                .filter(k -> k.startsWith(prefix.toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
    }

    void applyEnchants(ItemStack it, Collection<?> list) {
        for (Object o : list) {
            try {
                String[] a = String.valueOf(o).split(":");
                Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase(Locale.ROOT)));
                if (en != null) it.addUnsafeEnchantment(en, a.length > 1 ? Integer.parseInt(a[1]) : 1);
            } catch (Exception ignored) { }
        }
    }

    void giveArmorSet(Player p) { giveArmorSet(p, "DIAMOND"); }

    // tier = DIAMOND / NETHERITE / IRON ... ; enchants come from config "<tier>-armor-enchants"
    void giveArmorSet(Player p, String tier) {
        for (String part : new String[]{"HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS"}) {
            Material m = Material.matchMaterial(tier + "_" + part);
            if (m == null) continue;
            ItemStack it = new ItemStack(m);
            applyEnchants(it, getConfig().getStringList(tier.toLowerCase(Locale.ROOT) + "-armor-enchants"));
            give(p, it);
        }
    }

    static String variantName(String v) {
        StringBuilder sb = new StringBuilder();
        for (String part : v.toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    static boolean isSetKey(String key) { return key.endsWith("_ARMOR_SET"); }

    static String tierName(double price) {
        if (price < 100) return "&7Common";
        if (price < 1_000) return "&aUncommon";
        if (price < 10_000) return "&9Rare";
        if (price < 100_000) return "&5Epic";
        if (price < 1_000_000) return "&6Legendary";
        return "&c&lMythic";
    }

    void shardsCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length >= 3 && a[0].equalsIgnoreCase("pay")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            long amt = (long) parseAmount(a[2]);
            if (t == null || t == p || amt <= 0) { msg(p, "&cInvalid input"); return; }
            if (shards.getOrDefault(id, 0L) < amt) { msg(p, "&cNot enough Shards"); return; }
            shards.merge(id, -amt, Long::sum);
            shards.merge(t.getUniqueId(), amt, Long::sum);
            msg(p, "&aSent &d" + fmt(amt) + " Shards &ato &9" + t.getName());
            msg(t, "&9" + p.getName() + " &apaid you &d" + fmt(amt) + " Shards");
            t.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(w(p.getName() + " paid you " + fmt(amt) + " Shards")));
            t.playSound(t.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
            return;
        }
        msg(p, "&dYour Shards: &f" + fmt(shards.getOrDefault(id, 0L)) + " &7| /shardshop opens the shop | /shards pay <player> <amount>");
    }

    void openShardShop(Player p) { openShardShop(p, 0, false); }
    void openShardShop(Player p, int page) { openShardShop(p, page, false); }

    void openShardShop(Player p, int page, boolean legacyFlag) {
        List<List<ItemStack>> allGoods = new ArrayList<>();
        List<Long> allPrices = new ArrayList<>();
        List<ItemStack> allDisplay = new ArrayList<>();
        List<Integer> allSlots = new ArrayList<>();   // wanted slot on the gear page (-1 = next free slot)
        for (Map<?, ?> m : getConfig().getMapList("shardshop.items")) {
            try {
                List<String> ench = new ArrayList<>();
                if (m.get("enchants") instanceof List<?> el) for (Object o : el) ench.add(String.valueOf(o));
                List<ItemStack> goods = new ArrayList<>();
                ItemStack display;
                Object armorSet = m.get("armor-set");
                if (armorSet != null) {
                    for (String part : List.of("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS")) {
                        Material pm = Material.matchMaterial(String.valueOf(armorSet).toUpperCase(Locale.ROOT) + "_" + part);
                        if (pm == null) continue;
                        ItemStack pi = new ItemStack(pm);
                        applyEnchants(pi, ench);
                        goods.add(pi);
                    }
                    if (goods.isEmpty()) continue;
                    display = goods.get(goods.size() > 1 ? 1 : 0).clone();
                } else {
                    Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                    if (mat == null) continue;
                    int amt = m.get("amount") instanceof Number nn ? nn.intValue() : 1;
                    ItemStack gi = new ItemStack(mat, Math.max(1, amt));
                    applyEnchants(gi, ench);
                    if (m.get("name") != null) {
                        ItemMeta gm = gi.getItemMeta();
                        gm.setDisplayName(c(String.valueOf(m.get("name"))));
                        gi.setItemMeta(gm);
                    }
                    if (m.get("hammer") != null) tagHammer(gi);
                    if (m.get("sellaxe") != null) tagSellAxe(gi);
                    goods.add(gi);
                    display = gi.clone();
                }
                long price = ((Number) m.get("price")).longValue();
                ItemMeta mt = display.getItemMeta();
                if (m.get("name") != null) mt.setDisplayName(c(String.valueOf(m.get("name"))));
                List<String> lore = new ArrayList<>();
                if (armorSet != null) lore.add(c("&7Includes all 4 pieces"));
                lore.add(c("&7Price: &d" + fmt(price) + " Shards"));
                lore.add(c("&eClick to buy"));
                mt.setLore(lore);
                display.setItemMeta(mt);
                allGoods.add(goods);
                allPrices.add(price);
                allDisplay.add(display);
                allSlots.add(m.get("slot") instanceof Number sn ? sn.intValue() : -1);
            } catch (Exception ignored) { }
        }
        int gearCount = allGoods.size();

        List<EntityType> types = Arrays.stream(EntityType.values())
                .filter(et -> Material.matchMaterial(et.name() + "_SPAWN_EGG") != null)
                .sorted(Comparator.comparing(Enum::name)).collect(Collectors.toList());
        for (EntityType et : types) {
            long price = getConfig().getLong("shardshop.spawner-prices." + et.name(), getConfig().getLong("shardshop.spawner-default", 800));
            ItemStack good = spawnerItem(et, 1);
            ItemStack display = good.clone();
            ItemMeta dm = display.getItemMeta();
            dm.setLore(List.of(c("&7Type: &f" + nice(et)), c("&7Price: &d" + fmt(price) + " Shards"), c("&eClick to buy")));
            display.setItemMeta(dm);
            allGoods.add(List.of(good));
            allPrices.add(price);
            allDisplay.add(display);
            allSlots.add(-1);
        }
        // Layout: page 1 = gear on the slots chosen in config (grouped in rows), then spawners follow on the next pages
        int n = allGoods.size();
        int[] pageOf = new int[n];
        int[] slotOf = new int[n];
        List<boolean[]> used = new ArrayList<>();
        if (gearCount > 0) used.add(new boolean[45]);
        boolean[] placed = new boolean[n];
        for (int i = 0; i < gearCount; i++) {
            int ws = allSlots.get(i);
            if (ws >= 0 && ws < 45 && !used.get(0)[ws]) { used.get(0)[ws] = true; pageOf[i] = 0; slotOf[i] = ws; placed[i] = true; }
        }
        for (int i = 0; i < gearCount; i++) {
            if (placed[i]) continue;
            outer:
            for (int pg = 0; ; pg++) {
                if (pg == used.size()) used.add(new boolean[45]);
                for (int sl = 0; sl < 45; sl++) {
                    if (!used.get(pg)[sl]) { used.get(pg)[sl] = true; pageOf[i] = pg; slotOf[i] = sl; break outer; }
                }
            }
        }
        int gearPages = used.size();
        for (int k = 0; gearCount + k < n; k++) { pageOf[gearCount + k] = gearPages + k / 45; slotOf[gearCount + k] = k % 45; }
        int pages = Math.max(1, gearPages + (n - gearCount + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("shardshop");
        g.page = page;
        g.goods = allGoods;
        g.prices = allPrices;
        String baseTitle = getConfig().getString("shardshop.title", "&5&lShard Shop");
        g.inv = Bukkit.createInventory(g, 54, c(baseTitle + (pages > 1 ? " &8(" + (page + 1) + "/" + pages + ")" : "")));
        for (int i = 0; i < n; i++) {
            if (pageOf[i] != page) continue;
            g.slotIdx.put(slotOf[i], i);
            g.inv.setItem(slotOf[i], allDisplay.get(i));
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        g.inv.setItem(49, item(Material.AMETHYST_SHARD, "&dShards: &f" + fmt(shards.getOrDefault(p.getUniqueId(), 0L)), "&7Play to earn Shards"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // Items that are sold in /shop sell for the same price as they cost there.
    // (Enchanted shop gear keeps the "sell:" price, so plain crafted gear is not paid like enchanted gear.)
    // shop price of one entry (key may be MATERIAL, MATERIAL:VARIANT or TIER_ARMOR_SET); /settingmn edits are stored in data.yml
    double shopPrice(String cat, String key) {
        String dp = "prices.shop." + cat + "." + key;
        if (data.contains(dp)) return data.getDouble(dp);
        return getConfig().getDouble("shop-items." + cat + "." + key, -1);
    }

    double sellPrice(Material m) {
        String k = m.name();
        if (data.contains("prices.sell." + k)) return data.getDouble("prices.sell." + k);
        if (getConfig().contains("sell-override." + k)) return getConfig().getDouble("sell-override." + k);
        ConfigurationSection si = getConfig().getConfigurationSection("shop-items");
        if (si != null && !getConfig().contains("shop-enchants." + k)) {
            for (String cat : si.getKeys(false)) {
                ConfigurationSection cs = si.getConfigurationSection(cat);
                if (cs != null && cs.contains(k)) return shopPrice(cat, k);
            }
        }
        return getConfig().getDouble("sell." + k, getConfig().getDouble("sell-default", 1));
    }


    void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection m = data.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection sh = data.getConfigurationSection("shards");
        if (sh != null) for (String k : sh.getKeys(false)) shards.put(UUID.fromString(k), sh.getLong(k));
        ConfigurationSection bo = data.getConfigurationSection("bounties");
        if (bo != null) for (String k : bo.getKeys(false)) { double bv = bo.getDouble(k); if (bv > 0) bounties.put(UUID.fromString(k), bv); }
        ConfigurationSection pt = data.getConfigurationSection("playtime");
        if (pt != null) for (String k : pt.getKeys(false)) playSeconds.put(UUID.fromString(k), pt.getLong(k));
        ConfigurationSection os = data.getConfigurationSection("orders");
        if (os != null) for (String k : os.getKeys(false)) {
            ConfigurationSection s = os.getConfigurationSection(k);
            Material mat = Material.matchMaterial(s.getString("item", ""));
            if (mat == null) continue;
            int id = Integer.parseInt(k);
            Order lo = new Order(id, UUID.fromString(s.getString("owner")), mat, s.getInt("left"), s.getDouble("price"));
            lo.delivered = s.getInt("delivered");
            orders.add(lo);
            nextOrderId = Math.max(nextOrderId, id + 1);
        }
        ConfigurationSection as = data.getConfigurationSection("auctions");
        if (as != null) for (String k : as.getKeys(false)) {
            ConfigurationSection s = as.getConfigurationSection(k);
            ItemStack it = s.getItemStack("item");
            if (it == null) continue;
            int id = Integer.parseInt(k);
            listings.add(new Listing(id, UUID.fromString(s.getString("seller")), it, s.getDouble("price"), s.getLong("time")));
            nextListingId = Math.max(nextListingId, id + 1);
        }
        ConfigurationSection cs = data.getConfigurationSection("claims");
        if (cs != null) for (String owner : cs.getKeys(false)) {
            Map<String, Integer> map = new HashMap<>();
            ConfigurationSection items = cs.getConfigurationSection(owner);
            for (String mat : items.getKeys(false)) map.put(mat, items.getInt(mat));
            claims.put(UUID.fromString(owner), map);
        }
        ConfigurationSection sps = data.getConfigurationSection("spawners");
        if (sps != null) for (String k : sps.getKeys(false)) {
            ConfigurationSection sc = sps.getConfigurationSection(k);
            try {
                SpawnerData sd = new SpawnerData(UUID.fromString(sc.getString("owner")), EntityType.valueOf(sc.getString("type")),
                        sc.getString("world"), sc.getInt("x"), sc.getInt("y"), sc.getInt("z"));
                sd.stack = Math.max(1, sc.getInt("stack", 1));
                sd.xp = sc.getLong("xp");
                ConfigurationSection its = sc.getConfigurationSection("items");
                if (its != null) for (String mk : its.getKeys(false)) {
                    Material mm = Material.matchMaterial(mk);
                    if (mm != null) sd.items.put(mm, its.getLong(mk));
                }
                for (String dn : sc.getStringList("disabled")) {
                    Material dm = Material.matchMaterial(dn);
                    if (dm != null) sd.disabled.add(dm);
                }
                spawners.put(sd.id, sd);
            } catch (Exception ex) { getLogger().warning("bad spawner entry " + k); }
        }
        ConfigurationSection bns = data.getConfigurationSection("bans");
        if (bns != null) for (String k : bns.getKeys(false)) {
            try {
                bans.put(UUID.fromString(k), new BanInfo(bns.getString(k + ".reason", "Cheating"), bns.getLong(k + ".until"), bns.getString(k + ".id", "UNKNOWN")));
            } catch (Exception ex) { getLogger().warning("bad ban entry " + k); }
        }
        ConfigurationSection mst = data.getConfigurationSection("stats.mined");
        if (mst != null) for (String k : mst.getKeys(false)) mined.put(UUID.fromString(k), mst.getLong(k));
        ConfigurationSection pst = data.getConfigurationSection("stats.placed");
        if (pst != null) for (String k : pst.getKeys(false)) placed.put(UUID.fromString(k), pst.getLong(k));
    }

    void saveData() {
        data.set("money", null);
        money.forEach((k, v) -> data.set("money." + k, v));
        data.set("shards", null);
        shards.forEach((k, v) -> data.set("shards." + k, v));
        data.set("bounties", null);
        bounties.forEach((k, v) -> data.set("bounties." + k, v));
        data.set("playtime", null);
        playSeconds.forEach((k, v) -> data.set("playtime." + k, v));
        data.set("orders", null);
        for (Order o : orders) {
            String p = "orders." + o.id + ".";
            data.set(p + "owner", o.owner.toString());
            data.set(p + "item", o.mat.name());
            data.set(p + "left", o.left);
            data.set(p + "delivered", o.delivered);
            data.set(p + "price", o.price);
        }
        data.set("auctions", null);
        for (Listing l : listings) {
            String p = "auctions." + l.id + ".";
            data.set(p + "seller", l.seller.toString());
            data.set(p + "item", l.item);
            data.set(p + "price", l.price);
            data.set(p + "time", l.time);
        }
        data.set("claims", null);
        claims.forEach((k, map) -> map.forEach((mat, n) -> data.set("claims." + k + "." + mat, n)));
        data.set("spawners", null);
        int si = 0;
        for (SpawnerData sd : spawners.values()) {
            String b = "spawners." + (si++) + ".";
            data.set(b + "world", sd.world);
            data.set(b + "x", sd.x); data.set(b + "y", sd.y); data.set(b + "z", sd.z);
            data.set(b + "owner", sd.owner.toString());
            data.set(b + "type", sd.type.name());
            data.set(b + "stack", sd.stack);
            data.set(b + "xp", sd.xp);
            data.set(b + "disabled", sd.disabled.stream().map(Material::name).collect(Collectors.toList()));
            for (Map.Entry<Material, Long> en : sd.items.entrySet()) data.set(b + "items." + en.getKey().name(), en.getValue());
        }
        data.set("stats", null);
        mined.forEach((k, v) -> data.set("stats.mined." + k, v));
        placed.forEach((k, v) -> data.set("stats.placed." + k, v));
        data.set("bans", null);
        bans.forEach((k, v) -> {
            data.set("bans." + k + ".reason", v.reason());
            data.set("bans." + k + ".until", v.until());
            data.set("bans." + k + ".id", v.id());
        });
        data.set("keyall", null); // purge old Keyall data
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    // ---------- Scoreboard ----------
    // Title with a left-to-right multi-colour gradient (default: white -> yellow -> purple)
    Component boardTitle() {
        String text = getConfig().getString("scoreboard.title", "Lastlight SMP");
        if (text == null || text.isEmpty()) return Component.text(" ");
        List<String> hex = getConfig().getStringList("scoreboard.gradient");
        if (hex.size() < 2) hex = List.of("#FFFFFF", "#FFE14D", "#A855F7");
        int[] stops = new int[hex.size()];
        for (int i = 0; i < stops.length; i++) {
            try { stops[i] = Integer.parseInt(hex.get(i).replace("#", "").trim(), 16); }
            catch (NumberFormatException ex) { stops[i] = 0xFFFFFF; }
        }
        int n = text.length();
        Component out = Component.empty();
        for (int i = 0; i < n; i++) {
            double t = n <= 1 ? 0 : (double) i / (n - 1);
            double pos = t * (stops.length - 1);
            int k = Math.min((int) Math.floor(pos), stops.length - 2);
            double f = pos - k;
            int c1 = stops[k], c2 = stops[k + 1];
            int r = (int) Math.round(((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * f);
            int g = (int) Math.round(((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * f);
            int bl = (int) Math.round((c1 & 255) + ((c2 & 255) - (c1 & 255)) * f);
            out = out.append(Component.text(String.valueOf(text.charAt(i)))
                    .color(net.kyori.adventure.text.format.TextColor.color(r, g, bl))
                    .decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
        }
        return out;
    }

    void setupBoard(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", Criteria.DUMMY, boardTitle());
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        o.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.blank());
        Objective bn = sb.registerNewObjective("donut_money", Criteria.DUMMY, c("&a$"));
        bn.setDisplaySlot(DisplaySlot.BELOW_NAME);
        int n = Math.min(15, getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = "\u00a7" + Integer.toHexString(i) + "\u00a7r";
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        updateBoard(p);
    }

    void updateBoard(Player p) {
        UUID id = p.getUniqueId();
        Scoreboard sb = p.getScoreboard();
        if (sb.getObjective("donut") == null) { setupBoard(p); return; }
        updateNameTags(sb);
        boolean show = setting(id, "scoreboard", true);
        sb.getObjective("donut").setDisplaySlot(show ? DisplaySlot.SIDEBAR : null);
        if (!show) return;
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        int n = Math.min(15, lines.size());
        boolean[] vis = new boolean[n];
        int visCount = 0;
        for (int i = 0; i < n; i++) {
            String key = lineKey(lines.get(i));
            vis[i] = key == null || setting(id, "sb_" + key, true);
            if (vis[i]) visCount++;
        }
        Objective obj = sb.getObjective("donut");
        int pos = 0;
        for (int i = 0; i < n; i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String entry = "§" + Integer.toHexString(i) + "§r";
            if (!vis[i]) { sb.resetScores(entry); continue; }
            String line = lines.get(i)
                    .replace("{money}", fmt(bal(id)))
                    .replace("{shards}", fmt(shards.getOrDefault(id, 0L)))
                    .replace("{kills}", String.valueOf(kills(id)))
                    .replace("{deaths}", String.valueOf(deaths(id)))
                    .replace("{playtime}", shortTime(playSeconds.getOrDefault(id, 0L)))
                    .replace("{team}", teamName(id))
                    .replace("{player}", p.getName())
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()));
            t.setPrefix(c(line));
            obj.getScore(entry).setScore(visCount - pos);
            pos++;
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        e.joinMessage(Component.text(p.getName() + " joined the game", NamedTextColor.WHITE));
        if (!money.containsKey(p.getUniqueId())) money.put(p.getUniqueId(), getConfig().getDouble("start-money", 0));
        knownNames.add(p.getName());
        setupBoard(p);
        applyNv(p);
        refreshStaffPerms(p);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) applyNv(p); }, 2L);
    }

    // Auto respawn: skip the death screen and respawn the player right away (each player can toggle it in /settings)
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeathAutoRespawn(org.bukkit.event.entity.PlayerDeathEvent e) {
        if (!getConfig().getBoolean("auto-respawn.enabled", true)) return;
        Player p = e.getEntity();
        if (!setting(p.getUniqueId(), "autorespawn", true)) return;   // player turned it off in /settings
        long delay = Math.max(1L, getConfig().getLong("auto-respawn.delay-ticks", 1L));
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && p.isDead()) p.spigot().respawn();
        }, delay);
    }

    private boolean inFxFree = false;

    // ---------- Combat tag ----------
    private final Map<UUID, Long> combatUntil = new HashMap<>();

    boolean inCombat(Player p) {
        Long u = combatUntil.get(p.getUniqueId());
        if (u == null) return false;
        if (u < System.currentTimeMillis()) { combatUntil.remove(p.getUniqueId()); return false; }
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onCombatHit(org.bukkit.event.entity.EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player dp) attacker = dp;
        else if (e.getDamager() instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Player sp) attacker = sp;
        if (attacker == null || attacker.equals(victim)) return;
        long until = System.currentTimeMillis() + getConfig().getInt("combat.seconds", 20) * 1000L;
        combatUntil.put(victim.getUniqueId(), until);
        combatUntil.put(attacker.getUniqueId(), until);
    }

    @EventHandler
    public void onCombatDeath(org.bukkit.event.entity.PlayerDeathEvent e) {
        combatUntil.remove(e.getEntity().getUniqueId());
    }

    private final Map<UUID, Long> spawnerOpenAt = new HashMap<>();

    // merge a drop into the existing stacks (up to the max stack size) so an explosion spawns very few items
    void addMergedDrop(List<ItemStack> stacks, List<Location> where, ItemStack it, Location at) {
        for (ItemStack ex : stacks) {
            if (it.getAmount() <= 0) return;
            if (!ex.isSimilar(it) || ex.getAmount() >= ex.getMaxStackSize()) continue;
            int mv = Math.min(ex.getMaxStackSize() - ex.getAmount(), it.getAmount());
            ex.setAmount(ex.getAmount() + mv);
            it.setAmount(it.getAmount() - mv);
        }
        if (it.getAmount() > 0) { stacks.add(it); where.add(at); }
    }

    // "noexplode" = hide the explosion effect (particles + sound) only. Blocks and entities are still damaged.
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onExplosionProtect(EntityExplodeEvent e) {
        Entity en = e.getEntity();
        if (!(en instanceof TNTPrimed || en instanceof EnderCrystal || en instanceof ExplosiveMinecart)) return;
        Location loc = e.getLocation();
        boolean hide = false;
        for (Player pl : loc.getWorld().getNearbyPlayers(loc, 24)) {
            if (setting(pl.getUniqueId(), "noexplode", false)) { hide = true; break; }
        }
        if (!hide) return;
        // Cancelling the event removes the vanilla particles/sound; we apply the destruction + damage ourselves
        e.setCancelled(true);
        // keep the explosion SOUND (only the particles are hidden)
        ThreadLocalRandom sr = ThreadLocalRandom.current();
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0f,
                (1.0f + (sr.nextFloat() - sr.nextFloat()) * 0.2f) * 0.7f);
        float power = en instanceof EnderCrystal ? 6f : 4f;
        List<Block> blocks = new ArrayList<>(e.blockList());
        float yield = e.getYield();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        List<ItemStack> dropStacks = new ArrayList<>();
        List<Location> dropWhere = new ArrayList<>();
        for (Block b : blocks) {
            Material t = b.getType();
            if (t.isAir()) continue;
            if (t == Material.TNT) {
                b.setType(Material.AIR);
                TNTPrimed tnt = (TNTPrimed) b.getWorld().spawnEntity(b.getLocation().add(0.5, 0, 0.5), EntityType.TNT);
                tnt.setFuseTicks(10 + rnd.nextInt(20));
                continue;
            }
            // vanilla-like drops: collect the drops, merge them into full stacks, spawn few item entities (no lag)
            if (rnd.nextFloat() <= yield) {
                for (ItemStack d : b.getDrops(new ItemStack(Material.NETHERITE_PICKAXE))) {
                    if (d == null || d.getType().isAir()) continue;
                    addMergedDrop(dropStacks, dropWhere, d.clone(), b.getLocation().add(0.5, 0.5, 0.5));
                }
            }
            b.setType(Material.AIR);
        }
        for (int i = 0; i < dropStacks.size(); i++) loc.getWorld().dropItem(dropWhere.get(i), dropStacks.get(i));
        double r = power * 2;
        for (Entity t : loc.getWorld().getNearbyEntities(loc, r, r, r)) {
            if (t == en) continue;
            // like vanilla: spectators and flying creative players are not pushed or hurt by explosions
            if (t instanceof Player tp0 && (tp0.getGameMode() == GameMode.SPECTATOR
                    || (tp0.getGameMode() == GameMode.CREATIVE && tp0.isFlying()))) continue;
            double dist = t.getLocation().distance(loc) / r;
            if (dist > 1) continue;
            double impact = 1 - dist;
            if (t instanceof org.bukkit.entity.LivingEntity le) {
                double dmg = ((impact * impact + impact) / 2 * 7 * r + 1);
                le.damage(dmg, en);
            }
            org.bukkit.util.Vector kb = t.getLocation().toVector().subtract(loc.toVector());
            if (kb.lengthSquared() > 0) t.setVelocity(t.getVelocity().add(kb.normalize().multiply(impact)));
        }
        en.remove();
    }


    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        // "@Name" works like "Name" for any known player (selectors such as @a @p @r @s @e @n are left alone)
        for (int ai = 0; ai < a.length; ai++) {
            if (a[ai].length() > 2 && a[ai].startsWith("@") && !SELECTORS.contains(a[ai].substring(1).toLowerCase(Locale.ROOT))
                    && knownNames.contains(a[ai].substring(1))) a[ai] = a[ai].substring(1);
        }

        if (n.equals("eco")) {
            if (!isStaff(s)) { msg(s, "&cYou do not have permission"); return true; }
            String usage = "&e/eco <give|take|set> <player> <money|shard|kill|death|time> <amount>  &7|  &e/eco reset <player> [type]  &7|  &e/eco proset <player> [all|type]";
            if (a.length < 2) { msg(s, usage); return true; }
            String act = a[0].toLowerCase(Locale.ROOT);
            if (a[1].startsWith("@")) {
                List<Player> targets = new ArrayList<>();
                try {
                    for (Entity en : Bukkit.selectEntities(s, a[1])) if (en instanceof Player tp) targets.add(tp);
                } catch (IllegalArgumentException ex) { msg(s, "&cInvalid selector. Use @a @e @n @p @r @s"); return true; }
                if (targets.isEmpty()) { msg(s, "&cNo players matched " + a[1]); return true; }
                for (Player tp : targets) {
                    String[] b = a.clone();
                    b[1] = tp.getName();
                    onCommand(s, cmd, label, b);
                }
                return true;
            }
            OfflinePlayer t = findPlayer(a[1]);
            if (t == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
            UUID tid = t.getUniqueId();
            Player online = t.getPlayer();

            if (act.equals("reset")) {
                String what = a.length >= 3 ? a[2].toLowerCase(Locale.ROOT) : "all";
                boolean all = what.equals("all");
                boolean done = false;
                if (all || what.equals("money")) { money.put(tid, getConfig().getDouble("start-money", 0)); done = true; }
                if (all || what.equals("shard") || what.equals("shards")) { shards.put(tid, 0L); done = true; }
                if (all || what.equals("kill") || what.equals("kills")) { setKills(tid, 0); done = true; }
                if (all || what.equals("death") || what.equals("deaths")) { setDeaths(tid, 0); done = true; }
                if (all || what.equals("time") || what.equals("playtime")) { playSeconds.put(tid, 0L); done = true; }
                if (!done) { msg(s, "&cType must be money / shard / kill / death / time"); return true; }
                if (online != null) updateBoard(online);
                msg(s, "&aReset " + (all ? "all stats" : what) + " of &f" + a[1]);
                return true;
            }

            if (act.equals("proset")) {
                String what = a.length >= 3 ? a[2].toLowerCase(Locale.ROOT) : "all";
                boolean all = what.equals("all");
                ThreadLocalRandom r = ThreadLocalRandom.current();
                boolean done = false;
                if (all || what.equals("money")) { money.put(tid, (double) r.nextLong(1000, 5_000_001)); done = true; }
                if (all || what.equals("shard") || what.equals("shards")) { shards.put(tid, r.nextLong(0, 50_001)); done = true; }
                if (all || what.equals("kill") || what.equals("kills")) { setKills(tid, r.nextInt(0, 501)); done = true; }
                if (all || what.equals("death") || what.equals("deaths")) { setDeaths(tid, r.nextInt(0, 501)); done = true; }
                if (all || what.equals("time") || what.equals("playtime")) { playSeconds.put(tid, r.nextLong(3600, 500L * 3600 + 1)); done = true; }
                if (!done) { msg(s, "&cType must be all / money / shard / kill / death / time"); return true; }
                if (online != null) updateBoard(online);
                msg(s, "&aRandomized " + (all ? "all stats" : what) + " of &f" + a[1]
                        + " &7($" + fmt(bal(tid)) + " | " + fmt(shards.getOrDefault(tid, 0L)) + " shards | "
                        + kills(tid) + " kills | " + deaths(tid) + " deaths | " + dh(playSeconds.getOrDefault(tid, 0L)) + ")");
                return true;
            }

            if (!(act.equals("give") || act.equals("take") || act.equals("set"))) { msg(s, usage); return true; }
            if (a.length < 4) { msg(s, usage); return true; }
            String kind = a[2].toLowerCase(Locale.ROOT);
            String amtStr = a[3];
            switch (kind) {
                case "money" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    switch (act) {
                        case "give" -> add(tid, amt);
                        case "take" -> add(tid, -amt);
                        default -> money.put(tid, amt);
                    }
                    msg(s, "&a" + a[1] + "'s money is now $" + fmt(bal(tid)));
                }
                case "shard", "shards" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    long v = (long) amt;
                    long cur = shards.getOrDefault(tid, 0L);
                    switch (act) {
                        case "give" -> shards.put(tid, cur + v);
                        case "take" -> shards.put(tid, Math.max(0, cur - v));
                        default -> shards.put(tid, v);
                    }
                    msg(s, "&d" + a[1] + "'s Shards are now " + fmt(shards.getOrDefault(tid, 0L)));
                }
                case "kill", "kills" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    int v = (int) amt;
                    switch (act) {
                        case "give" -> setKills(tid, kills(tid) + v);
                        case "take" -> setKills(tid, kills(tid) - v);
                        default -> setKills(tid, v);
                    }
                    msg(s, "&c" + a[1] + "'s Kills are now " + kills(tid));
                }
                case "death", "deaths" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    int v = (int) amt;
                    switch (act) {
                        case "give" -> setDeaths(tid, deaths(tid) + v);
                        case "take" -> setDeaths(tid, deaths(tid) - v);
                        default -> setDeaths(tid, v);
                    }
                    msg(s, "&6" + a[1] + "'s Deaths are now " + deaths(tid));
                }
                case "time", "playtime" -> {
                    long secs = parseTime(amtStr);
                    if (secs < 0) { msg(s, "&cInvalid time (examples: 5 = 5 hours, 90m, 2d)"); return true; }
                    long cur = playSeconds.getOrDefault(tid, 0L);
                    switch (act) {
                        case "give" -> playSeconds.put(tid, cur + secs);
                        case "take" -> playSeconds.put(tid, Math.max(0, cur - secs));
                        default -> playSeconds.put(tid, secs);
                    }
                    msg(s, "&e" + a[1] + "'s Playtime is now " + dh(playSeconds.getOrDefault(tid, 0L)));
                }
                default -> { msg(s, "&cType must be money / shard / kill / death / time"); return true; }
            }
            if (online != null) updateBoard(online);
            return true;
        }

        if (n.equals("help-smp")) {
            for (String l : getConfig().getStringList("help-smp.lines")) s.sendMessage(w(l));
            return true;
        }

        if (n.equals("afk")) {
            if (a.length == 0) {   // everyone: teleport to the AFK spot
                if (!(s instanceof Player ap)) { msg(s, "&cPlayers only"); return true; }
                Location al = data.getLocation("afk");
                if (al == null || al.getWorld() == null) { msg(s, "&cThe AFK spot has not been set yet"); return true; }
                ap.teleportAsync(al);
                msg(s, "Teleporting to the AFK spot");
                return true;
            }
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (sub.equals("reset")) {
                data.set("afk", null);
                saveData();
                msg(s, "AFK spot removed");
                return true;
            }
            if (sub.equals("set")) {
                Location base = s instanceof Player sp ? sp.getLocation() : Bukkit.getWorlds().get(0).getSpawnLocation();
                Location target;
                try {
                    String[] xyz;
                    if (a.length == 4) xyz = new String[]{a[1], a[2], a[3]};
                    else if (a.length == 2 && a[1].matches("-?\\d+(\\.\\d+)?-(-?\\d+(\\.\\d+)?)-(-?\\d+(\\.\\d+)?)")) {
                        java.util.regex.Matcher mt = java.util.regex.Pattern.compile("(-?\\d+(?:\\.\\d+)?)-(-?\\d+(?:\\.\\d+)?)-(-?\\d+(?:\\.\\d+)?)").matcher(a[1]);
                        mt.matches();
                        xyz = new String[]{mt.group(1), mt.group(2), mt.group(3)};
                    } else if (a.length == 1 && s instanceof Player) xyz = null;   // no coordinates = your position
                    else { msg(s, "/afk set <x> <y> <z>  |  /afk set  (your position)  |  /afk reset"); return true; }
                    if (xyz == null) target = base.clone();
                    else target = new Location(base.getWorld(), Double.parseDouble(xyz[0]), Double.parseDouble(xyz[1]), Double.parseDouble(xyz[2]), base.getYaw(), base.getPitch());
                } catch (NumberFormatException ex) { msg(s, "&cInvalid coordinates"); return true; }
                data.set("afk", target);
                saveData();
                msg(s, "AFK spot set at " + target.getBlockX() + " " + target.getBlockY() + " " + target.getBlockZ() + " (" + target.getWorld().getName() + ")");
                return true;
            }
            msg(s, "/afk  |  /afk set <x> <y> <z>  |  /afk reset");
            return true;
        }

        if (n.equals("givera")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
            // /givera re <rank|all> <player>  -> remove a rank (or all ranks)
            if (a.length >= 1 && (a[0].equalsIgnoreCase("re") || a[0].equalsIgnoreCase("remove"))) {
                if (a.length < 3) { msg(s, "/givera re <rank|all> <player>"); return true; }
                OfflinePlayer rt = findPlayer(a[2]);
                if (rt == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
                String rk = normalizeRank(a[1]);
                List<String> cur = new ArrayList<>(ranksOf(rt.getUniqueId()));
                if (rk.equals("ALL")) {
                    cur.clear();
                    msg(s, "Removed all ranks of " + a[2]);
                } else if (cur.remove(rk)) {
                    msg(s, "Removed rank " + rk + " from " + a[2]);
                } else {
                    msg(s, a[2] + " does not have rank " + rk);
                    return true;
                }
                saveRanks(rt.getUniqueId(), cur);
                return true;
            }
            if (a.length < 2) { msg(s, "/givera <player> <OWNER|ADMIN|CREATOR|+|++|+++>   |   /givera re <rank|all> <player>"); return true; }
            OfflinePlayer rt = findPlayer(a[0]);
            if (rt == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
            String rk = normalizeRank(a[1]);
            if (rk.equals("NONE") || rk.equals("REMOVE")) {   // legacy: clear everything
                saveRanks(rt.getUniqueId(), new ArrayList<>());
                msg(s, "Removed all ranks of " + a[0]);
            } else if (getConfig().contains("ranks." + rk)) {
                List<String> cur = new ArrayList<>(ranksOf(rt.getUniqueId()));
                if (rk.startsWith("PLUS")) cur.removeIf(x -> x.startsWith("PLUS"));   // only one of + / ++ / +++
                if (!cur.contains(rk)) cur.add(rk);
                saveRanks(rt.getUniqueId(), cur);
                msg(s, "Gave rank " + rk + " to " + a[0]);
            } else {
                msg(s, "Unknown rank (OWNER, ADMIN, CREATOR, +, ++, +++)");
            }
            return true;
        }

        if (n.equals("spawner")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
            if (a.length >= 2 && a[0].equalsIgnoreCase("fill")) {
                if (!(s instanceof Player fp)) { msg(s, "&cPlayers only"); return true; }
                EntityType ft;
                try { ft = EntityType.valueOf(a[1].toUpperCase(Locale.ROOT)); } catch (Exception ex) { ft = null; }
                if (ft == null) { msg(s, "&cUnknown mob type"); return true; }
                int stackN = 1;
                if (a.length > 2) { try { stackN = Math.max(1, Math.min(getConfig().getInt("spawner.max-stack", 100000), Integer.parseInt(a[2]))); } catch (NumberFormatException ex) { stackN = 1; } }
                Block floor = fp.getLocation().getBlock().getRelative(0, -1, 0);
                if (floor.getY() < fp.getWorld().getMinHeight() || floor.getType() == Material.BEDROCK || floor.getState() instanceof TileState) {
                    msg(s, "&cYou can't place it here");
                    return true;
                }
                SpawnerData ex0 = spawners.get(key(floor));
                int maxStack = getConfig().getInt("spawner.max-stack", 100000);
                if (ex0 != null && floor.getType() == Material.SPAWNER) {
                    if (ex0.type != ft) { msg(s, "&cThere is already a " + nice(ex0.type) + " spawner here"); return true; }
                    int add = Math.min(stackN, maxStack - ex0.stack);
                    if (add <= 0) { msg(s, "&cMaximum stack reached"); return true; }
                    ex0.stack += add;
                    msg(s, "&aAdded " + add + " " + nice(ft) + " spawner(s). Now x" + ex0.stack);
                    return true;
                }
                placeSpawner(floor, ft, fp.getUniqueId(), stackN);
                msg(s, "&aPlaced " + nice(ft) + " spawner x" + stackN + " under your feet (1x1)");
                return true;
            }
            if (a.length < 3 || !a[0].equalsIgnoreCase("give")) { msg(s, "&e/spawner give <player> <mob> [amount] | /spawner fill <mob> [stack]"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            EntityType et;
            try { et = EntityType.valueOf(a[2].toUpperCase(Locale.ROOT)); } catch (Exception ex) { et = null; }
            if (t == null || et == null) { msg(s, "&cPlayer or mob type not found"); return true; }
            int amt = 1;
            if (a.length > 3) { try { amt = Math.max(1, Math.min(getConfig().getInt("spawner.give-max", 100000), Integer.parseInt(a[3]))); } catch (NumberFormatException ex) { amt = 1; } }
            giveSpawners(t, et, amt);
            msg(s, "&aGave " + nice(et) + " Spawner x" + amt + " to " + t.getName());
            return true;
        }

        if (!(s instanceof Player p)) { s.sendMessage("Players only"); return true; }
        UUID id = p.getUniqueId();

        switch (n) {
            case "shop" -> openShop(p);
            case "sell" -> openSell(p);
            case "order" -> orderCmd(p, a);
            case "ah" -> ahCmd(p, a);
            case "rtp" -> rtpCmd(p, a);
            case "offend" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                if (a.length < 3) { msg(p, "&e/offend <player> <ESP|AutoClicker|HackedClient|Cheating|XRAY> <time: 30m, 12h, 14d, 1d12h, perm>"); return true; }
                long banSecs = parseBanSeconds(a[a.length - 1]);
                if (banSecs < 0) { msg(p, "&cInvalid time. Examples: 30m, 12h, 14d, 1d12h, perm"); return true; }
                String off = offenceOf(String.join(" ", Arrays.copyOfRange(a, 1, a.length - 1)));
                if (off == null) { msg(p, "&cReason must be one of: ESP, AutoClicker, HackedClient, Cheating, XRAY"); return true; }
                Player onT = Bukkit.getPlayerExact(a[0]);
                OfflinePlayer offT = onT != null ? onT : findPlayer(a[0]);
                if (offT == null) { msg(p, "&cPlayer not found"); return true; }
                if (offT.getUniqueId().equals(p.getUniqueId())) { msg(p, "&cYou cannot ban yourself"); return true; }
                String offName = offT.getName() != null ? offT.getName() : a[0];
                BanInfo bi = new BanInfo(off, banSecs == 0 ? 0L : System.currentTimeMillis() + banSecs * 1000L, genBanId());
                bans.put(offT.getUniqueId(), bi);
                Player kickT = Bukkit.getPlayer(offT.getUniqueId());
                if (kickT != null) kickT.kick(banScreen(bi));
                saveData();
                msg(p, "Banned " + offName + " for " + off + " (" + (banSecs == 0 ? "permanent" : dhms(banSecs)) + ")");
            }
            case "unoffend" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                if (a.length < 1) { msg(p, "&e/unoffend <player>"); return true; }
                Player unOn = Bukkit.getPlayerExact(a[0]);
                OfflinePlayer unT = unOn != null ? unOn : findPlayer(a[0]);
                if (unT == null) { msg(p, "&cPlayer not found"); return true; }
                String unName = unT.getName() != null ? unT.getName() : a[0];
                if (bans.remove(unT.getUniqueId()) != null) { saveData(); msg(p, "Unbanned " + unName); }
                else msg(p, "&c" + unName + " is not banned by /offend");
            }
            case "settingall" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                openSettingAll(p);
            }
            case "settingmn" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                openPriceMgr(p, 0);
            }
            case "sus" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                openSus(p, 0);
            }
            case "gmst" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                p.setGameMode(GameMode.SPECTATOR);
                msg(p, "Game mode set to Spectator");
            }
            case "gmse" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                p.setGameMode(GameMode.SURVIVAL);
                msg(p, "Game mode set to Survival");
            }
            case "fly" -> {
                if (!canFly(p)) { msg(p, "&cYou do not have permission"); return true; }
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) { msg(p, "&cYou can already fly in this game mode"); return true; }
                boolean flyOn = !p.getAllowFlight();
                p.setAllowFlight(flyOn);
                if (flyOn) { if (!p.isOnGround()) p.setFlying(true); }
                else p.setFlying(false);
                msg(p, flyOn ? "Fly enabled" : "Fly disabled");
            }
            case "balance" -> {
                if (a.length == 0) { msg(p, "You have " + fullMoney(bal(id))); return true; }
                UUID tid = null;
                String tname = a[0];
                Player online = Bukkit.getPlayerExact(a[0]);
                if (online != null) { tid = online.getUniqueId(); tname = online.getName(); }
                else {
                    OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(a[0]);
                    if (op != null) { tid = op.getUniqueId(); if (op.getName() != null) tname = op.getName(); }
                }
                if (tid == null) { msg(p, "&cPlayer not found"); return true; }
                msg(p, tname + " have " + fullMoney(bal(tid)));
            }
            case "pay" -> pay(p, a);
            case "tpa" -> tpaCmd(p, a, false);
            case "tphere" -> tpaCmd(p, a, true);
            case "tpaccept" -> tpAcceptCmd(p, a.length > 0 ? a[0] : null);
            case "tpdeny" -> tpRespond(p, false, a.length > 0 ? a[0] : null);
            case "tpgui" -> {
                TpaReq rq = tpaReqs.get(id);
                Player rf = a.length > 0 ? Bukkit.getPlayerExact(a[0]) : null;
                if (rq == null || rf == null || !rq.from.equals(rf.getUniqueId()) || rq.expire < System.currentTimeMillis()) {
                    msg(p, "&cNo pending teleport request");
                } else {
                    openTpConfirm(p, rf, rq.here);
                }
            }
            case "rtpq" -> {
                if (rtpQueue.contains(id)) joinRtpQueue(p); else openRtpQueue(p);
            }
            case "baltop" -> openBaltop(p, 0);
            case "dounty" -> bountyCmd(p, a);
            case "stats" -> {
                UUID su = id;
                if (a.length > 0) {
                    OfflinePlayer fp0 = findPlayer(a[0]);
                    su = fp0 == null ? null : fp0.getUniqueId();
                    if (su == null) { msg(p, "&cPlayer not found"); return true; }
                }
                openProfile(p, su);
            }
            case "tpauto" -> {
                boolean v = !setting(id, "tpauto", false);
                setSetting(id, "tpauto", v);
                msg(p, "&eAuto-accept TPA: " + (v ? "&aON" : "&cOFF"));
            }
            case "settings" -> openSettings(p);
            case "nv" -> {
                boolean on = !setting(id, "nv", false);
                setNv(p, on);
                msg(p, "&eNight Vision: " + (on ? "&aON" : "&cOFF"));
            }
            case "team" -> teamCmd(p, a);
            case "sethome" -> {
                String name = a.length > 0 ? cleanHomeName(a[0]) : "home";
                if (name == null) { msg(p, "&cInvalid home name (use letters, numbers, _ or -, max 16 characters)"); return true; }
                setHome(p, name);
            }
            case "home" -> {
                if (a.length == 0) { openHomes(p); return true; }
                String name = a[0].toLowerCase(Locale.ROOT);
                Location l = data.getLocation("homes." + id + "." + name);
                if (l == null) { msg(p, "&cHome not found: " + name); return true; }
                p.teleportAsync(l);
                msg(p, "&aTeleported to home &e" + name);
            }
            case "delhome" -> {
                if (a.length < 1) { msg(p, "&e/delhome <name>"); return true; }
                String path = "homes." + id + "." + a[0].toLowerCase(Locale.ROOT);
                if (!data.contains(path)) { msg(p, "&cHome not found"); return true; }
                data.set(path, null);
                msg(p, "&aHome deleted");
            }
            case "rules" -> openRules(p);
            case "shardshop" -> openShardShop(p);
            case "shards" -> shardsCmd(p, a);
        }
        return true;
    }

    void pay(Player p, String[] a) {
        if (a.length < 2) { msg(p, "&e/pay <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        double amt = parseAmount(a[1]);
        if (t == null || t == p) { msg(p, "&cPlayer not found"); return; }
        if (amt <= 0) { msg(p, "&cInvalid amount"); return; }
        if (!setting(t.getUniqueId(), "pay", true)) { msg(p, "&cThis player has disabled receiving payments"); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cNot enough money"); return; }
        add(t.getUniqueId(), amt);
        msg(p, "&aYou sent $" + fmt(amt) + " to &9" + t.getName());
        msg(t, "&9" + p.getName() + " &apaid you &e$" + fmt(amt));
        t.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(w(p.getName() + " paid you $" + fmt(amt))));
        t.playSound(t.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    // ---------- TPA ----------
    void tpaCmd(Player p, String[] a, boolean here) {
        if (a.length < 1) { msg(p, "&e/" + (here ? "tphere" : "tpa") + " <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || t == p) { msg(p, "&cPlayer not found"); return; }
        if (inCombat(t)) { msg(p, "That user is in combat"); return; }
        if (!setting(t.getUniqueId(), here ? "tphere" : "tpa", true)) { msg(p, "&cThis player has disabled teleport requests"); return; }
        if (setting(t.getUniqueId(), "tpauto", false)) { doTp(p, t, here); return; }
        tpaReqs.put(t.getUniqueId(), new TpaReq(p.getUniqueId(), here, System.currentTimeMillis() + 60_000));
        String reqWord = here ? "tpahere" : "tpa";
        msg(p, "You sent " + t.getName() + " a " + reqWord);
        t.sendMessage(w(p.getName() + " sent " + reqWord + " You"));
        TextComponent tc = new TextComponent(TextComponent.fromLegacyText(w("type: /tpaccept")));
        tc.setClickEvent(new net.md_5.bungee.api.chat.ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, "/tpaccept"));
        t.spigot().sendMessage(tc);
        t.playSound(t.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);   // ping only: the window opens when /tpaccept is used
    }

    // /tpaccept opens the Accept / Deny window (nothing opens by itself when a request arrives)
    void tpAcceptCmd(Player p, String who) {
        TpaReq r = tpaReqs.get(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { tpaReqs.remove(p.getUniqueId()); msg(p, "&cNo pending teleport request"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { tpaReqs.remove(p.getUniqueId()); msg(p, "&cThe requester is offline"); return; }
        if (who != null && !from.getName().equalsIgnoreCase(who)) { msg(p, "&cNo request from that player"); return; }
        openTpConfirm(p, from, r.here);
    }

    void doTp(Player requester, Player target, boolean here) {
        requester.sendMessage(w(target.getName() + " accepted the " + (here ? "tpahere" : "tpa") + "."));
        requester.playSound(requester.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        if (here) target.teleportAsync(requester.getLocation());
        else requester.teleportAsync(target.getLocation());
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (requester.isOnline()) requester.playSound(requester.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            if (target.isOnline()) target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
        }, 10L);
    }

    void tpRespond(Player p, boolean accept, String who) {
        TpaReq r = tpaReqs.get(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { tpaReqs.remove(p.getUniqueId()); msg(p, "&cNo pending teleport request"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (who != null && (from == null || !from.getName().equalsIgnoreCase(who))) { msg(p, "&cNo request from that player"); return; }
        tpaReqs.remove(p.getUniqueId());
        if (from == null) { msg(p, "&cThe requester is offline"); return; }
        if (accept && inCombat(from)) { msg(p, "That user is in combat"); return; }
        if (!accept) {
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.8f);
            msg(p, "&cRequest denied");
            msg(from, "&c" + p.getName() + " denied your teleport request");
            return;
        }
        doTp(from, p, r.here);
    }

    void openTpConfirm(Player p, Player from, boolean here) {
        Gui g = new Gui("tpconfirm");
        g.filter = from.getName();
        g.inv = Bukkit.createInventory(g, 27, c("&8" + (here ? "TPAHERE" : "TPA") + " Request"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cDeny", "&7Click to deny the request"));
        World.Environment env = from.getWorld().getEnvironment();
        Material wm = env == World.Environment.NETHER ? Material.NETHERRACK : env == World.Environment.THE_END ? Material.END_STONE : Material.GRASS_BLOCK;
        g.inv.setItem(12, item(wm, "&fWorld: &e" + from.getWorld().getName()));
        g.inv.setItem(13, item(Material.NETHERITE_SWORD, "&6" + (here ? "TPAHERE" : "TPA") + " Request",
                "&f" + from.getName() + " &7" + (here ? "wants you to teleport to them" : "wants to teleport to you"), "&7Do you accept?"));
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(from);
        sm.setDisplayName(c("&f" + from.getName()));
        head.setItemMeta(sm);
        g.inv.setItem(14, head);
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aAccept", "&7Click to accept the request"));
        p.openInventory(g.inv);
    }

    // ---------- /rtpq ----------
    void openRtpQueue(Player p) {
        Gui g = new Gui("rtpq");
        g.inv = Bukkit.createInventory(g, 27, c("&8RTP Queue"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cDeny"));
        g.inv.setItem(13, item(Material.NETHERITE_SWORD, "&6RTP Queue", "&7You will be matched with another player in the queue", "&7and teleport to them", "&7Do you want to join the RTPQ?"));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aConfirm"));
        p.openInventory(g.inv);
    }

    void joinRtpQueue(Player p) {
        UUID id = p.getUniqueId();
        if (rtpQueue.remove(id)) { msg(p, "&eYou left the RTPQ"); return; }
        rtpQueue.removeIf(u -> Bukkit.getPlayer(u) == null);
        UUID other = rtpQueue.stream().filter(u -> !u.equals(id)).findFirst().orElse(null);
        if (other != null) {
            rtpQueue.remove(other);
            Player op = Bukkit.getPlayer(other);
            if (op != null) {
                p.teleportAsync(op.getLocation());
                msg(p, "&aMatched! Teleporting to &e" + op.getName());
                msg(op, "&e" + p.getName() + " &ateleported to you via RTPQ");
                return;
            }
        }
        rtpQueue.add(id);
        msg(p, "&eYou joined the RTPQ. Waiting for another player... (type /rtpq again to leave)");
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (rtpQueue.remove(id)) {
                Player q = Bukkit.getPlayer(id);
                if (q != null) msg(q, "&cRTPQ timed out");
            }
        }, 20L * 120);
    }


    // ---------- Bounty: /dounty (view)  |  /dounty add <player> <amount> ----------
    void bountyCmd(Player p, String[] a) {
        if (a.length == 0) { openBounty(p, 0); return; }
        if (!a[0].equalsIgnoreCase("add") || a.length < 3) {
            msg(p, "&e/dounty &7- view all bounties  |  &e/dounty add <player> <amount> &7- put a bounty on a player's head");
            return;
        }
        OfflinePlayer t = findPlayer(a[1]);
        if (t == null) { msg(p, "&cPlayer not found (they must have joined the server before)"); return; }
        if (t.getUniqueId().equals(p.getUniqueId())) { msg(p, "&cYou can't put a bounty on yourself"); return; }
        double amt = parseAmount(a[2]);
        double min = getConfig().getDouble("bounty.min", 1000);
        if (amt <= 0) { msg(p, "&cInvalid amount"); return; }
        if (amt < min) { msg(p, "&cMinimum bounty is $" + fmt(min)); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cYou don't have enough money"); return; }
        double total = bounties.merge(t.getUniqueId(), amt, Double::sum);
        String tn = t.getName() == null ? a[1] : t.getName();
        Bukkit.broadcastMessage(w(p.getName() + " put a $" + fmt(amt) + " bounty on " + tn + " (total $" + fmt(total) + ")"));
        updateBoard(p);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBountyDeath(org.bukkit.event.entity.PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.getUniqueId().equals(victim.getUniqueId())) return;
        Double b = bounties.remove(victim.getUniqueId());
        if (b == null || b <= 0) return;
        add(killer.getUniqueId(), b);
        Bukkit.broadcastMessage(w(killer.getName() + " claimed the $" + fmt(b) + " bounty on " + victim.getName()));
        updateBoard(killer);
    }

    void openBounty(Player p, int page) {
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(bounties.entrySet());
        list.sort((x, y) -> Double.compare(y.getValue(), x.getValue()));
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("bounty");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8Bounties (Page " + (page + 1) + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            UUID u = list.get(i).getKey();
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.setDisplayName(c("&e#" + (i + 1) + " &f" + Optional.ofNullable(op.getName()).orElse("?")));
            sm.setLore(List.of(c("&7Bounty: &a$" + fmt(list.get(i).getValue())), c(op.isOnline() ? "&aOnline" : "&7Offline"), c("&eKill them to claim it")));
            head.setItemMeta(sm);
            g.inv.setItem(g.uuids.size(), head);
            g.uuids.add(u);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        g.inv.setItem(49, item(Material.PAPER, "&6Add a bounty", "&7/dounty add <player> <amount>", "&7Minimum: &a$" + fmt(getConfig().getDouble("bounty.min", 1000))));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        p.openInventory(g.inv);
    }

    void openBaltop(Player p, int page) {
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(money.entrySet());
        list.sort((x, y) -> Double.compare(y.getValue(), x.getValue()));
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("baltop");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8Most Money (Page " + (page + 1) + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            UUID u = list.get(i).getKey();
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.setDisplayName(c("&e#" + (i + 1) + " &f" + Optional.ofNullable(op.getName()).orElse("?")));
            sm.setLore(List.of(c("&7Money: &a$" + fmt(list.get(i).getValue())), c("&eClick to view profile")));
            head.setItemMeta(sm);
            g.inv.setItem(g.uuids.size(), head);
            g.uuids.add(u);
        }
        int myRank = 1;
        for (Map.Entry<UUID, Double> en : list) { if (en.getKey().equals(p.getUniqueId())) break; myRank++; }
        ItemStack mine = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta ms = (SkullMeta) mine.getItemMeta();
        ms.setOwningPlayer(p);
        ms.setDisplayName(c("&aMy Profile"));
        ms.setLore(List.of(c("&7Rank: &e#" + myRank), c("&7Money: &a$" + fmt(bal(p.getUniqueId())))));
        mine.setItemMeta(ms);
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        g.inv.setItem(48, mine);
        g.inv.setItem(49, item(Material.EMERALD, "&aYour Money", "&7Click to see your balance"));
        g.inv.setItem(50, item(Material.OAK_SIGN, "&eSearch Player", "&7Click to type a player name"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        p.openInventory(g.inv);
    }

    int kills(UUID id) {
        return Math.max(0, stat(Bukkit.getOfflinePlayer(id), Statistic.PLAYER_KILLS) + data.getInt("statoffset.kills." + id, 0));
    }

    int deaths(UUID id) {
        return Math.max(0, stat(Bukkit.getOfflinePlayer(id), Statistic.DEATHS) + data.getInt("statoffset.deaths." + id, 0));
    }

    void setKills(UUID id, int v) {
        data.set("statoffset.kills." + id, Math.max(0, v) - stat(Bukkit.getOfflinePlayer(id), Statistic.PLAYER_KILLS));
    }

    void setDeaths(UUID id, int v) {
        data.set("statoffset.deaths." + id, Math.max(0, v) - stat(Bukkit.getOfflinePlayer(id), Statistic.DEATHS));
    }

    // time: plain number = hours, or with suffix s / m / h / d (e.g. 90m, 2d)
    long parseTime(String t) {
        try {
            t = t.toLowerCase(Locale.ROOT).trim();
            long mul = 3600;
            char last = t.charAt(t.length() - 1);
            if (last == 's') { mul = 1; t = t.substring(0, t.length() - 1); }
            else if (last == 'm') { mul = 60; t = t.substring(0, t.length() - 1); }
            else if (last == 'h') { t = t.substring(0, t.length() - 1); }
            else if (last == 'd') { mul = 86400; t = t.substring(0, t.length() - 1); }
            return (long) (Double.parseDouble(t) * mul);
        } catch (Exception e) { return -1; }
    }

    int stat(OfflinePlayer op, Statistic st) {
        try { return op.getStatistic(st); } catch (Exception e) { return 0; }
    }

    void openProfile(Player viewer, UUID target) {
        OfflinePlayer op = Bukkit.getOfflinePlayer(target);
        String name = Optional.ofNullable(op.getName()).orElse("?");
        Gui g = new Gui("profile");
        g.inv = Bukkit.createInventory(g, 36, c("&8" + name + " Stats"));
        g.inv.setItem(10, item(Material.EMERALD, "&aMoney", "&f$" + fmt(bal(target))));
        g.inv.setItem(11, item(Material.AMETHYST_SHARD, "&dShards", "&f" + fmt(shards.getOrDefault(target, 0L))));
        g.inv.setItem(12, item(Material.DIAMOND_SWORD, "&cKills", "&f" + kills(target)));
        g.inv.setItem(13, item(Material.SKELETON_SKULL, "&6Deaths", "&f" + deaths(target)));
        g.inv.setItem(14, item(Material.CLOCK, "&ePlaytime", "&f" + dh(playSeconds.getOrDefault(target, 0L))));
        g.inv.setItem(15, item(Material.STONE, "&bBlocks Mined", "&f" + fmt(mined.getOrDefault(target, 0L))));
        g.inv.setItem(16, item(Material.COBBLESTONE, "&7Blocks Placed", "&f" + fmt(placed.getOrDefault(target, 0L))));
        g.inv.setItem(19, item(Material.ZOMBIE_HEAD, "&2Monsters Killed", "&f" + stat(op, Statistic.MOB_KILLS)));
        g.inv.setItem(27, item(Material.RED_STAINED_GLASS_PANE, "&c« Back"));
        g.filter = name;
        Player online = Bukkit.getPlayer(target);
        if (online != null && !online.equals(viewer)) {
            g.inv.setItem(30, item(Material.ENDER_PEARL, "&bTPA", "&7Request to teleport to &f" + name, "&eClick to send"));
            g.inv.setItem(32, item(Material.ENDER_EYE, "&bTPHERE", "&7Ask &f" + name + " &7to teleport to you", "&eClick to send"));
        }
        viewer.openInventory(g.inv);
    }

    void searchPlayerProfile(Player p, String text) {
        for (UUID u : money.keySet()) {
            String n = Bukkit.getOfflinePlayer(u).getName();
            if (n != null && n.equalsIgnoreCase(text)) {
                msg(p, "&f" + n + " &7has &a$" + fmt(bal(u)));
                openProfile(p, u);
                return;
            }
        }
        msg(p, "&cPlayer not found: " + text);
    }


    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMine(BlockBreakEvent e) { mined.merge(e.getPlayer().getUniqueId(), 1L, Long::sum); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlaceCount(BlockPlaceEvent e) { placed.merge(e.getPlayer().getUniqueId(), 1L, Long::sum); }

    @EventHandler(ignoreCancelled = true)
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL) return;
        if (!(e.getEntity() instanceof org.bukkit.entity.Enemy)) return;
        Collection<Player> near = e.getLocation().getWorld().getNearbyPlayers(e.getLocation(), 128);
        if (near.isEmpty()) return;
        for (Player pl : near) if (!setting(pl.getUniqueId(), "nomobs", false)) return;
        e.setCancelled(true);
    }

    // ---------- /settings ----------
    // key, name, default, icon
    private static final String[][] SETTINGS = {
            {"chat", "Global Chat", "true", "PAPER"},
            {"tpa", "Accept TPA Requests", "true", "ENDER_PEARL"},
            {"tphere", "Accept TPHERE Requests", "true", "ENDER_EYE"},
            {"tpauto", "Auto-Accept TPA/TPHERE", "false", "REPEATER"},
            {"pay", "Accept Payments (/pay)", "true", "EMERALD"},
            {"nomobs", "Disable Monsters & Phantoms Around You", "false", "ZOMBIE_HEAD"},
            {"noexplode", "Hide TNT & End Crystal Particles", "false", "TNT"},
            {"nv", "Night Vision", "false", "GOLDEN_CARROT"},
            {"autorespawn", "Auto Respawn", "true", "TOTEM_OF_UNDYING"},
            {"scoreboard", "Show Scoreboard", "true", "ITEM_FRAME"},
            {"sb_money", "Scoreboard: Money", "true", "GOLD_INGOT"},
            {"sb_shards", "Scoreboard: Shards", "true", "AMETHYST_SHARD"},
            {"sb_kills", "Scoreboard: Kills", "true", "DIAMOND_SWORD"},
            {"sb_deaths", "Scoreboard: Deaths", "true", "SKELETON_SKULL"},
            {"sb_playtime", "Scoreboard: Playtime", "true", "CLOCK"},
            {"sb_team", "Scoreboard: Team", "true", "WHITE_BANNER"}};
    private static final int[] SETTING_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29};

    void fill(Inventory inv, Material m) {
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, item(m, " "));
    }

    void openSettings(Player p) {
        Gui g = new Gui("settings");
        g.inv = Bukkit.createInventory(g, 45, c("&8Settings"));
        for (int i = 0; i < SETTINGS.length; i++) {
            boolean on = setting(p.getUniqueId(), SETTINGS[i][0], Boolean.parseBoolean(SETTINGS[i][2]));
            ItemStack st = item(Material.valueOf(SETTINGS[i][3]), (on ? "&a" : "&c") + SETTINGS[i][1],
                    on ? "&7Status: &a\u2714 ON" : "&7Status: &c\u2718 OFF", "", "&eClick to toggle");
            if (on) {
                ItemMeta sm = st.getItemMeta();
                sm.setEnchantmentGlintOverride(true);
                st.setItemMeta(sm);
            }
            g.inv.setItem(SETTING_SLOTS[i], st);
        }
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // ---------- Night vision (kept after death) ----------
    void setNv(Player p, boolean on) {
        setSetting(p.getUniqueId(), "nv", on);
        if (on) p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        else p.removePotionEffect(PotionEffectType.NIGHT_VISION);
    }

    void applyNv(Player p) {
        if (setting(p.getUniqueId(), "nv", false))
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
    }

    // ---------- /home GUI ----------
    private static final int HOME_MAX_ALL = 20;
    private static final int[] HOME_POS = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 29, 30, 31, 32, 33, 38, 39, 40, 41, 42};

    int homeLimit(UUID id) {
        if (ranksOf(id).contains("CREATOR")) return Math.min(HOME_MAX_ALL, getConfig().getInt("homes.creator-max", 20));
        return Math.min(5, getConfig().getInt("homes.max", 5));
    }

    private final Map<UUID, String> homeSearch = new HashMap<>();

    int[] homePositions(int limit) { return Arrays.copyOf(HOME_POS, Math.max(1, Math.min(limit, HOME_MAX_ALL))); }

    String cleanHomeName(String s) {
        if (s == null) return null;
        String n = s.toLowerCase(Locale.ROOT).trim().replace(' ', '_');
        return n.matches("[a-z0-9_\\-]{1,16}") ? n : null;
    }

    // fixed slot -> home name; homes that have no slot yet fill the free slots
    String[] homeSlots(UUID id, int limit) {
        String[] out = new String[limit];
        ConfigurationSection hs = data.getConfigurationSection("homes." + id);
        Set<String> existing = hs == null ? new HashSet<>() : hs.getKeys(false);
        Set<String> used = new HashSet<>();
        for (int i = 0; i < HOME_MAX_ALL; i++) {
            String nm = data.getString("homeslot." + id + "." + i);
            if (nm != null && existing.contains(nm) && used.add(nm) && i < limit) out[i] = nm;
        }
        TreeSet<String> rest = new TreeSet<>(Comparator.comparing(String::length).thenComparing(Comparator.naturalOrder()));
        for (String k : existing) if (!used.contains(k)) rest.add(k);
        for (int i = 0; i < limit; i++) {
            if (out[i] == null && !rest.isEmpty()) out[i] = rest.pollFirst();
            data.set("homeslot." + id + "." + i, out[i]);
        }
        return out;
    }

    boolean setHome(Player p, String name) { return setHome(p, name, -1); }

    boolean setHome(Player p, String name, int preferred) {
        UUID id = p.getUniqueId();
        String base = "homes." + id;
        int limit = homeLimit(id);
        String[] sl = homeSlots(id, limit);
        boolean exists = data.contains(base + "." + name);
        int free = -1;
        if (preferred >= 0 && preferred < limit && sl[preferred] == null) free = preferred;
        else for (int i = 0; i < limit; i++) if (sl[i] == null) { free = i; break; }
        if (!exists && free < 0) { msg(p, "&cYou can only set up to " + limit + " homes"); return false; }
        data.set(base + "." + name, p.getLocation());
        if (!exists) data.set("homeslot." + id + "." + free, name);
        msg(p, "&aHome &e" + name + " &aset");
        return true;
    }

    void openHomes(Player p) {
        UUID id = p.getUniqueId();
        int limit = homeLimit(id);
        String[] sl = homeSlots(id, limit);
        String f = homeSearch.getOrDefault(id, "").toLowerCase(Locale.ROOT).trim();
        Gui g = new Gui("homes");
        g.filter = f.isEmpty() ? "" : "search";
        g.inv = Bukkit.createInventory(g, 54, c("&8&lHomes"));
        if (f.isEmpty()) {
            for (int i = 0; i < 45; i++) {
                String nm = i < limit ? sl[i] : null;
                g.names.add(nm);
                if (i >= limit) {
                    g.inv.setItem(i, item(Material.RED_STAINED_GLASS_PANE, "&cLocked", "&7You cannot set a home here"));
                } else if (nm != null) {
                    g.inv.setItem(i, homeItem(id, nm));
                } else {
                    g.inv.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, "&7Empty Home Slot", "&eClick to set a home here"));
                }
            }
        } else {
            int pos = 0;
            for (String nm : sl) {
                if (nm == null || !nm.toLowerCase(Locale.ROOT).contains(f) || pos >= 45) continue;
                g.names.add(nm);
                g.inv.setItem(pos, homeItem(id, nm));
                pos++;
            }
            g.inv.setItem(51, item(Material.BARRIER, "&cClear search"));
        }
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Homes", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a home name"));
        p.openInventory(g.inv);
    }

    ItemStack homeItem(UUID id, String nm) {
        Location l = data.getLocation("homes." + id + "." + nm);
        String loc = (l != null && l.getWorld() != null)
                ? l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() : "?";
        return item(Material.LIME_STAINED_GLASS_PANE, "&a" + nm, "&7" + loc, "", "&eClick to open");
    }

    void openHomeManage(Player p, String name) {
        Location l = data.getLocation("homes." + p.getUniqueId() + "." + name);
        String loc = (l != null && l.getWorld() != null)
                ? l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() : "?";
        Gui g = new Gui("homemanage");
        g.filter = name;
        g.inv = Bukkit.createInventory(g, 27, c("&8Home: " + name));
        g.inv.setItem(10, item(Material.NAME_TAG, "&eRename Home", "&7Current name: &f" + name, "&7Click to change it"));
        g.inv.setItem(13, item(Material.ENDER_PEARL, "&aTeleport", "&7" + loc, "&7Click to teleport home"));
        g.inv.setItem(16, item(Material.BARRIER, "&4Delete Home", "&7Click to delete this home"));
        g.inv.setItem(22, item(Material.ARROW, "&e« Back", "&7Go back to your homes"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    String nextHomeName(UUID id) {
        int n = 1;
        while (data.contains("homes." + id + ".home" + n)) n++;
        return "home" + n;
    }

    // ---------- /rules GUI ----------
    void openRules(Player p) {
        int size = Math.max(9, Math.min(54, getConfig().getInt("rules-gui.size", 27) / 9 * 9));
        Gui g = new Gui("rules");
        g.inv = Bukkit.createInventory(g, size, c(getConfig().getString("rules-gui.title", "&8Rules")));
        for (Map<?, ?> m : getConfig().getMapList("rules-gui.items")) {
            try {
                int slot = ((Number) m.get("slot")).intValue();
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null || slot < 0 || slot >= size) continue;
                List<String> lore = new ArrayList<>();
                Object lo = m.get("lore");
                if (lo instanceof List<?> ll) for (Object o : ll) lore.add(String.valueOf(o));
                g.inv.setItem(slot, item(mat, String.valueOf(m.get("name")), lore.toArray(new String[0])));
            } catch (Exception ignored) { }
        }
        Material fm = Material.matchMaterial(getConfig().getString("rules-gui.filler", "BLACK_STAINED_GLASS_PANE"));
        if (fm != null) fill(g.inv, fm);
        p.openInventory(g.inv);
    }

    // ---------- Virtual Spawner ----------
    String nice(EntityType t) {
        String n = t.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(n.charAt(0)) + n.substring(1);
    }

    String key(Block b) { return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ(); }

    ItemStack spawnerItem(EntityType t, int amt) {
        ItemStack it = new ItemStack(Material.SPAWNER, amt);
        BlockStateMeta bm = (BlockStateMeta) it.getItemMeta();
        CreatureSpawner cs = (CreatureSpawner) bm.getBlockState();
        cs.setSpawnedType(t);
        bm.setBlockState(cs);
        bm.setDisplayName(c("&5Spawners"));
        bm.setLore(List.of(c("&7Type: &f" + nice(t)), c("&7Place it, then interact with an empty hand to open"), c("&7Interact with the same spawner type to stack (sneak = all, normal = one)")));
        it.setItemMeta(bm);
        return it;
    }

    // any amount: split into stacks of 64
    void giveSpawners(Player p, EntityType t, int total) {
        int left = total;
        while (left > 0) {
            int n = Math.min(64, left);
            give(p, spawnerItem(t, n));
            left -= n;
        }
    }

    EntityType spawnerType(ItemStack it) {
        if (it == null || it.getType() != Material.SPAWNER) return null;
        if (it.getItemMeta() instanceof BlockStateMeta bm && bm.getBlockState() instanceof CreatureSpawner cs) return cs.getSpawnedType();
        return null;
    }

    boolean canUse(Player p, SpawnerData sd) {
        return !getConfig().getBoolean("spawner.owner-only", false) || sd.owner.equals(p.getUniqueId()) || p.hasPermission("donutsmp.admin");
    }

    @EventHandler
    public void onSpawnerPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.SPAWNER) return;
        EntityType t = spawnerType(e.getItemInHand());
        if (t == null) return;
        Block b = e.getBlockPlaced();
        SpawnerData sd = new SpawnerData(e.getPlayer().getUniqueId(), t, b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        spawners.put(sd.id, sd);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0);
            cs.update();
        }
        msg(e.getPlayer(), "&aPlaced spawner &e" + nice(t) + " &7(interact with an empty hand to open)");
    }

    @EventHandler
    public void onSpawnerInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        boolean empty = hand == null || hand.getType().isAir();
        EntityType ht = spawnerType(hand);
        if (!empty && ht == null) return;
        e.setCancelled(true);
        if (!canUse(p, sd)) { msg(p, "&cThis spawner belongs to someone else"); return; }
        if (ht != null) {
            if (ht != sd.type) { msg(p, "&cSpawner types do not match"); return; }
            int room = getConfig().getInt("spawner.max-stack", 100000) - sd.stack;
            if (room <= 0) { msg(p, "&cMaximum stack reached"); return; }
            // sneaking = put in the whole stack in your hand, standing = one at a time
            int put = p.isSneaking() ? Math.min(hand.getAmount(), room) : 1;
            sd.stack += put;
            hand.setAmount(hand.getAmount() - put);
            msg(p, (put == 1 ? "You just added another spawner!" : "You just added " + put + " spawners!") + " There are now " + sd.stack + " spawners in the stack");
            return;
        }
        long nowMs = System.currentTimeMillis();
        Long lastOpen = spawnerOpenAt.get(p.getUniqueId());
        boolean menuOpen = p.getOpenInventory().getTopInventory().getHolder(false) instanceof Gui;
        if (menuOpen || (lastOpen != null && nowMs - lastOpen < 600)) {
            msg(p, "You cannot do this while having a menu open");
            return;
        }
        spawnerOpenAt.put(p.getUniqueId(), nowMs);
        openSpawner(p, sd, 0);
    }

    @EventHandler
    public void onSpawnerBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        if (!canUse(p, sd)) { e.setCancelled(true); msg(p, "&cThis spawner belongs to someone else"); return; }
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (getConfig().getBoolean("spawner.require-silk-touch", true)
                && (!tool.containsEnchantment(Enchantment.SILK_TOUCH) || !tool.getType().name().endsWith("_PICKAXE"))) {
            e.setCancelled(true);
            msg(p, "&cYou need a Pickaxe with Silk Touch");
            return;
        }
        e.setExpToDrop(0);
        e.setDropItems(false);
        int take = p.isSneaking() ? Math.min(sd.stack, Math.max(1, Math.min(64, getConfig().getInt("spawner.break-amount", 64)))) : 1;
        giveSpawners(p, sd.type, take);
        if (sd.stack > take) {
            sd.stack -= take;
            e.setCancelled(true);
            msg(p, "&eCollected " + take + " spawner(s), remaining &fx" + sd.stack);
        } else {
            spawners.remove(sd.id);
            msg(p, "&eSpawner collected (items left inside are lost)");
        }
    }

    @EventHandler
    public void onSpawnerExplode(EntityExplodeEvent e) {
        if (getConfig().getBoolean("spawner.explosion-protect", true))
            e.blockList().removeIf(b -> b.getType() == Material.SPAWNER && spawners.containsKey(key(b)));
    }

    void produceAll() {
        double dist = getConfig().getDouble("spawner.activation-distance", 16);
        double d2 = dist * dist;
        for (SpawnerData sd : spawners.values()) {
            World w = Bukkit.getWorld(sd.world);
            if (w == null) continue;
            boolean near = false;
            for (Player p : w.getPlayers()) {
                double dx = p.getX() - sd.x, dy = p.getY() - sd.y, dz = p.getZ() - sd.z;
                if (dx * dx + dy * dy + dz * dz <= d2) { near = true; break; }
            }
            if (near) produce(sd);
        }
    }

    void produce(SpawnerData sd) {
        long cap = getConfig().getLong("spawner.max-items", 50000);
        long total = sd.items.values().stream().mapToLong(Long::longValue).sum();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            try {
                String[] a = entry.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null || sd.disabled.contains(m)) continue;
                String[] range = a[1].split("-");
                long lo = Long.parseLong(range[0]) * sd.stack, hi = Long.parseLong(range[1]) * sd.stack;
                long amt = lo >= hi ? lo : r.nextLong(lo, hi + 1);
                amt = Math.min(amt, Math.max(0, cap - total));
                if (amt <= 0) continue;
                sd.items.merge(m, amt, Long::sum);
                total += amt;
            } catch (Exception ignored) { }
        }
        long maxXp = getConfig().getLong("spawner.max-xp", 100000);
        sd.xp = Math.min(maxXp, sd.xp + getConfig().getLong("spawner.xp-per-cycle", 5) * sd.stack);
    }

    long takeFromSpawner(Player p, SpawnerData sd, Material m, long want) {
        long have = sd.items.getOrDefault(m, 0L);
        want = Math.min(want, have);
        long given = 0;
        while (given < want) {
            int st = (int) Math.min(want - given, m.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        if (given > 0) {
            long rem = have - given;
            if (rem <= 0) sd.items.remove(m); else sd.items.put(m, rem);
        }
        return given;
    }

    Material mobIconMat(EntityType t) {
        Material m = switch (t) {
            case ZOMBIE -> Material.ZOMBIE_HEAD;
            case SKELETON -> Material.SKELETON_SKULL;
            case WITHER_SKELETON -> Material.WITHER_SKELETON_SKULL;
            case CREEPER -> Material.CREEPER_HEAD;
            case ZOMBIFIED_PIGLIN -> Material.PIGLIN_HEAD;
            default -> null;
        };
        if (m == null) m = Material.matchMaterial(t.name() + "_SPAWN_EGG");
        return m == null ? Material.PLAYER_HEAD : m;
    }

    // chance (percent) that an item is produced in one spawn cycle, from the "ITEM:min-max" config entries
    List<String> dropChanceLines(SpawnerData sd) {
        List<String> lines = new ArrayList<>();
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            try {
                String[] a = entry.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null) continue;
                String[] range = a[1].split("-");
                long lo = Long.parseLong(range[0]), hi = Long.parseLong(range[1]);
                double chance = hi <= 0 ? 0 : (lo > 0 ? 100.0 : 100.0 * hi / (hi + 1.0));
                boolean off = sd.disabled.contains(m);
                lines.add(c((off ? "&c" : "&7") + pretty(m) + ": " + (off ? "&c" : "&a") + Math.round(chance) + "%" + (off ? " (OFF)" : "")));
            } catch (Exception ignored) { }
        }
        return lines;
    }

    double spawnerTotalValue(SpawnerData sd) {
        double total = 0;
        for (Map.Entry<Material, Long> en : sd.items.entrySet()) total += en.getValue() * sellPrice(en.getKey());
        return total;
    }

    void openSpawner(Player p, SpawnerData sd, int page) {
        List<Material> mats = new ArrayList<>(sd.items.keySet());
        mats.removeIf(x -> sd.items.getOrDefault(x, 0L) <= 0);
        mats.sort(Comparator.comparing(Enum::name));
        List<Material> sm = new ArrayList<>();
        List<Integer> sc = new ArrayList<>();
        for (Material mm : mats) {
            long left = sd.items.get(mm);
            int max = mm.getMaxStackSize();
            while (left > 0 && sm.size() < 5000) {
                int st = (int) Math.min(left, max);
                sm.add(mm);
                sc.add(st);
                left -= st;
            }
        }
        int pages = Math.max(1, (sm.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("spawner");
        g.sp = sd;
        g.page = page;
        String title = sd.stack + " " + nice(sd.type).toUpperCase(Locale.ROOT) + " SPAWNERS" + (pages > 1 ? " (" + (page + 1) + "/" + pages + ")" : "");
        g.inv = Bukkit.createInventory(g, 54, c("&8" + title));
        for (int i = page * 45; i < Math.min(sm.size(), page * 45 + 45); i++) {
            Material m = sm.get(i);
            int cnt = sc.get(i);
            ItemStack it = new ItemStack(m, cnt);
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7Value: &a$" + fmt(cnt * sellPrice(m))), c("&eClick = take this stack")));
            it.setItemMeta(mt);
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
            g.counts.add(cnt);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        g.inv.setItem(48, item(Material.GOLD_BLOCK, "&6Sell", "&7Sell everything stored in this spawner", "&eClick to open"));
        g.inv.setItem(50, item(Material.DROPPER, "&6Drop Items", "&7Drops the items on this page", "&7in the direction you are looking"));
        List<String> headLore = new ArrayList<>();
        headLore.add(c("&7Spawners: &f" + sd.stack));
        headLore.add("");
        headLore.addAll(dropChanceLines(sd));
        g.inv.setItem(49, item(mobIconMat(sd.type), "&f" + nice(sd.type) + " Spawners", headLore.toArray(new String[0])));
        p.openInventory(g.inv);
    }

    void openSpawnerSell(Player p, SpawnerData sd) {
        Gui g = new Gui("spawnersell");
        g.sp = sd;
        g.inv = Bukkit.createInventory(g, 27, c("&8Sell Items"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cCancel", "&7Go back"));
        double total = spawnerTotalValue(sd);
        g.inv.setItem(13, item(mobIconMat(sd.type), "&f" + nice(sd.type) + " Spawners",
                "&7Level: &f" + sd.stack,
                "&7Price: &a$" + fmt(total)));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aConfirm", "&7Click to sell everything"));
        p.openInventory(g.inv);
    }

    void openSpawnerFilter(Player p, SpawnerData sd) {
        Gui g = new Gui("spawnerfilter");
        g.sp = sd;
        g.inv = Bukkit.createInventory(g, 27, c("&8" + nice(sd.type) + " - Choose Dropped Items"));
        int i = 0;
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            if (i >= 9) break;
            Material m = Material.matchMaterial(entry.split(":")[0]);
            if (m == null) continue;
            boolean off = sd.disabled.contains(m);
            g.inv.setItem(i, item(m, (off ? "&c" : "&a") + m.name(), off ? "&c✘ OFF (won't drop)" : "&a✔ ON (drops)", "&eClick to toggle"));
            g.inv.setItem(i + 9, item(off ? Material.RED_DYE : Material.LIME_DYE, off ? "&cOFF" : "&aON", "&7Click to toggle"));
            g.mats.add(m);
            i++;
        }
        g.inv.setItem(22, item(Material.ARROW, "&e« Back"));
        p.openInventory(g.inv);
    }

    void placeSpawner(Block b, EntityType t, UUID owner, int stack) {
        b.setType(Material.SPAWNER, false);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0);
            cs.update(true, false);
        }
        SpawnerData sd = new SpawnerData(owner, t, b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        sd.stack = stack;
        spawners.put(sd.id, sd);
    }

    // ---------- 3x3 Tools ----------
    private NamespacedKey hammerKey;

    NamespacedKey hk() {
        if (hammerKey == null) hammerKey = new NamespacedKey(this, "hammer3x3");
        return hammerKey;
    }

    void tagHammer(ItemStack it) {
        ItemMeta mt = it.getItemMeta();
        mt.getPersistentDataContainer().set(hk(), PersistentDataType.BYTE, (byte) 1);
        mt.setLore(List.of(c("&dAmethyst 3x3 Mining"), c("&7Front: 3x3  |  Up/Down: 3x1"), c("&7Hold Shift = mine a single block")));
        it.setItemMeta(mt);
    }

    // ---------- Sell Axe: breaking a container sells everything inside it ----------
    private NamespacedKey sellAxeKey;

    NamespacedKey sk() {
        if (sellAxeKey == null) sellAxeKey = new NamespacedKey(this, "sellaxe");
        return sellAxeKey;
    }

    void tagSellAxe(ItemStack it) {
        ItemMeta mt = it.getItemMeta();
        mt.getPersistentDataContainer().set(sk(), PersistentDataType.BYTE, (byte) 1);
        mt.setLore(List.of(c("&6Sell Axe"), c("&7Break a chest / barrel / shulker box"), c("&7and everything inside is sold automatically")));
        it.setItemMeta(mt);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSellAxeBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir() || !tool.hasItemMeta()) return;
        if (!tool.getItemMeta().getPersistentDataContainer().has(sk(), PersistentDataType.BYTE)) return;
        Block b = e.getBlock();
        if (!(b.getState() instanceof org.bukkit.block.Container cont)) return;
        Inventory inv = cont instanceof org.bukkit.block.Chest ch ? ch.getBlockInventory() : cont.getInventory();
        double total = 0;
        long count = 0;
        for (ItemStack st : inv.getContents()) {
            if (st == null || st.getType().isAir()) continue;
            total += st.getAmount() * sellPrice(st.getType());
            count += st.getAmount();
        }
        e.setCancelled(true);   // the container is NOT broken, only its contents are sold
        if (count <= 0) { msg(p, "&cNothing to sell in this container"); return; }
        inv.clear();
        add(p.getUniqueId(), total);
        msg(p, "You sold " + count + " items for $" + fmt(total));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    boolean canHammer(Block b, ItemStack tool) {
        Material t = b.getType();
        if (t.isAir() || b.isLiquid() || t == Material.BEDROCK || t == Material.SPAWNER || t.getHardness() < 0) return false;
        if (!b.isPreferredTool(tool)) return false;
        if (b.getState() instanceof TileState) return false;
        return !spawners.containsKey(key(b));
    }

    void damageTool(Player p, ItemStack tool, int amount) {
        if (tool.getItemMeta() instanceof Damageable d && !d.isUnbreakable()) {
            int nd = d.getDamage() + amount;
            if (nd >= tool.getType().getMaxDurability()) {
                p.getInventory().setItemInMainHand(null);
            } else {
                d.setDamage(nd);
                tool.setItemMeta(d);
            }
        }
    }

    void purpleFx(Block b) {
        b.getWorld().spawnParticle(Particle.DUST, b.getLocation().add(0.5, 0.5, 0.5), 12, 0.3, 0.3, 0.3, 0,
                new Particle.DustOptions(Color.fromRGB(170, 0, 255), 1.6f));
        b.getWorld().spawnParticle(Particle.WITCH, b.getLocation().add(0.5, 0.5, 0.5), 6, 0.3, 0.3, 0.3, 0);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHammerBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir() || !tool.hasItemMeta()) return;
        if (!tool.getItemMeta().getPersistentDataContainer().has(hk(), PersistentDataType.BYTE)) return;
        if (p.isSneaking()) return;
        Block origin = e.getBlock();
        BlockFace face = BlockFace.UP;
        RayTraceResult r = p.rayTraceBlocks(8);
        if (r != null && r.getHitBlockFace() != null && origin.equals(r.getHitBlock())) face = r.getHitBlockFace();
        purpleFx(origin);
        origin.getWorld().playSound(origin.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.0f);
        origin.getWorld().playSound(origin.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1.0f, 1.0f);
        int broken = 0;
        boolean vertical = face == BlockFace.UP || face == BlockFace.DOWN;
        BlockFace look = p.getFacing();
        boolean alongX = look == BlockFace.NORTH || look == BlockFace.SOUTH;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                if (vertical && dy != 0) continue;   // mining up/down = a row of 3 (3x1)
                Block b = switch (face) {
                    case UP, DOWN -> alongX ? origin.getRelative(dx, 0, 0) : origin.getRelative(0, 0, dx);
                    case NORTH, SOUTH -> origin.getRelative(dx, dy, 0);
                    default -> origin.getRelative(0, dy, dx);
                };
                if (!canHammer(b, tool)) continue;
                purpleFx(b);
                b.breakNaturally(tool);
                broken++;
            }
        }
        if (broken > 0) {
            mined.merge(p.getUniqueId(), (long) broken, Long::sum);
            // hammers are tough: only 1 durability per 3 extra blocks, and Unbreaking still applies
            int wear = 0;
            int ub = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
            for (int i = 0; i < Math.max(1, broken / 3); i++)
                if (ub <= 0 || ThreadLocalRandom.current().nextInt(ub + 1) == 0) wear++;
            if (wear > 0) damageTool(p, tool, wear);
        }
    }


    // Display order: OWNER, ADMIN, camera (CREATOR), then + / ++ / +++ always AFTER the camera
    static final List<String> RANK_ORDER = List.of("OWNER", "ADMIN", "CREATOR", "PLUS", "PLUS2", "PLUS3");

    static String normalizeRank(String in) {
        String rk = in.toUpperCase(Locale.ROOT);
        if (rk.equals("+\uD83D\uDCF7") || rk.equals("\uD83D\uDCF7") || rk.equals("CAMERA") || rk.equals("CAM") || rk.equals("CREATE")) return "CREATOR";
        if (rk.equals("+") || rk.equals("1")) return "PLUS";
        if (rk.equals("++") || rk.equals("2")) return "PLUS2";
        if (rk.equals("+++") || rk.equals("3")) return "PLUS3";
       
        return rk;
    }

    List<String> ranksOf(UUID id) {
        List<String> out = new ArrayList<>();
        if (data.isList("ranks." + id)) out.addAll(data.getStringList("ranks." + id));
        else if (data.isString("ranks." + id)) out.add(data.getString("ranks." + id));   // old single-rank data
        out.removeIf(r -> !getConfig().contains("ranks." + r));
        out.sort(Comparator.comparingInt((String r) -> { int k = RANK_ORDER.indexOf(r); return k < 0 ? 99 : k; }));
        return out;
    }

    void saveRanks(UUID id, List<String> list) {
        data.set("ranks." + id, list.isEmpty() ? null : list);
        Bukkit.getScheduler().runTask(this, () -> {
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) refreshStaffPerms(pl);
        });
    }

    // ---------- Bans made with /offend ----------
    record BanInfo(String reason, long until, String id) { }   // until = 0 -> permanent

    private final Map<UUID, BanInfo> bans = new java.util.concurrent.ConcurrentHashMap<>();

    static String dhms(long sec) {
        sec = Math.max(0, sec);
        return (sec / 86400) + "d " + (sec % 86400 / 3600) + "h " + (sec % 3600 / 60) + "m " + (sec % 60) + "s";
    }

    // 0 = permanent, -1 = invalid. Accepts 30m, 12h, 14d, 2w, 1d12h30m, perm
    long parseBanSeconds(String t) {
        t = t.toLowerCase(Locale.ROOT).trim();
        if (t.equals("perm") || t.equals("permanent") || t.equals("forever")) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)([wdhms])").matcher(t);
        long total = 0;
        int end = 0;
        while (m.find()) {
            if (m.start() != end) return -1;
            end = m.end();
            long n = Long.parseLong(m.group(1));
            long unit = switch (m.group(2).charAt(0)) { case 'w' -> 604800L; case 'd' -> 86400L; case 'h' -> 3600L; case 'm' -> 60L; default -> 1L; };
            total += n * unit;
        }
        return end == t.length() && total > 0 ? total : -1;
    }

    String genBanId() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) sb.append(chars.charAt(ThreadLocalRandom.current().nextInt(chars.length())));
        return sb.toString();
    }

    Component banScreen(BanInfo b) {
        String left = b.until() == 0 ? "Permanent" : dhms((b.until() - System.currentTimeMillis()) / 1000);
        return LegacyComponentSerializer.legacySection().deserialize("\u00a7fConnection Lost\n\n\u00a7cYou have been banned for " + b.reason()
                + "\n\n\u00a7fTime left: " + left + "\n\n\u00a7fBan ID: " + b.id());
    }

    @EventHandler
    public void onPreLogin(org.bukkit.event.player.AsyncPlayerPreLoginEvent e) {
        BanInfo b = bans.get(e.getUniqueId());
        if (b == null) return;
        if (b.until() != 0 && b.until() <= System.currentTimeMillis()) { bans.remove(e.getUniqueId()); return; }
        e.disallow(org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result.KICK_BANNED, banScreen(b));
    }

    // /pardon <name> also lifts a ban made with /offend
    void handlePardon(String text) {
        String[] parts = text.trim().split("\\s+");
        if (parts.length < 2) return;
        String cmd = parts[0].toLowerCase(Locale.ROOT).replace("/", "").replace("minecraft:", "");
        if (!cmd.equals("pardon")) return;
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(parts[1]);
        if (op != null && bans.remove(op.getUniqueId()) != null) saveData();
    }

    @EventHandler
    public void onPardonPlayer(org.bukkit.event.player.PlayerCommandPreprocessEvent e) {
        if (e.getPlayer().hasPermission("minecraft.command.pardon")) handlePardon(e.getMessage());
    }

    @EventHandler
    public void onPardonConsole(org.bukkit.event.server.ServerCommandEvent e) {
        handlePardon("/" + e.getCommand());
    }

    // ---------- /settingall : change everything on the server ----------
    void openSettingAll(Player p) {
        Gui g = new Gui("settingall");
        g.inv = Bukkit.createInventory(g, 27, c("&8Server Settings"));
        g.inv.setItem(11, item(Material.GOLD_INGOT, "&6Prices", "&7Change the /sell and /shop price of every item"));
        g.inv.setItem(13, item(Material.COMPARATOR, "&bServer Settings", "&7Change every value of the plugin config", "&7(spawners, shards, homes, combat ...)"));
        g.inv.setItem(15, item(Material.EMERALD, "&aReload config", "&7Reload config.yml from the disk"));
        p.openInventory(g.inv);
    }

    void openCfg(Player p, String path, int page) {
        ConfigurationSection sec = path.isEmpty() ? getConfig() : getConfig().getConfigurationSection(path);
        if (sec == null) { openCfg(p, "", 0); return; }
        List<String> keys = new ArrayList<>(sec.getKeys(false));
        keys.remove("config-version");
        int pages = Math.max(1, (keys.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("cfg");
        g.page = page;
        g.filter = path;
        String shown = path.isEmpty() ? "Settings" : path;
        if (shown.length() > 26) shown = "..." + shown.substring(shown.length() - 23);
        g.inv = Bukkit.createInventory(g, 54, c("&8" + shown + " (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(keys.size(), page * 45 + 45); i++) {
            String k = keys.get(i);
            String full = path.isEmpty() ? k : path + "." + k;
            Object v = sec.get(k);
            ItemStack it;
            String kind;
            if (v instanceof ConfigurationSection sub) {
                kind = "S";
                it = item(Material.CHEST, "&6" + k, "&7" + sub.getKeys(false).size() + " entries", "&eClick to open");
            } else if (v instanceof Boolean bv) {
                kind = "B";
                it = item(bv ? Material.LIME_DYE : Material.GRAY_DYE, "&f" + k, "&7Value: " + (bv ? "&atrue" : "&cfalse"), "&eClick to toggle");
            } else if (v instanceof Number) {
                kind = "N";
                it = item(Material.PAPER, "&f" + k, "&7Value: &e" + v, "&eClick to change");
            } else if (v instanceof String sv) {
                kind = "T";
                it = item(Material.NAME_TAG, "&f" + k, "&7Value: &f" + (sv.length() > 40 ? sv.substring(0, 40) + "..." : sv).replace('&', '+'), "&eClick to change");
            } else {
                kind = "L";
                it = item(Material.BOOK, "&f" + k, "&7List - edit it in config.yml");
            }
            g.inv.setItem(i - page * 45, it);
            g.names.add(kind + "|" + full);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(48, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.PAPER, "&e" + (path.isEmpty() ? "config.yml" : path), "&7Some settings need a restart to apply"));
        p.openInventory(g.inv);
    }

    // ---------- /settingmn : change /sell and /shop prices ----------
    private final Map<UUID, Boolean> priceShopMode = new HashMap<>();   // false = sell prices, true = shop prices
    private final Map<UUID, String> priceSearch = new HashMap<>();

    void openPriceMgr(Player p, int page) {
        UUID id = p.getUniqueId();
        boolean shop = priceShopMode.getOrDefault(id, false);
        String f = priceSearch.getOrDefault(id, "").toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Material> icons = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        if (!shop) {
            for (Material m : allItems()) if (f.isEmpty() || m.name().contains(f)) { icons.add(m); keys.add(m.name()); }
        } else {
            ConfigurationSection si = getConfig().getConfigurationSection("shop-items");
            if (si != null) for (String cat : si.getKeys(false)) {
                ConfigurationSection cs = si.getConfigurationSection(cat);
                if (cs == null) continue;
                for (String key : cs.getKeys(false)) {
                    Material m = isSetKey(key)
                            ? Material.matchMaterial(key.substring(0, key.length() - "_ARMOR_SET".length()) + "_CHESTPLATE")
                            : Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
                    if (m == null || !m.isItem()) continue;
                    if (!f.isEmpty() && !key.toUpperCase(Locale.ROOT).contains(f)) continue;
                    icons.add(m);
                    keys.add(cat + "|" + key);
                }
            }
        }
        int pages = Math.max(1, (icons.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("pricemgr");
        g.page = page;
        g.filter = shop ? "shop" : "sell";
        g.inv = Bukkit.createInventory(g, 54, c("&8Price Manager - " + (shop ? "Shop" : "Sell") + " (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(icons.size(), page * 45 + 45); i++) {
            Material m = icons.get(i);
            String pkey = keys.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta mt = it.getItemMeta();
            if (mt == null) continue;
            if (shop) {
                String cat = pkey.substring(0, pkey.indexOf('|'));
                String key = pkey.substring(pkey.indexOf('|') + 1);
                mt.setDisplayName(c("&f" + key + " &7[" + cat + "]"));
                mt.setLore(List.of(c("&7Shop price: &a$" + fmt(shopPrice(cat, key))), c("&eClick to change the price")));
            } else {
                mt.setLore(List.of(c("&7Sell price: &a$" + fmt(sellPrice(m))), c("&eClick to change the price")));
            }
            it.setItemMeta(mt);
            g.inv.setItem(i - page * 45, it);
            g.names.add(pkey);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(47, item(shop ? Material.CHEST : Material.GOLD_INGOT, "&6Editing: &f" + (shop ? "Shop prices" : "Sell prices"), "&7Click to switch"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Item", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a name"));
        if (!f.isEmpty()) g.inv.setItem(51, item(Material.BARRIER, "&cClear search"));
        p.openInventory(g.inv);
    }

    // text: a price (1000, 1.5k, 2m) or "reset" to go back to the default
    String applyPriceEdit(boolean shop, String pkey, String text) {
        if (text == null || text.isBlank()) return null;
        String path;
        String label;
        if (shop) {
            String cat = pkey.substring(0, pkey.indexOf('|'));
            String key = pkey.substring(pkey.indexOf('|') + 1);
            path = "prices.shop." + cat + "." + key;
            label = key;
        } else {
            path = "prices.sell." + pkey;
            label = pkey;
        }
        if (text.trim().equalsIgnoreCase("reset")) {
            data.set(path, null);
            saveData();
            return "&aPrice of &e" + label + " &areset to default";
        }
        double v = parseAmount(text.trim());
        if (v < 0 || (shop && v <= 0)) return "&cInvalid price";
        data.set(path, v);
        saveData();
        return "&aPrice of &e" + label + " &aset to &e$" + fmt(v);
    }

    // ---------- /offend + /sus ----------
    static final String[] OFFENCES = {"ESP", "AutoClicker", "HackedClient", "Cheating", "XRAY"};

    static String offenceKey(String in) { return in.toLowerCase(Locale.ROOT).replaceAll("[\\s_\\-]", ""); }

    String offenceOf(String in) {
        String k = offenceKey(in);
        for (String o : OFFENCES) if (offenceKey(o).equals(k)) return o;
        return null;
    }

    void openSus(Player p, int page) {
        List<Player> list = new ArrayList<>(Bukkit.getOnlinePlayers());
        list.remove(p);
        list.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("sus");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8Players (" + list.size() + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Player t = list.get(i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(t);
            sm.setDisplayName(c("&f" + t.getName()));
            Location tl = t.getLocation();
            sm.setLore(List.of(c("&7" + tl.getWorld().getName() + " " + tl.getBlockX() + ", " + tl.getBlockY() + ", " + tl.getBlockZ()), c("&eClick to teleport")));
            head.setItemMeta(sm);
            g.inv.setItem(i - page * 45, head);
            g.uuids.add(t.getUniqueId());
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        p.openInventory(g.inv);
    }

    // ---------- Rank permissions ----------
    private final Map<UUID, org.bukkit.permissions.PermissionAttachment> permAttach = new HashMap<>();

    // ADMIN / OWNER rank (or op / console)
    boolean isStaff(CommandSender s) {
        if (!(s instanceof Player pl)) return true;
        if (pl.hasPermission("donutsmp.admin")) return true;
        List<String> r = ranksOf(pl.getUniqueId());
        return r.contains("ADMIN") || r.contains("OWNER");
    }

    // /fly: ADMIN, OWNER and the +++ rank
    boolean canFly(Player p) {
        return isStaff(p) || ranksOf(p.getUniqueId()).contains("PLUS3");
    }

    // staff ranks get the vanilla /ban /ban-ip /pardon commands; flight is removed again when the rank is gone
    void refreshStaffPerms(Player p) {
        org.bukkit.permissions.PermissionAttachment old = permAttach.remove(p.getUniqueId());
        if (old != null) {
            try { p.removeAttachment(old); } catch (IllegalArgumentException ignored) { }
        }
        if (isStaff(p)) {
            org.bukkit.permissions.PermissionAttachment at = p.addAttachment(this);
            for (String node : List.of("minecraft.command.ban", "minecraft.command.ban-ip", "minecraft.command.pardon"))
                at.setPermission(node, true);
            permAttach.put(p.getUniqueId(), at);
        }
        GameMode gm = p.getGameMode();
        if (!canFly(p) && p.getAllowFlight() && (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE)) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
        p.updateCommands();
    }

    String rankPrefix(UUID id) {
        StringBuilder sb = new StringBuilder();
        for (String r : ranksOf(id)) sb.append(getConfig().getString("ranks." + r, ""));
        return c(sb.toString());
    }

    void updateNameTags(Scoreboard sb) {
        Objective bn = sb.getObjective("donut_money");
        for (Player t : Bukkit.getOnlinePlayers()) {
            if (bn != null) {
                Score sc = bn.getScore(t.getName());
                double bal = bal(t.getUniqueId());
                sc.setScore((int) Math.min(Integer.MAX_VALUE, bal));
                // show the money short, e.g. 10.5M instead of 10500000
                sc.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.fixed(Component.text(fmt(bal))));
            }
            String tn = "rk_" + t.getUniqueId().toString().replace("-", "").substring(0, 12);
            Team tm = sb.getTeam(tn);
            if (tm == null) tm = sb.registerNewTeam(tn);
            if (!tm.hasEntry(t.getName())) tm.addEntry(t.getName());
            tm.setPrefix(rankPrefix(t.getUniqueId()));
        }
        for (Team tm : new ArrayList<>(sb.getTeams())) {
            if (!tm.getName().startsWith("rk_")) continue;
            boolean alive = false;
            for (String en : tm.getEntries()) {
                if (Bukkit.getPlayerExact(en) != null) { alive = true; break; }
            }
            if (!alive) tm.unregister();
        }
    }

    // Chat: hover over a player's name -> click opens their stats window (with TPA / TPHERE buttons)
    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncChatEvent e) {
        Player sender = e.getPlayer();
        e.viewers().removeIf(v -> v instanceof Player r && !r.equals(sender) && !setting(r.getUniqueId(), "chat", true));
        final String pre = rankPrefix(sender.getUniqueId());
        final String pname = sender.getName();
        e.renderer((source, displayName, message, viewer) -> {
            Component name = displayName
                    .hoverEvent(HoverEvent.showText(Component.text(pname, NamedTextColor.AQUA)
                            .append(Component.newline())
                            .append(Component.text("Click to view stats", NamedTextColor.YELLOW))
                            .append(Component.newline())
                            .append(Component.text("(TPA / TPHERE available there)", NamedTextColor.GRAY))))
                    .clickEvent(ClickEvent.runCommand("/stats " + pname));
            Component out = Component.empty();
            if (!pre.isEmpty()) {
                out = out.append(LegacyComponentSerializer.legacySection().deserialize(pre)).append(name).append(Component.text(": "));
            } else {
                out = out.append(Component.text("<")).append(name).append(Component.text("> "));
            }
            return out.append(message.colorIfAbsent(NamedTextColor.WHITE));
        });
    }


    static class SignPrompt {
        final Location loc; final BlockData original; final Consumer<String> cb;
        SignPrompt(Location loc, BlockData original, Consumer<String> cb) { this.loc = loc; this.original = original; this.cb = cb; }
    }

    private final Map<UUID, SignPrompt> signPrompts = new HashMap<>();

    boolean signPrompt(Player p, String[] lines, Consumer<String> cb) {
        restoreSign(p.getUniqueId());
        Block base = p.getLocation().getBlock();
        World w = p.getWorld();
        int[][] offs = {{0, 2, 0}, {1, 2, 0}, {-1, 2, 0}, {0, 2, 1}, {0, 2, -1}, {0, 3, 0}, {1, 1, 0}, {-1, 1, 0}, {0, 1, 1}, {0, 1, -1}};
        Block target = null;
        for (int[] o : offs) {
            Block b = base.getRelative(o[0], o[1], o[2]);
            if (b.getY() < w.getMinHeight() || b.getY() >= w.getMaxHeight()) continue;
            if (b.isLiquid() || b.getState() instanceof TileState) continue;
            target = b;
            break;
        }
        if (target == null) { msg(p, "&cCannot open a sign here. Move to an open area and try again."); return false; }
        BlockData orig = target.getBlockData();
        target.setType(Material.OAK_SIGN, false);
        if (target.getState() instanceof Sign sign) {
            org.bukkit.block.sign.SignSide front = sign.getSide(Side.FRONT);
            for (int i = 0; i < 4; i++) front.line(i, Component.text(i < lines.length ? lines[i] : ""));
            sign.update(true, false);
            signPrompts.put(p.getUniqueId(), new SignPrompt(target.getLocation(), orig, cb));
            final Block tb = target;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                SignPrompt cur = signPrompts.get(p.getUniqueId());
                if (cur == null || !p.isOnline() || !(tb.getState() instanceof Sign s2)) return;
                p.openSign(s2, Side.FRONT);
                StringBuilder pb = new StringBuilder();
                for (int i = 1; i < lines.length; i++) {
                    String ln = lines[i];
                    if (ln == null || ln.isBlank() || ln.startsWith("^")) continue;
                    if (pb.length() > 0) pb.append(' ');
                    pb.append(ln);
                }
                if (pb.length() > 0) {
                    p.showTitle(net.kyori.adventure.title.Title.title(Component.empty(), Component.text(pb.toString(), NamedTextColor.YELLOW),
                            net.kyori.adventure.title.Title.Times.times(java.time.Duration.ZERO, java.time.Duration.ofSeconds(60), java.time.Duration.ZERO)));
                }
            }, 2L);
            return true;
        } else {
            target.setBlockData(orig, false);
            return false;
        }
    }

    void restoreSign(UUID id) {
        SignPrompt sp = signPrompts.remove(id);
        if (sp != null) {
            sp.loc.getBlock().setBlockData(sp.original, false);
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) pl.clearTitle();
        }
    }

    @EventHandler
    public void onSignChange(SignChangeEvent e) {
        SignPrompt sp = signPrompts.get(e.getPlayer().getUniqueId());
        if (sp == null || !e.getBlock().equals(sp.loc.getBlock())) return;
        e.setCancelled(true);
        e.getPlayer().clearTitle();
        String text = e.getLine(0);
        String result = text == null ? "" : text.trim();
        signPrompts.remove(e.getPlayer().getUniqueId());
        sp.loc.getBlock().setBlockData(sp.original, false);
        Bukkit.getScheduler().runTask(this, () -> sp.cb.accept(result));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID q = e.getPlayer().getUniqueId();
        e.quitMessage(Component.text(e.getPlayer().getName() + " left the game", NamedTextColor.WHITE));
        restoreSign(q);
        ItemStack pend = ahPending.remove(q);
        if (pend != null) give(e.getPlayer(), pend);
        rtpQueue.remove(q);
        combatUntil.remove(q);
        permAttach.remove(q);
    }

    // ---------- Team ----------
    void teamCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { msg(p, "&e/team create <name> | invite <player> | accept | leave | info"); return; }
        String cur = data.getString("playerTeam." + id);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (cur != null) { msg(p, "&cYou are already in a team"); return; }
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_]{2,12}")) { msg(p, "&e/team create <name> &7(A-Z 0-9 _ , 2-12 characters)"); return; }
                String key = a[1].toLowerCase(Locale.ROOT);
                if (data.contains("teams." + key)) { msg(p, "&cThat team name is already taken"); return; }
                data.set("teams." + key + ".name", a[1]);
                data.set("teams." + key + ".leader", id.toString());
                data.set("teams." + key + ".members", new ArrayList<>(List.of(id.toString())));
                data.set("playerTeam." + id, key);
                msg(p, "&aCreated team &e" + a[1]);
            }
            case "invite" -> {
                if (cur == null) { msg(p, "&cYou are not in a team"); return; }
                if (a.length < 2) { msg(p, "&e/team invite <player>"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null || t == p) { msg(p, "&cPlayer not found"); return; }
                if (data.getString("playerTeam." + t.getUniqueId()) != null) { msg(p, "&cThat player already has a team"); return; }
                teamInvites.put(t.getUniqueId(), cur);
                msg(p, "&aInvited &e" + t.getName());
                msg(t, "&e" + p.getName() + " &finvited you to team &e" + teamName(id) + " &7- type &a/team accept");
            }
            case "accept" -> {
                String key = teamInvites.remove(id);
                if (key == null || !data.contains("teams." + key)) { msg(p, "&cNo pending invite"); return; }
                if (cur != null) { msg(p, "&cYou are already in a team"); return; }
                List<String> members = data.getStringList("teams." + key + ".members");
                if (members.size() >= getConfig().getInt("team.max-members", 5)) { msg(p, "&cThe team is full"); return; }
                members.add(id.toString());
                data.set("teams." + key + ".members", members);
                data.set("playerTeam." + id, key);
                msg(p, "&aJoined team &e" + data.getString("teams." + key + ".name"));
            }
            case "leave" -> {
                if (cur == null) { msg(p, "&cYou are not in a team"); return; }
                List<String> members = data.getStringList("teams." + cur + ".members");
                if (id.toString().equals(data.getString("teams." + cur + ".leader"))) {
                    for (String m : members) data.set("playerTeam." + m, null);
                    data.set("teams." + cur, null);
                    msg(p, "&eYou were the leader, so the team was disbanded");
                } else {
                    members.remove(id.toString());
                    data.set("teams." + cur + ".members", members);
                    data.set("playerTeam." + id, null);
                    msg(p, "&eYou left the team");
                }
            }
            case "info" -> {
                if (cur == null) { msg(p, "&cYou are not in a team"); return; }
                String names = data.getStringList("teams." + cur + ".members").stream()
                        .map(u -> Optional.ofNullable(Bukkit.getOfflinePlayer(UUID.fromString(u)).getName()).orElse("?"))
                        .collect(Collectors.joining(", "));
                msg(p, "&eTeam &f" + teamName(id) + " &7| Members: &f" + names);
            }
            default -> msg(p, "&e/team create | invite | accept | leave | info");
        }
    }

    // ---------- /shop ----------
    // ---------- /shop : one big paged page, black glass = slots staff can fill with any item ----------
    private static final int[] SHOP_NAV = {45, 48, 49, 50};   // 45 = buy amount, 48 = previous, 49 = search, 50 = next
    private static final int SHOP_PER_PAGE = 50;
    private static final Map<Integer, String> SHOP_LAYOUT0 = new HashMap<>();
    private static final List<Integer> SHOP_SLOTS = new ArrayList<>();
    static {
        // first page, laid out like the screenshot; every cell that is not listed is a black glass slot staff can fill
        String[] lay = {
            "1 gear|DIAMOND_HELMET", "2 all-pvp|GOLDEN_APPLE", "3 all-pvp|ENDER_PEARL", "4 resources|PHANTOM_MEMBRANE",
            "5 all-pvp|COBWEB", "6 resources|BLAZE_ROD", "8 blocks|OBSIDIAN",
            "10 gear|DIAMOND_CHESTPLATE", "11 food|GOLDEN_CARROT", "12 all-pvp|FLINT_AND_STEEL", "13 food|BREAD",
            "14 food|COOKED_BEEF", "15 all-pvp|EXPERIENCE_BOTTLE", "16 blocks|SPONGE", "17 all-pvp|END_CRYSTAL",
            "19 gear|DIAMOND_LEGGINGS", "20 food|APPLE", "21 resources|SHULKER_SHELL", "22 food|BAKED_POTATO",
            "23 all-pvp|SPECTRAL_ARROW", "24 all-pvp|RESPAWN_ANCHOR", "25 blocks|SHULKER_BOX", "26 blocks|CRYING_OBSIDIAN",
            "28 gear|DIAMOND_BOOTS", "29 food|COOKED_PORKCHOP", "33 all-pvp|FIREWORK_ROCKET", "34 blocks|ENDER_CHEST", "35 blocks|GLOWSTONE",
            "37 gear|DIAMOND_SWORD", "38 all-pvp|WATER_BUCKET", "42 all-pvp|TNT", "43 all-pvp|TOTEM_OF_UNDYING", "44 gear|ELYTRA",
            "46 gear|TRIDENT", "47 all-pvp|LAVA_BUCKET", "51 gear|DIAMOND_PICKAXE", "52 gear|DIAMOND_PICKAXE:SILK_TOUCH", "53 gear|DIAMOND_AXE"
        };
        for (String ln : lay) SHOP_LAYOUT0.put(Integer.parseInt(ln.substring(0, ln.indexOf(' '))), ln.substring(ln.indexOf(' ') + 1));
        for (int i = 0; i < 54; i++) {
            boolean nav = false;
            for (int n : SHOP_NAV) if (n == i) nav = true;
            if (!nav) SHOP_SLOTS.add(i);
        }
    }
    private final Map<UUID, String> shopSearch = new HashMap<>();
    private final Map<UUID, String> shopPickSearch = new HashMap<>();

    static boolean inArr(int[] arr, int v) {
        for (int x : arr) if (x == v) return true;
        return false;
    }

    // entries that are not on the first page, they fill the next pages in order
    List<String> shopOverflow() {
        Set<String> placed = new HashSet<>(SHOP_LAYOUT0.values());
        List<String> out = new ArrayList<>();
        for (String en : shopEntries("")) if (!placed.contains(en)) out.add(en);
        return out;
    }

    // what sits in one slot: "cfg:category|key", "cus:MATERIAL|quantity" or null (black glass)
    String shopSlotContent(int page, int slot, List<String> overflow) {
        String b = "shopslots." + page + "." + slot;
        String cm = data.getString(b + ".item");
        if (cm != null) return cm.equals("NONE") ? null : "cus:" + cm + "|" + data.getInt(b + ".qty", 1);
        if (page == 0) {
            String d = SHOP_LAYOUT0.get(slot);
            return d == null ? null : "cfg:" + d;
        }
        int idx = (page - 1) * SHOP_PER_PAGE + SHOP_SLOTS.indexOf(slot);
        return idx >= 0 && idx < overflow.size() ? "cfg:" + overflow.get(idx) : null;
    }

    int shopMaxPage(List<String> overflow) {
        int max = overflow.isEmpty() ? 0 : (overflow.size() - 1) / SHOP_PER_PAGE + 1;
        ConfigurationSection cs = data.getConfigurationSection("shopslots");
        if (cs != null) for (String k : cs.getKeys(false)) {
            try { max = Math.max(max, Integer.parseInt(k)); } catch (NumberFormatException ignored) { }
        }
        return max;
    }

    // every shop entry as "category|key", categories in menu order, cheapest first inside a category
    List<String> shopEntries(String f) {
        List<String> out = new ArrayList<>();
        ConfigurationSection si = getConfig().getConfigurationSection("shop-items");
        if (si == null) return out;
        List<String> cats = new ArrayList<>();
        for (Map<?, ?> m : getConfig().getMapList("shop-menu.categories")) cats.add(String.valueOf(m.get("id")));
        for (String k : si.getKeys(false)) if (!cats.contains(k)) cats.add(k);
        for (String cat : cats) {
            ConfigurationSection cs = si.getConfigurationSection(cat);
            if (cs == null) continue;
            List<String> keys = new ArrayList<>(cs.getKeys(false));
            keys.sort((x, y) -> { int cmp = Double.compare(shopPrice(cat, x), shopPrice(cat, y)); return cmp != 0 ? cmp : x.compareTo(y); });
            for (String key : keys) {
                if (!f.isEmpty() && !key.toUpperCase(Locale.ROOT).contains(f)) continue;
                out.add(cat + "|" + key);
            }
        }
        return out;
    }

    ItemStack shopEntryItem(String cat, String key, int qty) {
        double price = shopPrice(cat, key);
        if (price < 0) return null;
        if (isSetKey(key)) {
            String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
            Material icon = Material.matchMaterial(tier + "_CHESTPLATE");
            if (icon == null) return null;
            String nm = tier.substring(0, 1) + tier.substring(1).toLowerCase(Locale.ROOT);
            return item(icon, tierName(price).substring(0, 2) + "Full " + nm + " Armor Set",
                    "&7Tier: " + tierName(price), "&7Price: &a$" + fmt(price), "&7Includes all 4 pieces", "&eClick to buy");
        }
        Material m = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
        if (m == null || !m.isItem()) return null;
        ItemStack it = new ItemStack(m);
        List<String> ench = getConfig().getStringList("shop-enchants." + key);
        boolean enchanted = !ench.isEmpty();
        int shown = enchanted ? 1 : qty;
        if (enchanted) applyEnchants(it, ench);
        ItemMeta meta = it.getItemMeta();
        meta.setLore(List.of(c("&7Tier: " + tierName(price)), c("&7Price: &a$" + fmt(price) + " &7each"),
                c("&7Total for " + shown + ": &a$" + fmt(price * shown)), c("&eClick to buy " + shown)));
        it.setItemMeta(meta);
        return it;
    }

    void buyShopEntry(Player p, String cat, String key) {
        UUID pid = p.getUniqueId();
        double price = shopPrice(cat, key);
        if (price < 0) return;
        if (isSetKey(key)) {
            String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
            if (!take(pid, price)) { msg(p, "&cNot enough money (need $" + fmt(price) + ")"); return; }
            giveArmorSet(p, tier);
            msg(p, pretty(Material.matchMaterial(tier + "_CHESTPLATE")).replace(" Chestplate", "") + " Armor Set for $" + fmt(price));
            return;
        }
        String variant = key.contains(":") ? key.substring(key.indexOf(':') + 1) : null;
        Material sm = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
        if (sm == null) return;
        List<String> ench = getConfig().getStringList("shop-enchants." + key);
        int amt = ench.isEmpty() ? shopQty.getOrDefault(pid, 1) : 1;
        double total = price * amt;
        if (!take(pid, total)) { msg(p, "&cNot enough money (need $" + fmt(total) + ")"); return; }
        ItemStack bought = new ItemStack(sm, amt);
        if (!ench.isEmpty()) applyEnchants(bought, ench);
        give(p, bought);
        msg(p, (variant != null ? variantName(variant) + " " : "") + pretty(sm) + (amt > 1 ? " x" + amt : "") + " for $" + fmt(total));
    }

    void openShop(Player p) { openShopPage(p, 0); }

    ItemStack shopContentItem(String ct, int qty, boolean staff) {
        String body = ct.substring(4);
        ItemStack it;
        if (ct.startsWith("cfg:")) {
            it = shopEntryItem(body.substring(0, body.indexOf('|')), body.substring(body.indexOf('|') + 1), qty);
        } else {
            Material cm = Material.matchMaterial(body.substring(0, body.indexOf('|')));
            if (cm == null || !cm.isItem()) return null;
            int cq = 1;
            try { cq = Math.max(1, Integer.parseInt(body.substring(body.indexOf('|') + 1))); } catch (NumberFormatException ignored) { }
            double unit = sellPrice(cm);
            it = new ItemStack(cm, Math.min(cq, cm.getMaxStackSize()));
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7Price: &a$" + fmt(unit) + " &7each"), c("&7Quantity: &f" + cq),
                    c("&7Total: &a$" + fmt(unit * cq)), c("&eClick to buy")));
            it.setItemMeta(mt);
        }
        if (it != null && staff) {
            ItemMeta m2 = it.getItemMeta();
            List<String> lo = m2.getLore() == null ? new ArrayList<>() : new ArrayList<>(m2.getLore());
            lo.add(c("&6Shift-click to change this slot"));
            m2.setLore(lo);
            it.setItemMeta(m2);
        }
        return it;
    }

    String shopContentName(String ct) {
        String body = ct.substring(4);
        String n = ct.startsWith("cfg:") ? body.substring(body.indexOf('|') + 1) : body.substring(0, body.indexOf('|'));
        return n.toUpperCase(Locale.ROOT);
    }

    void buyShopCustom(Player p, String ct) {
        String body = ct.substring(4);
        Material cm = Material.matchMaterial(body.substring(0, body.indexOf('|')));
        if (cm == null) return;
        int cq = 1;
        try { cq = Math.max(1, Integer.parseInt(body.substring(body.indexOf('|') + 1))); } catch (NumberFormatException ignored) { }
        double total = sellPrice(cm) * cq;
        if (total <= 0) return;
        if (!take(p.getUniqueId(), total)) { msg(p, "&cNot enough money (need $" + fmt(total) + ")"); return; }
        int left = cq;
        while (left > 0) {
            int n = Math.min(left, cm.getMaxStackSize());
            give(p, new ItemStack(cm, n));
            left -= n;
        }
        msg(p, pretty(cm) + (cq > 1 ? " x" + cq : "") + " for $" + fmt(total));
    }

    void openShopPage(Player p, int page) {
        UUID id = p.getUniqueId();
        boolean staff = isStaff(p);
        String f = shopSearch.getOrDefault(id, "").toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<String> overflow = shopOverflow();
        int maxPage = shopMaxPage(overflow);
        int qty = shopQty.getOrDefault(id, 1);
        Gui g = new Gui("shop");
        g.filter = f;
        int pages;
        if (f.isEmpty()) {
            boolean full = true;
            for (int sl : SHOP_SLOTS) if (shopSlotContent(maxPage, sl, overflow) == null) { full = false; break; }
            pages = maxPage + 1 + (staff && full ? 1 : 0);
            page = Math.max(0, Math.min(page, pages - 1));
            g.page = page;
            g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-menu.title", "&8SHOP") + (pages > 1 ? " &7(" + (page + 1) + "/" + pages + ")" : "")));
            for (int sl : SHOP_SLOTS) {
                String ct = shopSlotContent(page, sl, overflow);
                ItemStack it = ct == null ? null : shopContentItem(ct, qty, staff);
                if (it == null) {
                    g.inv.setItem(sl, staff ? item(Material.BLACK_STAINED_GLASS_PANE, "&7Empty Slot", "&eClick to choose an item")
                            : item(Material.BLACK_STAINED_GLASS_PANE, " "));
                    g.names.add("empty");
                } else {
                    g.inv.setItem(sl, it);
                    g.names.add(ct);
                }
                g.slotIdx.put(sl, g.names.size() - 1);
            }
        } else {
            List<String> matches = new ArrayList<>();
            for (int pg = 0; pg <= maxPage; pg++) {
                for (int sl : SHOP_SLOTS) {
                    String ct = shopSlotContent(pg, sl, overflow);
                    if (ct != null && shopContentName(ct).contains(f)) matches.add(ct);
                }
            }
            pages = Math.max(1, (matches.size() + SHOP_PER_PAGE - 1) / SHOP_PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
            g.page = page;
            g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-menu.title", "&8SHOP") + " &7- " + f + (pages > 1 ? " (" + (page + 1) + "/" + pages + ")" : "")));
            int pos = 0;
            for (int i = page * SHOP_PER_PAGE; i < Math.min(matches.size(), page * SHOP_PER_PAGE + SHOP_PER_PAGE); i++) {
                ItemStack it = shopContentItem(matches.get(i), qty, false);
                if (it == null) continue;
                int sl = SHOP_SLOTS.get(pos++);
                g.inv.setItem(sl, it);
                g.slotIdx.put(sl, g.names.size());
                g.names.add(matches.get(i));
            }
        }
        if (page > 0) g.inv.setItem(48, item(Material.ARROW, "&e\u00ab Previous page"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type an item name", "&7(empty = show all)"));
        if (page < pages - 1) g.inv.setItem(50, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(45, item(Material.HOPPER, "&eBuy amount: &f" + qty, "&7Click to change (1 / 16 / 64)"));
        p.openInventory(g.inv);
    }

    // staff: choose the item (and quantity) of one slot of the shop
    void openShopPick(Player p, int shopPage, int shopSlot, int page) {
        UUID id = p.getUniqueId();
        String f = shopPickSearch.getOrDefault(id, "").toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Material> list = allItems().stream().filter(m -> f.isEmpty() || m.name().contains(f)).collect(Collectors.toList());
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("shoppick");
        g.page = page;
        g.counts.add(shopPage);
        g.counts.add(shopSlot);
        g.inv = Bukkit.createInventory(g, 54, c("&8Choose an item for this slot (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Material m = list.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta mt = it.getItemMeta();
            if (mt != null) { mt.setLore(List.of(c("&7Price: &a$" + fmt(sellPrice(m)) + " &7each"), c("&eClick to choose this item"))); it.setItemMeta(mt); }
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(46, item(Material.BLACK_STAINED_GLASS_PANE, "&7Make this slot empty", "&7The slot becomes black glass"));
        if (data.getString("shopslots." + shopPage + "." + shopSlot + ".item") != null)
            g.inv.setItem(47, item(Material.BARRIER, "&cReset this slot", "&7Back to the default of this slot"));
        g.inv.setItem(48, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Item", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a name"));
        p.openInventory(g.inv);
    }

    void openShopCategory(Player p, String id) {
        int qty = shopQty.getOrDefault(p.getUniqueId(), 1);
        Gui g = new Gui("shopcat");
        g.filter = id;
        g.inv = Bukkit.createInventory(g, 54, c("&8SHOP - " + id.toUpperCase(Locale.ROOT)));
        ConfigurationSection s = getConfig().getConfigurationSection("shop-items." + id);
        if (s != null) {
            // cheapest first -> most expensive last, so similar tiers sit together
            List<String> keys = new ArrayList<>(s.getKeys(false));
            keys.sort((x, y) -> { int cmp = Double.compare(shopPrice(id, x), shopPrice(id, y)); return cmp != 0 ? cmp : x.compareTo(y); });
            for (String key : keys) {
                if (g.names.size() >= 45) break;
                double price = shopPrice(id, key);
                ItemStack it;
                if (isSetKey(key)) {
                    String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
                    Material icon = Material.matchMaterial(tier + "_CHESTPLATE");
                    if (icon == null) continue;
                    String nm = tier.substring(0, 1) + tier.substring(1).toLowerCase(Locale.ROOT);
                    it = item(icon, tierName(price).substring(0, 2) + "Full " + nm + " Armor Set",
                            "&7Tier: " + tierName(price), "&7Price: &a$" + fmt(price), "&7Includes all 4 pieces", "&eClick to buy");
                } else {
                    Material m = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
                    if (m == null || !m.isItem()) continue;
                    it = new ItemStack(m);
                    List<String> ench = getConfig().getStringList("shop-enchants." + key);
                    boolean enchanted = !ench.isEmpty();
                    int shown = enchanted ? 1 : qty;
                    if (enchanted) applyEnchants(it, ench);
                    ItemMeta meta = it.getItemMeta();
                    meta.setLore(List.of(c("&7Tier: " + tierName(price)), c("&7Price: &a$" + fmt(price) + " &7each"),
                            c("&7Total for " + shown + ": &a$" + fmt(price * shown)), c("&eClick to buy " + shown)));
                    it.setItemMeta(meta);
                }
                g.inv.setItem(g.names.size(), it);
                g.names.add(key);
            }
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.HOPPER, "&eBuy amount: &f" + qty, "&7Click to change (1 / 16 / 64)"));
        for (int i = 45; i < 54; i++) if (g.inv.getItem(i) == null) g.inv.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, " "));
        p.openInventory(g.inv);
    }


    private static final int SELL_BTN = 53;

    void openSell(Player p) {
        Gui g = new Gui("sell");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("sell-title")));
        refreshSellButton(g);
        p.openInventory(g.inv);
    }

    // the green glass: hover = total price of the items in the window, click = sell them
    void refreshSellButton(Gui g) {
        double total = 0;
        long n = 0;
        for (int i = 0; i < g.inv.getSize(); i++) {
            if (i == SELL_BTN) continue;
            ItemStack it = g.inv.getItem(i);
            if (it == null || it.getType().isAir()) continue;
            total += sellPrice(it.getType()) * it.getAmount();
            n += it.getAmount();
        }
        g.inv.setItem(SELL_BTN, item(Material.LIME_STAINED_GLASS_PANE, "&aSell Items", "&7Items: &f" + n, "&7Total price: &a$" + fmt(total), "", "&eClick to sell"));
    }

    void sellContents(Player p, Gui g, boolean warn) {
        double total = 0;
        long sold = 0;
        for (int i = 0; i < g.inv.getSize(); i++) {
            if (i == SELL_BTN) continue;
            ItemStack it = g.inv.getItem(i);
            if (it == null || it.getType().isAir()) continue;
            double price = sellPrice(it.getType());
            if (price > 0) { total += price * it.getAmount(); sold += it.getAmount(); }
            else give(p, it);
            g.inv.setItem(i, null);
        }
        if (total > 0) {
            add(p.getUniqueId(), total);
            msg(p, "&aSold " + sold + " items for &e$" + fmt(total));
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        } else if (warn && sold == 0) {
            msg(p, "&cPlace the items you want to sell first");
        }
    }

    private final Map<UUID, Integer> shopQty = new HashMap<>();
    private final Map<UUID, Integer> ahSort = new HashMap<>();
    private final Map<UUID, String> ahSearch = new HashMap<>();
    private final Map<UUID, ItemStack> ahPending = new HashMap<>();

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        Player p = (Player) e.getPlayer();
        if (g.type.equals("orderdeposit")) { handleDeposit(p, g); return; }
        if (g.type.equals("ahsell")) {
            if (!"done".equals(g.filter)) {
                ItemStack back = e.getInventory().getItem(13);
                if (back != null && !back.getType().isAir()) give(p, back);
            }
            e.getInventory().clear();
            return;
        }
        if (!g.type.equals("sell")) return;
        e.getInventory().setItem(SELL_BTN, null);
        sellContents(p, g, false);
    }

    // ---------- /order ----------
    void orderCmd(Player p, String[] a) {
        if (a.length == 0) { openOrders(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 4) { msg(p, "&e/order create <item> <amount> <price per piece>"); return; }
                Material m = Material.matchMaterial(a[1]);
                int amt;
                try { amt = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { amt = -1; }
                double price = parseAmount(a[3]);
                if (m == null || !m.isItem() || amt <= 0 || price <= 0) { msg(p, "&cInvalid input"); return; }
                double cost = amt * price;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cNot enough money (need $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, amt, price));
                msg(p, "&aBuy order created: " + m.name() + " x" + amt + " at $" + fmt(price) + " each");
            }
            case "claim" -> {
                Map<String, Integer> map = claims.remove(p.getUniqueId());
                if (map == null || map.isEmpty()) { msg(p, "&cNothing to claim"); return; }
                map.forEach((mat, n) -> {
                    Material m = Material.matchMaterial(mat);
                    if (m == null) return;
                    int left = n;
                    while (left > 0) {
                        int st = Math.min(left, m.getMaxStackSize());
                        give(p, new ItemStack(m, st));
                        left -= st;
                    }
                });
                msg(p, "&aClaimed items from your orders");
            }
            default -> openOrders(p);
        }
    }

    void openOrders(Player p) { openOrders(p, 0); }

    void openOrders(Player p, int page) {
        UUID pid = p.getUniqueId();
        int mode = orderSort.getOrDefault(pid, 0);
        String q = orderSearch.get(pid);
        String qf = q == null ? "" : q.toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Order> active = orders.stream().filter(o -> o.left > 0)
                .filter(o -> qf.isEmpty() || o.mat.name().contains(qf)).collect(Collectors.toList());
        List<Double> prices = active.stream().map(o -> o.price).sorted().collect(Collectors.toList());
        final double med = prices.isEmpty() ? 0 : prices.get(prices.size() / 2);
        if (mode == 0) active.sort((x, y) -> Double.compare(y.price, x.price));
        else if (mode == 1) active.sort(Comparator.comparingDouble(o -> Math.abs(o.price - med)));
        else active.sort(Comparator.comparingDouble(o -> o.price));
        int pages = Math.max(1, (active.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("orders");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8" + getConfig().getString("order-title", "Orders") + " (Page " + (page + 1) + ")"));
        for (int i = page * 45; i < Math.min(active.size(), page * 45 + 45); i++) {
            Order o = active.get(i);
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            String owner = Optional.ofNullable(Bukkit.getOfflinePlayer(o.owner).getName()).orElse("?");
            meta.setLore(List.of(
                    c("&7Ordered by: &f" + owner),
                    c("&7Still needed: &f" + o.left),
                    c("&7Price per piece: &a$" + fmt(o.price)),
                    c(o.owner.equals(pid) ? "&eClick to manage your order" : "&aClick to deliver items to this order")));
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        String[] modes = {"Highest price", "Median price", "Lowest price"};
        String[] sortLore = new String[4];
        for (int i = 0; i < 3; i++) sortLore[i] = (i == mode ? "&a\u25b6 " : "&7  ") + modes[i];
        sortLore[3] = "&eClick to change";
        g.inv.setItem(47, item(Material.HOPPER, "&eSort", sortLore));
        g.inv.setItem(48, item(Material.AMETHYST_SHARD, "&dShard Shop", "&7Click to open the Shard Shop"));
        g.inv.setItem(49, item(Material.BOOK, "&aCreate New Order", "&7Pick an item, then set the amount and price"));
        g.inv.setItem(50, item(Material.OAK_SIGN, "&eSearch", "&7Current: &f" + (qf.isEmpty() ? "All" : qf), "&7Click to type an item name"));
        g.inv.setItem(51, item(Material.CHEST, "&6My Orders", "&7View delivered items / cancel orders"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        p.openInventory(g.inv);
    }

    void openMyOrders(Player p) {
        Gui g = new Gui("myorders");
        g.inv = Bukkit.createInventory(g, 54, c("&8My Orders"));
        for (Order o : orders) {
            if (!o.owner.equals(p.getUniqueId())) continue;
            if (g.orders.size() >= 45) break;
            ItemStack it = new ItemStack(o.mat);
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7Still needed: &f" + o.left), c("&7Price per piece: &a$" + fmt(o.price)),
                    c("&7Delivered: &f" + o.delivered), c("&eClick to manage")));
            it.setItemMeta(mt);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void openOrderManage(Player p, Order o) {
        Gui g = new Gui("ordermanage");
        g.ord = o;
        g.inv = Bukkit.createInventory(g, 27, c("&8Manage Order"));
        ItemStack it = new ItemStack(o.mat);
        ItemMeta mt = it.getItemMeta();
        mt.setLore(List.of(c("&7Still needed: &f" + o.left), c("&7Price per piece: &a$" + fmt(o.price)), c("&7Delivered: &f" + o.delivered)));
        it.setItemMeta(mt);
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cBack", "&7Go back to My Orders"));
        g.inv.setItem(13, it);
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aCancel Order & Collect",
                "&7Refund for the rest: &a$" + fmt(o.left * o.price), "&7Delivered items: &f" + o.delivered));
        g.inv.setItem(22, item(Material.CHEST, "&bView Delivered Items", "&7Take items one stack at a time"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void cancelOrder(Player p, Order o) {
        if (!orders.contains(o)) { openMyOrders(p); return; }
        if (o.left > 0) {
            double refund = o.left * o.price;
            add(p.getUniqueId(), refund);
            msg(p, "&eOrder cancelled. Refunded &a$" + fmt(refund));
            o.left = 0;
        }
        int got = takeDelivered(p, o, Integer.MAX_VALUE);
        if (got > 0) msg(p, "&aCollected " + got + " items");
        if (o.delivered <= 0) orders.remove(o);
        else msg(p, "&eYour inventory is full. Open the order again to collect the rest.");
        openMyOrders(p);
    }

    void openOrderClaim(Player p, Order o) {
        Gui g = new Gui("orderclaim");
        g.ord = o;
        g.inv = Bukkit.createInventory(g, 54, c("&8Delivered: " + o.mat.name()));
        int rem = o.delivered;
        int slot = 0;
        while (rem > 0 && slot < 45) {
            int n = Math.min(rem, o.mat.getMaxStackSize());
            ItemStack it = new ItemStack(o.mat, n);
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&eClick to take")));
            it.setItemMeta(mt);
            g.inv.setItem(slot++, it);
            rem -= n;
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.LIME_STAINED_GLASS_PANE, "&aCollect All", "&7Total: &f" + o.delivered));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    int takeDelivered(Player p, Order o, int want) {
        want = Math.min(want, o.delivered);
        int given = 0;
        while (given < want) {
            int st = Math.min(want - given, o.mat.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(o.mat, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        o.delivered -= given;
        if (o.delivered <= 0 && o.left <= 0) orders.remove(o);
        return given;
    }

    void openOrderDeposit(Player p, Order o) {
        Gui g = new Gui("orderdeposit");
        g.ord = o;
        g.inv = Bukkit.createInventory(g, 54, c("&8Deliver " + o.mat.name() + " ($" + fmt(o.price) + " each)"));
        p.openInventory(g.inv);
        msg(p, "&ePlace &f" + o.mat.name() + " &ein the window and close it to deliver (paid instantly at $" + fmt(o.price) + " each)");
    }

    void handleDeposit(Player p, Gui g) {
        Order o = g.ord;
        boolean valid = o != null && orders.contains(o) && o.left > 0;
        int total = 0;
        List<ItemStack> back = new ArrayList<>();
        for (ItemStack it : g.inv.getContents()) {
            if (it == null || it.getType().isAir()) continue;
            if (valid && it.getType() == o.mat && !it.hasItemMeta()) total += it.getAmount(); else back.add(it);
        }
        g.inv.clear();
        if (valid && total > 0) {
            int accept = Math.min(total, o.left);
            int excess = total - accept;
            o.left -= accept;
            o.delivered += accept;
            double pay = accept * o.price;
            add(p.getUniqueId(), pay);
            while (excess > 0) {
                int st = Math.min(excess, o.mat.getMaxStackSize());
                give(p, new ItemStack(o.mat, st));
                excess -= st;
            }
            msg(p, "You delivered " + accept + " " + pretty(o.mat) + " and received $" + fmt(pay));
            Player owner = Bukkit.getPlayer(o.owner);
            if (owner != null) msg(owner, "&aSomeone delivered " + o.mat.name() + " x" + accept + " to your order! Open /order > My Orders to collect.");
        }
        back.forEach(it -> give(p, it));
    }

    private List<Material> itemList;

    List<Material> allItems() {
        if (itemList == null) itemList = Arrays.stream(Material.values())
                .filter(m -> !m.isLegacy() && m.isItem() && !m.isAir())
                .sorted(Comparator.comparing(Enum::name)).collect(Collectors.toList());
        return itemList;
    }

    void openOrderPick(Player p, int page, String filter) {
        String f = filter == null ? "" : filter.toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Material> list = allItems().stream().filter(m -> f.isEmpty() || m.name().contains(f)).collect(Collectors.toList());
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("orderpick");
        g.page = page;
        g.filter = filter;
        g.inv = Bukkit.createInventory(g, 54, c("&8Choose an item to buy (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Material m = list.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta mt = it.getItemMeta();
            if (mt != null) { mt.setLore(List.of(c("&eClick to choose this item"))); it.setItemMeta(mt); }
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(48, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Item", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a name"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void startOrderCreate(Player p, Material m) {
        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Enter the amount", "received"}, priceText -> {
            double pr = parseAmount(priceText);
            if (pr <= 0) { msg(p, "&cInvalid price"); return; }
            signPrompt(p, new String[]{"", "Enter the", "quantity you wish", "to purchase"}, qtyText -> {
                double q = parseAmount(qtyText);
                int n = (int) Math.min(q, 2_000_000_000d);
                if (n <= 0) { msg(p, "&cInvalid amount"); return; }
                double cost = n * pr;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cNot enough money (need $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, n, pr));
                msg(p, "&aBuy order created: " + m.name() + " x" + n + " at $" + fmt(pr) + " each (charged $" + fmt(cost) + ")");
                openOrders(p, 0);
            });
        });
    }

    // ---------- /ah ----------
    void ahCmd(Player p, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("sell")) {
            if (a.length < 2) { msg(p, "&e/ah sell <price> &7(hold the item you want to sell)"); return; }
            double price = parseAmount(a[1]);
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (price <= 0) { msg(p, "&cInvalid price"); return; }
            if (hand == null || hand.getType().isAir()) { msg(p, "&cHold the item you want to sell"); return; }
            if (!canList(p)) return;
            listings.add(new Listing(nextListingId++, p.getUniqueId(), hand.clone(), price, System.currentTimeMillis()));
            p.getInventory().setItemInMainHand(null);
            msg(p, "You listen " + hand.getAmount() + " " + goodName(hand) + " for $" + fmt(price));
            return;
        }
        openAh(p, 0);
    }

    boolean canList(Player p) {
        long mine = listings.stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
        int max = getConfig().getInt("ah.max-listings", 10);
        if (mine >= max) { msg(p, "&cYou can have at most " + max + " listings"); return false; }
        return true;
    }

    void openAh(Player p, int page) {
        UUID pid = p.getUniqueId();
        int mode = ahSort.getOrDefault(pid, 0);
        String q = ahSearch.get(pid);
        String qf = q == null ? "" : q.toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Listing> sorted = listings.stream()
                .filter(l -> qf.isEmpty() || l.item.getType().name().contains(qf)).collect(Collectors.toList());
        if (mode == 0) sorted.sort((x, y) -> Long.compare(y.time, x.time));
        else if (mode == 1) sorted.sort(Comparator.comparingDouble(l -> l.price));
        else sorted.sort((x, y) -> Double.compare(y.price, x.price));
        int pages = Math.max(1, (sorted.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("ah");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&6&lAuction House &7(" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(sorted.size(), page * 45 + 45); i++) {
            Listing l = sorted.get(i);
            g.inv.setItem(g.shown.size(), listingIcon(l, pid));
            g.shown.add(l);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        String[] modes = {"Newest first", "Lowest price", "Highest price"};
        String[] sortLore = new String[4];
        for (int i = 0; i < 3; i++) sortLore[i] = (i == mode ? "&a\u25b6 " : "&7  ") + modes[i];
        sortLore[3] = "&eClick to change";
        g.inv.setItem(47, item(Material.HOPPER, "&eSort", sortLore));
        g.inv.setItem(48, item(Material.CLOCK, "&bRefresh", "&7Reload the listings"));
        g.inv.setItem(49, item(Material.BOOK, "&aSell Item", "&7Put an item in the window and set a price"));
        g.inv.setItem(50, item(Material.OAK_SIGN, "&eSearch", "&7Current: &f" + (qf.isEmpty() ? "All" : qf), "&7Click to type an item name"));
        g.inv.setItem(51, item(Material.CHEST, "&6My Listings", "&7View or take back your listings"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        p.openInventory(g.inv);
    }

    ItemStack listingIcon(Listing l, UUID viewer) {
        ItemStack d = l.item.clone();
        ItemMeta m = d.getItemMeta();
        List<String> lore = m.hasLore() && m.getLore() != null ? new ArrayList<>(m.getLore()) : new ArrayList<>();
        lore.add(c("&8\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"));
        lore.add(c("&7Price: &a$" + fmt(l.price)));
        lore.add(c("&7Seller: &f" + Optional.ofNullable(Bukkit.getOfflinePlayer(l.seller).getName()).orElse("?")));
        lore.add(c(l.seller.equals(viewer) ? "&eYour listing - click to manage" : "&aClick to buy"));
        m.setLore(lore);
        d.setItemMeta(m);
        return d;
    }

    void openAhMy(Player p) {
        Gui g = new Gui("ahmy");
        g.inv = Bukkit.createInventory(g, 54, c("&8My Listings"));
        for (Listing l : listings) {
            if (!l.seller.equals(p.getUniqueId())) continue;
            if (g.shown.size() >= 45) break;
            g.inv.setItem(g.shown.size(), listingIcon(l, p.getUniqueId()));
            g.shown.add(l);
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void openAhManage(Player p, Listing l) {
        Gui g = new Gui("ahmanage");
        g.shown.add(l);
        g.inv = Bukkit.createInventory(g, 27, c("&8Manage Listing"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cBack", "&7Go back to My Listings"));
        g.inv.setItem(13, listingIcon(l, p.getUniqueId()));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aTake Back", "&7Remove the listing and get the item back"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void openAhSell(Player p) {
        Gui g = new Gui("ahsell");
        g.inv = Bukkit.createInventory(g, 27, c("&8Sell Item"));
        g.inv.setItem(4, item(Material.PAPER, "&eSell an Item", "&7Place the item in the middle slot", "&7then press the green button"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cBack", "&7Cancel and get your item back"));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aConfirm", "&7Continue and set the price"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        g.inv.setItem(13, null);
        p.openInventory(g.inv);
    }

    void ahSellClick(InventoryClickEvent e, Gui g, Player p) {
        if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR) { e.setCancelled(true); return; }
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int s = e.getSlot();
        if (s == 13) return;
        e.setCancelled(true);
        if (s == 11) {
            Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); openAh(p, 0); });
            return;
        }
        if (s != 15) return;
        ItemStack put = g.inv.getItem(13);
        if (put == null || put.getType().isAir()) { msg(p, "&cPlace the item you want to sell in the middle slot first"); return; }
        if (!canList(p)) return;
        g.inv.setItem(13, null);
        g.filter = "done";
        UUID pid = p.getUniqueId();
        ahPending.put(pid, put);
        Bukkit.getScheduler().runTask(this, () -> {
            p.closeInventory();
            boolean ok = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Enter Price", ""}, text -> {
                ItemStack pend = ahPending.remove(pid);
                if (pend == null) return;
                double price = parseAmount(text);
                if (price <= 0) { give(p, pend); msg(p, "&cInvalid price. Your item was returned."); return; }
                listings.add(new Listing(nextListingId++, pid, pend, price, System.currentTimeMillis()));
                msg(p, "You listen " + pend.getAmount() + " " + goodName(pend) + " for $" + fmt(price));
            });
            if (!ok) {
                ItemStack pend = ahPending.remove(pid);
                if (pend != null) give(p, pend);
                return;
            }
            Bukkit.getScheduler().runTaskLater(this, () -> {
                ItemStack stale = ahPending.remove(pid);
                if (stale != null) {
                    restoreSign(pid);
                    Player pp = Bukkit.getPlayer(pid);
                    if (pp != null) { give(pp, stale); msg(pp, "&cPrice entry timed out. Your item was returned."); }
                }
            }, 20L * 90);
        });
    }

    void buyListing(Player p, Listing l) {
        if (l.seller.equals(p.getUniqueId())) { msg(p, "&cYou cannot buy your own listing"); return; }
        if (!take(p.getUniqueId(), l.price)) { msg(p, "&cNot enough money (need $" + fmt(l.price) + ")"); return; }
        listings.remove(l);
        add(l.seller, l.price);
        give(p, l.item.clone());
        msg(p, "You bought " + l.item.getAmount() + " " + goodName(l.item) + " for $" + fmt(l.price));
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) msg(seller, p.getName() + " bought your " + goodName(l.item) + " for $" + fmt(l.price));
    }


    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) {
            if (e.getRawSlots().contains(SELL_BTN)) { e.setCancelled(true); return; }
            Bukkit.getScheduler().runTask(this, () -> refreshSellButton(g));
            return;
        }
        if (g.type.equals("orderdeposit")) return;
        if (g.type.equals("ahsell")) {
            for (int rs : e.getRawSlots()) if (rs < 27 && rs != 13) { e.setCancelled(true); return; }
            return;
        }
        e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) {
            if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR) { e.setCancelled(true); return; }
            if (e.getRawSlot() == SELL_BTN) {
                e.setCancelled(true);
                sellContents((Player) e.getWhoClicked(), g, true);
                refreshSellButton(g);
                return;
            }
            Bukkit.getScheduler().runTask(this, () -> refreshSellButton(g));
            return;   // the rest of the window = free item placement
        }
        if (g.type.equals("orderdeposit")) return; // free item placement
        Player p = (Player) e.getWhoClicked();
        if (g.type.equals("ahsell")) { ahSellClick(e, g, p); return; }
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType().isAir()) return;
        int slot = e.getSlot();
        UUID pid = p.getUniqueId();

        switch (g.type) {
            case "shop" -> {
                if (slot == 48 && it.getType() == Material.ARROW) { openShopPage(p, g.page - 1); return; }
                if (slot == 50 && it.getType() == Material.ARROW) { openShopPage(p, g.page + 1); return; }
                if (slot == 45) {
                    int cur = shopQty.getOrDefault(pid, 1);
                    shopQty.put(pid, cur == 1 ? 16 : cur == 16 ? 64 : 1);
                    openShopPage(p, g.page);
                    return;
                }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okS = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) shopSearch.remove(pid); else shopSearch.put(pid, text);
                            openShopPage(p, 0);
                        });
                        if (!okS) openShopPage(p, 0);
                    });
                    return;
                }
                Integer sci = g.slotIdx.get(slot);
                if (sci == null) return;
                String entry = g.names.get(sci);
                boolean searching = g.filter != null && !g.filter.isEmpty();
                if (isStaff(p) && !searching && (entry.equals("empty") || e.isShiftClick())) { openShopPick(p, g.page, slot, 0); return; }
                if (entry.startsWith("cfg:")) {
                    String body = entry.substring(4);
                    buyShopEntry(p, body.substring(0, body.indexOf('|')), body.substring(body.indexOf('|') + 1));
                } else if (entry.startsWith("cus:")) {
                    buyShopCustom(p, entry);
                }
            }
            case "shoppick" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                final int spg = g.counts.size() > 0 ? g.counts.get(0) : 0;
                final int ssl = g.counts.size() > 1 ? g.counts.get(1) : 0;
                final String sbase = "shopslots." + spg + "." + ssl;
                if (slot == 45 && it.getType() == Material.ARROW) { openShopPick(p, spg, ssl, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openShopPick(p, spg, ssl, g.page + 1); return; }
                if (slot == 48) { openShopPage(p, spg); return; }
                if (slot == 46) {
                    data.set(sbase + ".item", "NONE");
                    data.set(sbase + ".qty", null);
                    saveData();
                    openShopPage(p, spg);
                    return;
                }
                if (slot == 47 && it.getType() == Material.BARRIER) {
                    data.set(sbase, null);
                    saveData();
                    openShopPage(p, spg);
                    return;
                }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okS = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) shopPickSearch.remove(pid); else shopPickSearch.put(pid, text);
                            openShopPick(p, spg, ssl, 0);
                        });
                        if (!okS) openShopPick(p, spg, ssl, 0);
                    });
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    final Material pm = g.mats.get(slot);
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okQ = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Item quantity", "(e.g. 1, 64)"}, text -> {
                            double q = text == null ? -1 : parseAmount(text.trim());
                            if (q < 1) { msg(p, "&cInvalid quantity"); openShopPage(p, spg); return; }
                            int n = (int) Math.min(q, 2304d);
                            data.set(sbase + ".item", pm.name());
                            data.set(sbase + ".qty", n);
                            saveData();
                            msg(p, "&aSlot set: " + pretty(pm) + " x" + n);
                            openShopPage(p, spg);
                        });
                        if (!okQ) openShopPage(p, spg);
                    });
                }
            }
            case "shopcat" -> {
                if (slot == 45) { openShop(p); return; }
                if (slot == 49) {
                    int cur = shopQty.getOrDefault(pid, 1);
                    shopQty.put(pid, cur == 1 ? 16 : cur == 16 ? 64 : 1);
                    openShopCategory(p, g.filter);
                    return;
                }
                if (slot >= 45 || slot >= g.names.size()) return;
                String key = g.names.get(slot);
                double price = shopPrice(g.filter, key);
                if (price < 0) return;
                if (isSetKey(key)) {
                    String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
                    if (!take(pid, price)) { msg(p, "&cNot enough money (need $" + fmt(price) + ")"); return; }
                    giveArmorSet(p, tier);
                    msg(p, pretty(Material.matchMaterial(tier + "_CHESTPLATE")).replace(" Chestplate", "") + " Armor Set for $" + fmt(price));
                    return;
                }
                String variant = key.contains(":") ? key.substring(key.indexOf(':') + 1) : null;
                Material sm = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
                if (sm == null) return;
                List<String> ench = getConfig().getStringList("shop-enchants." + g.names.get(slot));
                int amt = ench.isEmpty() ? shopQty.getOrDefault(pid, 1) : 1;
                double total = price * amt;
                if (!take(pid, total)) { msg(p, "&cNot enough money (need $" + fmt(total) + ")"); return; }
                ItemStack bought = new ItemStack(sm, amt);
                if (!ench.isEmpty()) applyEnchants(bought, ench);
                give(p, bought);
                msg(p, (variant != null ? variantName(variant) + " " : "") + pretty(sm) + (amt > 1 ? " x" + amt : "") + " for $" + fmt(total));
            }
            case "orders" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openOrders(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openOrders(p, g.page + 1); return; }
                if (slot == 47) { orderSort.put(pid, (orderSort.getOrDefault(pid, 0) + 1) % 3); openOrders(p, 0); return; }
                if (slot == 48) { openShardShop(p); return; }
                if (slot == 49) { openOrderPick(p, 0, null); return; }
                if (slot == 50) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Search orders", "(empty = all)"}, text -> {
                            orderSearch.put(pid, text);
                            openOrders(p, 0);
                        });
                    });
                    return;
                }
                if (slot == 51) { openMyOrders(p); return; }
                if (slot >= 45 || slot >= g.orders.size()) return;
                Order o = g.orders.get(slot);
                if (!orders.contains(o) || o.left <= 0) { openOrders(p, g.page); return; }
                if (o.owner.equals(pid)) openOrderManage(p, o); else openOrderDeposit(p, o);
            }
            case "orderpick" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openOrderPick(p, g.page - 1, g.filter); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openOrderPick(p, g.page + 1, g.filter); return; }
                if (slot == 48) { openOrders(p, 0); return; }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> openOrderPick(p, 0, text));
                    });
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    Material pm = g.mats.get(slot);
                    Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); startOrderCreate(p, pm); });
                }
            }
            case "myorders" -> {
                if (slot == 45) { openOrders(p, 0); return; }
                if (slot >= 45 || slot >= g.orders.size()) return;
                Order mo = g.orders.get(slot);
                if (!orders.contains(mo)) { openMyOrders(p); return; }
                openOrderManage(p, mo);
            }
            case "ordermanage" -> {
                Order mo = g.ord;
                if (mo == null) return;
                if (slot == 11) { openMyOrders(p); return; }
                if (!orders.contains(mo)) { openMyOrders(p); return; }
                if (slot == 15) { cancelOrder(p, mo); return; }
                if (slot == 22) openOrderClaim(p, mo);
            }
            case "orderclaim" -> {
                Order co = g.ord;
                if (co == null) return;
                if (slot == 45) { if (orders.contains(co)) openOrderManage(p, co); else openMyOrders(p); return; }
                if (slot == 49) {
                    int got = takeDelivered(p, co, Integer.MAX_VALUE);
                    if (got > 0) msg(p, "&aCollected " + got + " items");
                } else if (slot < 45) {
                    takeDelivered(p, co, it.getAmount());
                }
                if (orders.contains(co)) openOrderClaim(p, co); else openMyOrders(p);
            }
            case "spawnerfilter" -> {
                SpawnerData fs = g.sp;
                if (fs == null || !spawners.containsKey(fs.id)) { p.closeInventory(); return; }
                if (slot == 22) { openSpawner(p, fs, 0); return; }
                int fi = slot % 9;
                if (slot < 18 && fi < g.mats.size()) {
                    Material fm = g.mats.get(fi);
                    if (!fs.disabled.remove(fm)) fs.disabled.add(fm);
                    openSpawnerFilter(p, fs);
                }
            }
            case "rtp" -> {
                World.Environment env = slot == 11 ? World.Environment.NORMAL
                        : slot == 13 ? World.Environment.NETHER
                        : slot == 15 ? World.Environment.THE_END : null;
                if (env == null) return;
                Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); rtp(p, env); });
            }
            case "settings" -> {
                for (int i = 0; i < SETTING_SLOTS.length && i < SETTINGS.length; i++) {
                    if (SETTING_SLOTS[i] != slot) continue;
                    String skey = SETTINGS[i][0];
                    boolean cur = setting(pid, skey, Boolean.parseBoolean(SETTINGS[i][2]));
                    if (skey.equals("nv")) setNv(p, !cur); else setSetting(pid, skey, !cur);
                    break;
                }
                openSettings(p);
                updateBoard(p);
            }
            case "tpconfirm" -> {
                String who = g.filter;
                if (slot == 11) Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); tpRespond(p, false, who); });
                else if (slot == 15) Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f); tpRespond(p, true, who); });
            }
            case "rtpq" -> {
                if (slot == 11) Bukkit.getScheduler().runTask(this, () -> p.closeInventory());
                else if (slot == 15) Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); joinRtpQueue(p); });
            }
            case "bounty" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openBounty(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openBounty(p, g.page + 1); return; }
            }
            case "baltop" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openBaltop(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openBaltop(p, g.page + 1); return; }
                if (slot == 48) { openProfile(p, pid); return; }
                if (slot == 49) { msg(p, "&eYour balance: &a$" + fmt(bal(pid))); return; }
                if (slot == 50) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Player name", ""}, text -> searchPlayerProfile(p, text));
                    });
                    return;
                }
                if (slot < 45 && slot < g.uuids.size()) {
                    UUID tu = g.uuids.get(slot);
                    String tn = Optional.ofNullable(Bukkit.getOfflinePlayer(tu).getName()).orElse("?");
                    msg(p, "&f" + tn + " &7has &a$" + fmt(bal(tu)));
                    openProfile(p, tu);
                }
            }
            case "profile" -> {
                if (slot == 27) openBaltop(p, 0);
                else if ((slot == 30 || slot == 32) && g.filter != null) {
                    final boolean here = slot == 32;
                    final String tname = g.filter;
                    Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); tpaCmd(p, new String[]{tname}, here); });
                }
            }
            case "homes" -> {
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okH = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Home name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) homeSearch.remove(pid); else homeSearch.put(pid, text);
                            openHomes(p);
                        });
                        if (!okH) openHomes(p);
                    });
                    return;
                }
                if (slot == 51 && it.getType() == Material.BARRIER) { homeSearch.remove(pid); openHomes(p); return; }
                if (slot >= 45) return;
                String hn = slot < g.names.size() ? g.names.get(slot) : null;
                if (hn != null) { openHomeManage(p, hn); return; }
                if ("search".equals(g.filter)) return;
                if (slot >= homeLimit(pid)) { msg(p, "&cYou cannot set a home here"); return; }
                String auto = "home" + (slot + 1);
                if (data.contains("homes." + pid + "." + auto)) auto = nextHomeName(pid);
                setHome(p, auto, slot);
                openHomes(p);
            }
            case "homemanage" -> {
                final String hname = g.filter;
                String path = "homes." + pid + "." + hname;
                if (slot == 22) { openHomes(p); return; }
                if (slot == 13) {
                    Location hl = data.getLocation(path);
                    if (hl == null) { openHomes(p); return; }
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        p.teleportAsync(hl);
                        msg(p, "&aTeleported to home &e" + hname);
                    });
                    return;
                }
                if (slot == 10) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Home name", "(letters, numbers, _)"}, text -> {
                            String nn = cleanHomeName(text);
                            if (nn == null) {
                                msg(p, "&cInvalid name (use letters, numbers, _ or -, max 16 characters)");
                                openHomeManage(p, hname);
                            } else if (nn.equals(hname)) {
                                openHomeManage(p, hname);
                            } else if (data.contains("homes." + pid + "." + nn)) {
                                msg(p, "&cYou already have a home with that name");
                                openHomeManage(p, hname);
                            } else {
                                Location old = data.getLocation(path);
                                if (old == null) { openHomes(p); return; }
                                data.set("homes." + pid + "." + nn, old);
                                data.set(path, null);
                                for (int si = 0; si < HOME_MAX_ALL; si++)
                                    if (hname.equals(data.getString("homeslot." + pid + "." + si))) data.set("homeslot." + pid + "." + si, nn);
                                msg(p, "&aHome renamed to &e" + nn);
                                openHomeManage(p, nn);
                            }
                        });
                    });
                    return;
                }
                if (slot == 16) {
                    data.set(path, null);
                    for (int si = 0; si < HOME_MAX_ALL; si++)
                        if (hname.equals(data.getString("homeslot." + pid + "." + si))) data.set("homeslot." + pid + "." + si, null);
                    msg(p, "&aDeleted home &e" + hname);
                    openHomes(p);
                }
            }
            case "shardshop" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openShardShop(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openShardShop(p, g.page + 1); return; }
                Integer sidx = g.slotIdx.get(slot);
                if (sidx == null) return;
                long price = g.prices.get(sidx);
                long have = shards.getOrDefault(pid, 0L);
                if (have < price) { msg(p, "&cNot enough Shards (need " + fmt(price) + ")"); return; }
                shards.put(pid, have - price);
                for (ItemStack gi : g.goods.get(sidx)) give(p, gi.clone());
                msg(p, goodName(g.goods.get(sidx).get(0)) + " for " + fmt(price) + " Shards");
                openShardShop(p, g.page);
            }
            case "spawner" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page + 1); return; }
                if (slot == 48) { openSpawnerSell(p, sd); return; }
                if (slot == 50) {
                    Location eye = p.getEyeLocation();
                    org.bukkit.util.Vector dir = eye.getDirection();
                    Location from = eye.clone().subtract(0, 0.3, 0);
                    int dropped = 0;
                    for (int ti = 0; ti < g.mats.size(); ti++) {
                        Material dm = g.mats.get(ti);
                        long have = sd.items.getOrDefault(dm, 0L);
                        int st = (int) Math.min(g.counts.get(ti), have);
                        if (st <= 0) continue;
                        org.bukkit.entity.Item dr = p.getWorld().dropItem(from, new ItemStack(dm, st));
                        dr.setVelocity(dir.clone().multiply(0.4));
                        dr.setPickupDelay(30);
                        long rem = have - st;
                        if (rem <= 0) sd.items.remove(dm); else sd.items.put(dm, rem);
                        dropped += st;
                    }
                    msg(p, dropped > 0 ? "&aDropped " + dropped + " items" : "&cNothing to drop");
                    openSpawner(p, sd, g.page);
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    Material m = g.mats.get(slot);
                    takeFromSpawner(p, sd, m, g.counts.get(slot));
                    openSpawner(p, sd, g.page);
                }
            }
            case "sus" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openSus(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openSus(p, g.page + 1); return; }
                if (slot < 45 && slot < g.uuids.size()) {
                    Player st = Bukkit.getPlayer(g.uuids.get(slot));
                    if (st == null) { msg(p, "&cThat player is offline"); openSus(p, g.page); return; }
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        p.teleportAsync(st.getLocation());
                        msg(p, "Teleported to " + st.getName());
                    });
                }
            }
            case "settingall" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                if (slot == 11) openPriceMgr(p, 0);
                else if (slot == 13) openCfg(p, "", 0);
                else if (slot == 15) { reloadConfig(); msg(p, "&aConfig reloaded"); }
            }
            case "cfg" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                final String cpath = g.filter == null ? "" : g.filter;
                if (slot == 45 && it.getType() == Material.ARROW) { openCfg(p, cpath, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openCfg(p, cpath, g.page + 1); return; }
                if (slot == 48) {
                    if (cpath.isEmpty()) openSettingAll(p);
                    else openCfg(p, cpath.contains(".") ? cpath.substring(0, cpath.lastIndexOf('.')) : "", 0);
                    return;
                }
                if (slot < 45 && slot < g.names.size()) {
                    String ent = g.names.get(slot);
                    String kind = ent.substring(0, 1);
                    final String full = ent.substring(2);
                    final int pgc = g.page;
                    if (kind.equals("S")) { openCfg(p, full, 0); return; }
                    if (kind.equals("B")) {
                        getConfig().set(full, !getConfig().getBoolean(full));
                        saveConfig();
                        msg(p, "&aSet &e" + full + " &ato &f" + getConfig().getBoolean(full));
                        openCfg(p, cpath, pgc);
                        return;
                    }
                    if (kind.equals("N") || kind.equals("T")) {
                        final Object cur = getConfig().get(full);
                        String shortName = full.substring(full.lastIndexOf('.') + 1);
                        if (shortName.length() > 15) shortName = shortName.substring(0, 15);
                        final String hint = shortName;
                        Bukkit.getScheduler().runTask(this, () -> {
                            p.closeInventory();
                            boolean okC = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "New value", hint}, text -> {
                                if (text == null || text.isBlank()) { openCfg(p, cpath, pgc); return; }
                                Object nv;
                                if (cur instanceof Number) {
                                    double dv = parseAmount(text.trim());
                                    if (dv < 0) { msg(p, "&cInvalid number"); openCfg(p, cpath, pgc); return; }
                                    boolean whole = dv == Math.rint(dv) && dv < 9.0E15;
                                    if (cur instanceof Integer && whole && dv <= Integer.MAX_VALUE) nv = (int) dv;
                                    else if (cur instanceof Long && whole) nv = (long) dv;
                                    else nv = dv;
                                } else {
                                    nv = text;
                                }
                                getConfig().set(full, nv);
                                saveConfig();
                                msg(p, "&aSet &e" + full + " &ato &f" + nv + " &7(some settings need a restart)");
                                openCfg(p, cpath, pgc);
                            });
                            if (!okC) openCfg(p, cpath, pgc);
                        });
                    }
                }
            }
            case "pricemgr" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openPriceMgr(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openPriceMgr(p, g.page + 1); return; }
                if (slot == 47) { priceShopMode.put(pid, !priceShopMode.getOrDefault(pid, false)); openPriceMgr(p, 0); return; }
                if (slot == 51 && it.getType() == Material.BARRIER) { priceSearch.remove(pid); openPriceMgr(p, 0); return; }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okS = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) priceSearch.remove(pid); else priceSearch.put(pid, text);
                            openPriceMgr(p, 0);
                        });
                        if (!okS) openPriceMgr(p, 0);
                    });
                    return;
                }
                if (slot < 45 && slot < g.names.size()) {
                    final String pkey = g.names.get(slot);
                    final boolean shopM = "shop".equals(g.filter);
                    final int pg = g.page;
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okP = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "New price", "reset = default"}, text -> {
                            String res = applyPriceEdit(shopM, pkey, text);
                            if (res != null) msg(p, res);
                            openPriceMgr(p, pg);
                        });
                        if (!okP) openPriceMgr(p, pg);
                    });
                }
            }
            case "spawnersell" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 11) { openSpawner(p, sd, 0); return; }
                if (slot == 13) {
                    double total = spawnerTotalValue(sd);
                    msg(p, total > 0 ? "You will get $" + fmt(total) + " for selling everything in this spawner" : "Nothing to sell");
                    return;
                }
                if (slot == 15) {
                    double total = spawnerTotalValue(sd);
                    if (total <= 0) { msg(p, "&cNothing to sell"); openSpawner(p, sd, 0); return; }
                    sd.items.clear();
                    add(pid, total);
                    msg(p, "&aSold the spawner's items for &e$" + fmt(total));
                    openSpawner(p, sd, 0);
                }
            }
            case "ah" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openAh(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openAh(p, g.page + 1); return; }
                if (slot == 47) { ahSort.put(pid, (ahSort.getOrDefault(pid, 0) + 1) % 3); openAh(p, 0); return; }
                if (slot == 48) { openAh(p, g.page); return; }
                if (slot == 49) { openAhSell(p); return; }
                if (slot == 50) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Search listings", "(empty = all)"}, text -> {
                            ahSearch.put(pid, text);
                            openAh(p, 0);
                        });
                    });
                    return;
                }
                if (slot == 51) { openAhMy(p); return; }
                if (slot >= 45 || slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAh(p, g.page); return; }
                if (l.seller.equals(pid)) { openAhManage(p, l); return; }
                buyListing(p, l);
                openAh(p, g.page);
            }
            case "ahmy" -> {
                if (slot == 45) { openAh(p, 0); return; }
                if (slot >= 45 || slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAhMy(p); return; }
                openAhManage(p, l);
            }
            case "ahmanage" -> {
                if (slot == 11) { openAhMy(p); return; }
                if (slot == 15) {
                    Listing l = g.shown.isEmpty() ? null : g.shown.get(0);
                    if (l != null && listings.remove(l)) {
                        give(p, l.item.clone());
                        msg(p, "You collected your item");
                    }
                    openAhMy(p);
                }
            }
        }
    }

    // ---------- /rtp ----------
    void rtpCmd(Player p, String[] a) {
        if (a.length == 0) { openRtp(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "overworld", "ow", "world", "normal" -> rtp(p, World.Environment.NORMAL);
            case "nether", "hell" -> rtp(p, World.Environment.NETHER);
            case "end", "the_end" -> rtp(p, World.Environment.THE_END);
            default -> openRtp(p);
        }
    }

    void openRtp(Player p) {
        Gui g = new Gui("rtp");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lRTP - Choose Dimension"));
        g.inv.setItem(11, item(Material.GRASS_BLOCK, "&aOverworld", "&7Click to teleport randomly"));
        g.inv.setItem(13, item(Material.NETHERRACK, "&cNether", "&7Click to teleport randomly"));
        g.inv.setItem(15, item(Material.END_STONE, "&dThe End", "&7Click to teleport randomly"));
        p.openInventory(g.inv);
    }

    World findWorld(World.Environment env) {
        return Bukkit.getWorlds().stream().filter(w -> w.getEnvironment() == env).findFirst().orElse(null);
    }

    void rtp(Player p, World.Environment env) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("rtp.cooldown", 10) * 1000;
        Long last = rtpCooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { msg(p, "&cPlease wait " + ((cd - (now - last)) / 1000 + 1) + " more seconds"); return; }
        World w = findWorld(env);
        if (w == null) { msg(p, "&cThat dimension was not found on the server"); return; }
        rtpCooldown.put(p.getUniqueId(), now);
        msg(p, "&eFinding a random location...");
        tryRtp(p, w, 0, env == World.Environment.THE_END ? 80 : 20);
    }

    void tryRtp(Player p, World w, int tries, int maxTries) {
        if (tries >= maxTries) { msg(p, "&cCould not find a safe location, try again"); rtpCooldown.remove(p.getUniqueId()); return; }
        String key = switch (w.getEnvironment()) { case NETHER -> "nether"; case THE_END -> "end"; default -> "overworld"; };
        int defMin = switch (key) { case "nether" -> 300; case "end" -> 1200; default -> 500; };
        int defMax = switch (key) { case "nether" -> 2500; case "end" -> 4000; default -> 5000; };
        Location ctr = w.getWorldBorder().getCenter();
        int max = (int) Math.min(getConfig().getInt("rtp." + key + ".max", defMax), w.getWorldBorder().getSize() / 2 - 16);
        int min = Math.min(getConfig().getInt("rtp." + key + ".min", defMin), max / 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (ctr.getX() + Math.cos(ang) * dist);
        int z = (int) (ctr.getZ() + Math.sin(ang) * dist);
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            Location loc = findSafe(w, x, z);
            if (loc == null) { tryRtp(p, w, tries + 1, maxTries); return; }
            p.teleportAsync(loc).thenAccept(ok -> {
                if (ok) msg(p, "&aTeleported! &7X: " + x + " Z: " + z);
            });
        }));
    }

    Location findSafe(World w, int x, int z) {
        if (w.getEnvironment() == World.Environment.NETHER) {
            for (int y = 120; y >= 33; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (isSafe(b)) return new Location(w, x + 0.5, y + 1, z + 0.5);
            }
            return null;
        }
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y < w.getMinHeight()) return null;
        Block b = w.getBlockAt(x, y, z);
        return isSafe(b) ? new Location(w, x + 0.5, y + 1, z + 0.5) : null;
    }

    boolean isSafe(Block b) {
        Material t = b.getType();
        if (!t.isSolid() || Tag.LEAVES.isTagged(t)) return false;
        switch (t) {
            case MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE, POWDER_SNOW, SWEET_BERRY_BUSH,
                 WITHER_ROSE, CHORUS_PLANT, CHORUS_FLOWER, BEDROCK -> { return false; }
            default -> { }
        }
        for (int i = 1; i <= 2; i++) {
            Block a = b.getRelative(0, i, 0);
            Material at = a.getType();
            if (!a.isPassable() || a.isLiquid() || at == Material.FIRE || at == Material.SOUL_FIRE || at == Material.LAVA) return false;
        }
        return true;
    }

    // ---------- Tab complete ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) {
            ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
            return hs == null ? List.of() : hs.getKeys(false).stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if ((n.equals("pay") || n.equals("tpa") || n.equals("tphere")) && a.length == 1) return names(a[0]);
        if ((n.equals("balance") || n.equals("stats")) && a.length == 1) return allNames(a[0]);
        if (n.equals("dounty")) {
            if (a.length == 1) return Stream.of("add").filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            if (a.length == 2 && a[0].equalsIgnoreCase("add")) return allNames(a[1]);
            if (a.length == 3 && a[0].equalsIgnoreCase("add")) return List.of("1000", "10000", "100000", "1M");
            return List.of();
        }
        if (n.equals("eco")) {
            if (a.length == 1) return List.of("give", "take", "set", "reset", "proset");
            if (a.length == 2) { List<String> o = new ArrayList<>(List.of("@a", "@e", "@n", "@p", "@r", "@s")); o.addAll(allNames(a[1])); return o.stream().filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList()); }
            if (a.length == 3) return a[0].equalsIgnoreCase("proset") || a[0].equalsIgnoreCase("reset")
                    ? List.of("all", "money", "shard", "kill", "death", "time") : List.of("money", "shard", "kill", "death", "time");
        }
        if (n.equals("unoffend") && a.length == 1) {
            List<String> out = new ArrayList<>();
            for (UUID bu : bans.keySet()) {
                String bn = Bukkit.getOfflinePlayer(bu).getName();
                if (bn != null && bn.toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(bn);
            }
            return out;
        }
        if (n.equals("offend")) {
            if (a.length == 1) return allNames(a[0]);
            if (a.length == 2) return Arrays.stream(OFFENCES).filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            if (a.length == 3) return List.of("1d", "7d", "14d", "30d", "perm").stream().filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            return List.of();
        }
        if (n.equals("rtp") && a.length == 1) return List.of("overworld", "nether", "end");
        if (n.equals("afk")) {
            if (!s.hasPermission("donutsmp.admin")) return List.of();
            if (a.length == 1) return List.of("set", "reset").stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            return List.of();
        }
        if (n.equals("givera")) {
            if (a.length >= 1 && a[0].equalsIgnoreCase("re")) {
                if (a.length == 2) return List.of("all", "OWNER", "ADMIN", "CREATOR", "+", "++", "+++");
                if (a.length == 3) return allNames(a[2]);
                return List.of();
            }
            if (a.length == 1) { List<String> o = new ArrayList<>(allNames(a[0])); o.add("re"); return o; }
            if (a.length == 2) return List.of("OWNER", "ADMIN", "CREATOR", "+", "++", "+++");
        }
        if (n.equals("shards")) {
            if (a.length == 1) return List.of("pay");
            if (a.length == 2 && a[0].equalsIgnoreCase("pay")) return names(a[1]);
        }
        if (n.equals("spawner")) {
            if (a.length == 1) return List.of("give", "fill");
            if (a.length == 2 && a[0].equalsIgnoreCase("fill")) return mobs(a[1]);
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                    .filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        if (n.equals("ah") && a.length == 1) return List.of("sell");
        if (n.equals("team")) {
            if (a.length == 1) return List.of("create", "invite", "accept", "leave", "info");
            if (a.length == 2 && a[0].equalsIgnoreCase("invite")) return names(a[1]);
        }
        if (n.equals("order")) {
            if (a.length == 1) return List.of("create", "claim");
            if (a.length == 2 && a[0].equalsIgnoreCase("create"))
                return Arrays.stream(Material.values()).filter(Material::isItem).map(m -> m.name().toLowerCase(Locale.ROOT))
                        .filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        return List.of();
    }
}
