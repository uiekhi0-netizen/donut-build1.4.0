package th.donut;

import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.*;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.block.Sign;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.sign.Side;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.SignChangeEvent;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DonutSMP extends JavaPlugin implements Listener, TabExecutor {


    static class Gui implements InventoryHolder {
        final String type;
        Inventory inv;
        int page;
        List<Order> orders = new ArrayList<>();
        List<Listing> shown = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<Material> mats = new ArrayList<>();
        SpawnerData sp;
        Order ord;
        String filter;
        List<Integer> counts = new ArrayList<>();
        List<UUID> uuids = new ArrayList<>();
        List<List<ItemStack>> goods = new ArrayList<>();
        List<Long> prices = new ArrayList<>();
        Map<Integer, Integer> slotIdx = new HashMap<>();
        Gui(String type) { this.type = type; }
        @Override public Inventory getInventory() { return inv; }
    }

    static class Order {
        final int id; final UUID owner; final Material mat; int left; int delivered; final double price;
        Order(int id, UUID owner, Material mat, int left, double price) {
            this.id = id; this.owner = owner; this.mat = mat; this.left = left; this.price = price;
        }
    }

    static class Listing {
        final int id; final UUID seller; final ItemStack item; final double price; final long time;
        Listing(int id, UUID seller, ItemStack item, double price, long time) {
            this.id = id; this.seller = seller; this.item = item; this.price = price; this.time = time;
        }
    }

    static class TpaReq {
        final UUID from; final boolean here; final long expire;
        TpaReq(UUID from, boolean here, long expire) { this.from = from; this.here = here; this.expire = expire; }
    }

    static class SpawnerData {
        final String id, world; final UUID owner; final EntityType type; final int x, y, z;
        int stack = 1; long xp = 0;
        final Map<Material, Long> items = new HashMap<>();
        final Set<Material> disabled = new HashSet<>();
        SpawnerData(UUID owner, EntityType type, String world, int x, int y, int z) {
            this.owner = owner; this.type = type; this.world = world; this.x = x; this.y = y; this.z = z;
            this.id = world + ":" + x + "," + y + "," + z;
        }
    }

    private final Map<String, SpawnerData> spawners = new HashMap<>();
    private final Map<UUID, Double> money = new HashMap<>();
    private final Map<UUID, Long> shards = new HashMap<>();
    private final Map<UUID, Double> bounties = new HashMap<>();   // /dounty: target -> total bounty on their head
    private final Map<UUID, Long> playSeconds = new HashMap<>();
    private final List<Order> orders = new ArrayList<>();
    private final List<Listing> listings = new ArrayList<>();
    private final Map<UUID, Map<String, Integer>> claims = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Map<UUID, TpaReq> tpaReqs = new HashMap<>();
    private final Map<UUID, String> teamInvites = new HashMap<>();
    private int nextOrderId = 1;
    private int nextListingId = 1;
    private final Map<UUID, Long> mined = new HashMap<>();
    private final Map<UUID, Integer> levels = new HashMap<>();   // player level, gained randomly while mining
    private final Map<UUID, Long> placed = new HashMap<>();
    private final Map<UUID, Integer> orderSort = new HashMap<>();
    private final Map<UUID, String> orderSearch = new HashMap<>();
    private final LinkedHashSet<UUID> rtpQueue = new LinkedHashSet<>();
    private File dataFile;
    private YamlConfiguration data;


    @Override
    public void onEnable() {

        File cf = new File(getDataFolder(), "config.yml");
        if (cf.exists() && YamlConfiguration.loadConfiguration(cf).getInt("config-version", 1) < 34) {
            File old = new File(getDataFolder(), "config-old.yml");
            if (old.exists()) old.delete();
            cf.renameTo(old);
        }
        saveDefaultConfig();
        loadData();
        loadKnownNames();
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("shop", "sell", "order", "ah", "rtp", "sethome", "home", "delhome",
                "balance", "pay", "tpa", "tphere", "tpaccept", "tpdeny", "tpauto", "settings", "nv", "team", "eco", "rules", "spawner", "shardshop", "shards", "help-smp", "givera", "fly", "gmst", "gmse", "offend", "unoffend", "settingmn", "settingall", "sus", "afk", "tpgui", "rtpq", "baltop", "stats", "dounty", "register", "login", "loginauto", "unregister", "createrank", "deleterank", "tia", "follow", "unfollow", "protect", "bless")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) { pc.setExecutor(this); pc.setTabCompleter(this); }
        }
        loadAuth();
        Bukkit.getScheduler().runTaskTimer(this, this::authTick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);
        long siv = Math.max(1, getConfig().getLong("spawner.interval-seconds", 10)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, this::produceAll, siv, siv);
        Bukkit.getOnlinePlayers().forEach(this::setupBoard);
        Bukkit.getOnlinePlayers().forEach(this::refreshStaffPerms);
        Bukkit.getOnlinePlayers().forEach(this::authOnJoin);
    }

    @Override
    public void onDisable() {
        for (UUID sid : new ArrayList<>(signPrompts.keySet())) restoreSign(sid);
        saveData();
    }

    // progress towards the next Shard (0..1) - at the AFK spot it fills 10x faster than anywhere else
    private final Map<UUID, Double> shardProgress = new HashMap<>();

    boolean atAfkSpot(Player p, Location afk) {
        if (afk == null || afk.getWorld() == null || !afk.getWorld().equals(p.getWorld())) return false;
        double r = getConfig().getDouble("shards.afk-radius", 50);
        return p.getLocation().distanceSquared(afk) <= r * r;
    }

    void tick() {
        double normal = getConfig().getDouble("shards.per-minutes", 10) * 60;
        double afkMin = getConfig().getDouble("shards.afk-minutes", 1) * 60;
        long amt = getConfig().getLong("shards.amount", 1);
        Location afk = data.getLocation("afk");
        for (Player p : Bukkit.getOnlinePlayers()) {
            playSeconds.merge(p.getUniqueId(), 1L, Long::sum);
            double need = atAfkSpot(p, afk) ? afkMin : normal;
            if (need > 0) {
                double prog = shardProgress.merge(p.getUniqueId(), 1.0 / need, Double::sum);
                if (prog >= 1.0) {
                    shardProgress.put(p.getUniqueId(), prog - 1.0);
                    shards.merge(p.getUniqueId(), amt, Long::sum);
                    if (getConfig().getBoolean("shards.notify", true) && need >= normal)
                        msg(p, "You earned " + amt + (amt == 1 ? " Shard" : " Shards") + " for playing the server");
                }
            }
            updateBoard(p);
            if (setting(p.getUniqueId(), "tpauto", false))
                p.sendActionBar(Component.text("TPA Auto-Accept: ON", NamedTextColor.GREEN));
        }
    }

    // ---------- Utility ----------
    String c(String s) { return ChatColor.translateAlternateColorCodes('&', s); }

    // every plugin chat message is plain white (colour codes are stripped)
    String w(String m) { return ChatColor.WHITE + ChatColor.stripColor(c(m)); }

    void msg(CommandSender s, String m) { s.sendMessage(w(getConfig().getString("prefix", "") + m)); }

    static String pretty(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String part : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    String goodName(ItemStack it) {
        EntityType stype = spawnerType(it);
        if (stype != null) return nice(stype) + " Spawner";
        ItemMeta m = it.getItemMeta();
        if (m != null && m.hasDisplayName()) return ChatColor.stripColor(LegacyComponentSerializer.legacySection().serialize(m.displayName()));
        return pretty(it.getType());
    }

    double bal(UUID id) { return money.getOrDefault(id, 0.0); }

    void add(UUID id, double amt) { money.put(id, Math.max(0, bal(id) + amt)); }

    boolean take(UUID id, double amt) {
        if (bal(id) < amt) return false;
        money.put(id, bal(id) - amt);
        return true;
    }

    static String fmt(double v) {
        String[] suf = {"", "K", "M", "B", "T"};
        int i = 0;
        while (v >= 1000 && i < suf.length - 1) { v /= 1000; i++; }
        if (i == 0) return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.1f", v);
        String s = String.format(Locale.US, "%.1f", v);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s + suf[i];
    }

    static String fullMoney(double v) {
        long whole = (long) Math.floor(Math.max(0, v));
        return String.format(Locale.US, "%,d", whole).replace(',', '.') + " (" + fmt(v) + ")";
    }

    // level shown short: 999 -> 999, 1000 -> 1k, 1500 -> 1.5k, 1000000 -> 1m
    static String lvl(long v) {
        if (v < 1000) return String.valueOf(v);
        String[] suf = {"k", "m", "b"};
        double d = v;
        int i = -1;
        while (d >= 1000 && i < suf.length - 1) { d /= 1000; i++; }
        d = Math.floor(d * 10) / 10.0;   // cut, never round up (1999 -> 1.9k)
        String t = String.format(Locale.US, "%.1f", d);
        if (t.endsWith(".0")) t = t.substring(0, t.length() - 2);
        return t + suf[i];
    }

    static String dh(long s) { return (s / 86400) + "d " + (s % 86400 / 3600) + "h"; }

    String lineKey(String l) {
        for (String k : new String[]{"money", "shards", "kd", "level", "kills", "deaths", "playtime", "team"})
            if (l.contains("{" + k + "}")) return k;
        return null;
    }

    static String shortTime(long s) {
        long d = s / 86400, h = s % 86400 / 3600, m = s % 3600 / 60;
        if (d > 0) return d + "d " + h + "h";
        if (h > 0) return h + "h " + m + "m";
        return m + "m";
    }

    static String hms(long s) { return (s / 3600) + "h " + (s % 3600 / 60) + "m " + (s % 60) + "s"; }

    double parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(",", "");
            double mul = 1;
            if (s.endsWith("k")) mul = 1e3;
            else if (s.endsWith("m")) mul = 1e6;
            else if (s.endsWith("b")) mul = 1e9;
            if (mul != 1) s = s.substring(0, s.length() - 1);
            double v = Double.parseDouble(s) * mul;
            return (Double.isNaN(v) || Double.isInfinite(v)) ? -1 : v;
        } catch (Exception e) { return -1; }
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        left.values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta mt = it.getItemMeta();
        mt.setDisplayName(c(name));
        if (lore.length > 0) mt.setLore(Arrays.stream(lore).map(this::c).collect(Collectors.toList()));
        it.setItemMeta(mt);
        return it;
    }

    boolean setting(UUID id, String key, boolean def) { return data.getBoolean("settings." + id + "." + key, def); }

    void setSetting(UUID id, String key, boolean v) { data.set("settings." + id + "." + key, v); }

    // ---------- Known players (anyone who has ever joined, online or offline) ----------
    final NavigableSet<String> knownNames = new java.util.concurrent.ConcurrentSkipListSet<>(String.CASE_INSENSITIVE_ORDER);
    static final Set<String> SELECTORS = Set.of("a", "e", "n", "p", "r", "s");

    void loadKnownNames() {
        for (OfflinePlayer op : Bukkit.getOfflinePlayers()) if (op.getName() != null) knownNames.add(op.getName());
        for (UUID u : new HashSet<>(money.keySet())) {
            String nn = Bukkit.getOfflinePlayer(u).getName();
            if (nn != null) knownNames.add(nn);
        }
    }

    // find a player who has joined before (case-insensitive, works while they are offline); null if unknown
    OfflinePlayer findPlayer(String name) {
        if (name == null || name.isBlank()) return null;
        if (name.startsWith("@")) name = name.substring(1);
        Player on = Bukkit.getPlayerExact(name);
        if (on != null) return on;
        String real = knownNames.ceiling(name);
        if (real != null && real.equalsIgnoreCase(name)) return Bukkit.getOfflinePlayer(real);
        OfflinePlayer c = Bukkit.getOfflinePlayerIfCached(name);
        if (c != null && c.getName() != null) { knownNames.add(c.getName()); return c; }
        return null;
    }

    // tab-complete every known player (online + offline). If the player typed "@", suggest "@Name" so the list still shows.
    List<String> allNames(String typed) {
        boolean at = typed.startsWith("@");
        String pre = (at ? typed.substring(1) : typed).toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String nm : knownNames) {
            if (nm.toLowerCase(Locale.ROOT).startsWith(pre)) out.add(at ? "@" + nm : nm);
            if (out.size() >= 200) break;
        }
        for (Player pl : Bukkit.getOnlinePlayers()) {
            String nm = pl.getName();
            String sug = at ? "@" + nm : nm;
            if (nm.toLowerCase(Locale.ROOT).startsWith(pre) && !out.contains(sug)) out.add(sug);
        }
        return out;
    }

    List<String> names(String prefix) {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                .filter(n -> n.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))).collect(Collectors.toList());
    }

    List<String> mobs(String prefix) {
        return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                .filter(k -> k.startsWith(prefix.toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
    }

    void applyEnchants(ItemStack it, Collection<?> list) {
        for (Object o : list) {
            try {
                String[] a = String.valueOf(o).split(":");
                Enchantment en = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(a[0].toLowerCase(Locale.ROOT)));
                if (en != null) it.addUnsafeEnchantment(en, a.length > 1 ? Integer.parseInt(a[1]) : 1);
            } catch (Exception ignored) { }
        }
    }

    void giveArmorSet(Player p) { giveArmorSet(p, "DIAMOND"); }

    // tier = DIAMOND / NETHERITE / IRON ... ; enchants come from config "<tier>-armor-enchants"
    void giveArmorSet(Player p, String tier) {
        for (String part : new String[]{"HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS"}) {
            Material m = Material.matchMaterial(tier + "_" + part);
            if (m == null) continue;
            ItemStack it = new ItemStack(m);
            applyEnchants(it, getConfig().getStringList(tier.toLowerCase(Locale.ROOT) + "-armor-enchants"));
            give(p, it);
        }
    }

    static String variantName(String v) {
        StringBuilder sb = new StringBuilder();
        for (String part : v.toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    static boolean isSetKey(String key) { return key.endsWith("_ARMOR_SET"); }

    static String tierName(double price) {
        if (price < 100) return "&7Common";
        if (price < 1_000) return "&aUncommon";
        if (price < 10_000) return "&9Rare";
        if (price < 100_000) return "&5Epic";
        if (price < 1_000_000) return "&6Legendary";
        return "&c&lMythic";
    }

    void shardsCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length >= 3 && a[0].equalsIgnoreCase("pay")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            long amt = (long) parseAmount(a[2]);
            if (t == null || t == p || amt <= 0) { msg(p, "&cInvalid input"); return; }
            if (shards.getOrDefault(id, 0L) < amt) { msg(p, "&cNot enough Shards"); return; }
            shards.merge(id, -amt, Long::sum);
            shards.merge(t.getUniqueId(), amt, Long::sum);
            msg(p, "&aSent &d" + fmt(amt) + " Shards &ato &9" + t.getName());
            msg(t, "&9" + p.getName() + " &apaid you &d" + fmt(amt) + " Shards");
            t.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(w(p.getName() + " paid you " + fmt(amt) + " Shards")));
            t.playSound(t.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
            return;
        }
        msg(p, "&dYour Shards: &f" + fmt(shards.getOrDefault(id, 0L)) + " &7| /shardshop opens the shop | /shards pay <player> <amount>");
    }

    void openShardShop(Player p) { openShardShop(p, 0, false); }
    void openShardShop(Player p, int page) { openShardShop(p, page, false); }

    void openShardShop(Player p, int page, boolean legacyFlag) {
        List<List<ItemStack>> allGoods = new ArrayList<>();
        List<Long> allPrices = new ArrayList<>();
        List<ItemStack> allDisplay = new ArrayList<>();
        List<Integer> allSlots = new ArrayList<>();   // wanted slot on the gear page (-1 = next free slot)
        for (Map<?, ?> m : getConfig().getMapList("shardshop.items")) {
            try {
                List<String> ench = new ArrayList<>();
                if (m.get("enchants") instanceof List<?> el) for (Object o : el) ench.add(String.valueOf(o));
                List<ItemStack> goods = new ArrayList<>();
                ItemStack display;
                Object armorSet = m.get("armor-set");
                if (armorSet != null) {
                    for (String part : List.of("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS")) {
                        Material pm = Material.matchMaterial(String.valueOf(armorSet).toUpperCase(Locale.ROOT) + "_" + part);
                        if (pm == null) continue;
                        ItemStack pi = new ItemStack(pm);
                        applyEnchants(pi, ench);
                        goods.add(pi);
                    }
                    if (goods.isEmpty()) continue;
                    display = goods.get(goods.size() > 1 ? 1 : 0).clone();
                } else {
                    Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                    if (mat == null) continue;
                    int amt = m.get("amount") instanceof Number nn ? nn.intValue() : 1;
                    ItemStack gi = new ItemStack(mat, Math.max(1, amt));
                    applyEnchants(gi, ench);
                    if (m.get("name") != null) {
                        ItemMeta gm = gi.getItemMeta();
                        gm.setDisplayName(c(String.valueOf(m.get("name"))));
                        gi.setItemMeta(gm);
                    }
                    if (m.get("hammer") != null) tagHammer(gi);
                    if (m.get("sellaxe") != null) tagSellAxe(gi);
                    goods.add(gi);
                    display = gi.clone();
                }
                long price = ((Number) m.get("price")).longValue();
                ItemMeta mt = display.getItemMeta();
                if (m.get("name") != null) mt.setDisplayName(c(String.valueOf(m.get("name"))));
                List<String> lore = new ArrayList<>();
                if (armorSet != null) lore.add(c("&7Includes all 4 pieces"));
                lore.add(c("&7Price: &d" + fmt(price) + " Shards"));
                lore.add(c("&eClick to buy"));
                mt.setLore(lore);
                display.setItemMeta(mt);
                allGoods.add(goods);
                allPrices.add(price);
                allDisplay.add(display);
                allSlots.add(m.get("slot") instanceof Number sn ? sn.intValue() : -1);
            } catch (Exception ignored) { }
        }
        for (String tid : protectTierIds()) {
            ItemStack good = protectItem(tid);
            ItemStack display = good.clone();
            ItemMeta dm = display.getItemMeta();
            int psz = tierSize(tid);
            dm.lore(List.of(plain("&7Protects a &f" + psz + "x" + psz + " &7area"), plain("&7Price: &d" + fmt(tierPrice(tid)) + " Shards"), plain("&eClick to buy")));
            display.setItemMeta(dm);
            allGoods.add(List.of(good));
            allPrices.add(tierPrice(tid));
            allDisplay.add(display);
            allSlots.add(tierShopSlot(tid));
        }
        int gearCount = allGoods.size();

        List<EntityType> types = Arrays.stream(EntityType.values())
                .filter(et -> Material.matchMaterial(et.name() + "_SPAWN_EGG") != null)
                .sorted(Comparator.comparing(Enum::name)).collect(Collectors.toList());
        for (EntityType et : types) {
            long price = getConfig().getLong("shardshop.spawner-prices." + et.name(), getConfig().getLong("shardshop.spawner-default", 800));
            ItemStack good = spawnerItem(et, 1);
            ItemStack display = good.clone();
            ItemMeta dm = display.getItemMeta();
            dm.setLore(List.of(c("&7Type: &f" + nice(et)), c("&7Price: &d" + fmt(price) + " Shards"), c("&eClick to buy")));
            display.setItemMeta(dm);
            allGoods.add(List.of(good));
            allPrices.add(price);
            allDisplay.add(display);
            allSlots.add(-1);
        }
        // Layout: page 1 = gear on the slots chosen in config (grouped in rows), then spawners follow on the next pages
        int n = allGoods.size();
        int[] pageOf = new int[n];
        int[] slotOf = new int[n];
        List<boolean[]> used = new ArrayList<>();
        if (gearCount > 0) used.add(new boolean[45]);
        boolean[] placed = new boolean[n];
        for (int i = 0; i < gearCount; i++) {
            int ws = allSlots.get(i);
            if (ws >= 0 && ws < 45 && !used.get(0)[ws]) { used.get(0)[ws] = true; pageOf[i] = 0; slotOf[i] = ws; placed[i] = true; }
        }
        for (int i = 0; i < gearCount; i++) {
            if (placed[i]) continue;
            outer:
            for (int pg = 0; ; pg++) {
                if (pg == used.size()) used.add(new boolean[45]);
                for (int sl = 0; sl < 45; sl++) {
                    if (!used.get(pg)[sl]) { used.get(pg)[sl] = true; pageOf[i] = pg; slotOf[i] = sl; break outer; }
                }
            }
        }
        int gearPages = used.size();
        for (int k = 0; gearCount + k < n; k++) { pageOf[gearCount + k] = gearPages + k / 45; slotOf[gearCount + k] = k % 45; }
        int pages = Math.max(1, gearPages + (n - gearCount + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("shardshop");
        g.page = page;
        g.goods = allGoods;
        g.prices = allPrices;
        String baseTitle = getConfig().getString("shardshop.title", "&5&lShard Shop");
        g.inv = Bukkit.createInventory(g, 54, c(baseTitle + (pages > 1 ? " &8(" + (page + 1) + "/" + pages + ")" : "")));
        for (int i = 0; i < n; i++) {
            if (pageOf[i] != page) continue;
            g.slotIdx.put(slotOf[i], i);
            g.inv.setItem(slotOf[i], allDisplay.get(i));
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        g.inv.setItem(49, item(Material.AMETHYST_SHARD, "&dShards: &f" + fmt(shards.getOrDefault(p.getUniqueId(), 0L)), "&7Play to earn Shards"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // Items that are sold in /shop sell for the same price as they cost there.
    // (Enchanted shop gear keeps the "sell:" price, so plain crafted gear is not paid like enchanted gear.)
    // shop price of one entry (key may be MATERIAL, MATERIAL:VARIANT or TIER_ARMOR_SET); /settingmn edits are stored in data.yml
    double shopPrice(String cat, String key) {
        String dp = "prices.shop." + cat + "." + key;
        if (data.contains(dp)) return data.getDouble(dp);
        return getConfig().getDouble("shop-items." + cat + "." + key, -1);
    }

    double sellPrice(Material m) {
        String k = m.name();
        if (data.contains("prices.sell." + k)) return data.getDouble("prices.sell." + k);
        if (getConfig().contains("sell-override." + k)) return getConfig().getDouble("sell-override." + k);
        ConfigurationSection si = getConfig().getConfigurationSection("shop-items");
        if (si != null && !getConfig().contains("shop-enchants." + k)) {
            for (String cat : si.getKeys(false)) {
                ConfigurationSection cs = si.getConfigurationSection(cat);
                if (cs != null && cs.contains(k)) return shopPrice(cat, k);
            }
        }
        return getConfig().getDouble("sell." + k, getConfig().getDouble("sell-default", 1));
    }


    void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection m = data.getConfigurationSection("money");
        if (m != null) for (String k : m.getKeys(false)) money.put(UUID.fromString(k), m.getDouble(k));
        ConfigurationSection sh = data.getConfigurationSection("shards");
        if (sh != null) for (String k : sh.getKeys(false)) shards.put(UUID.fromString(k), sh.getLong(k));
        ConfigurationSection bo = data.getConfigurationSection("bounties");
        if (bo != null) for (String k : bo.getKeys(false)) { double bv = bo.getDouble(k); if (bv > 0) bounties.put(UUID.fromString(k), bv); }
        ConfigurationSection pt = data.getConfigurationSection("playtime");
        if (pt != null) for (String k : pt.getKeys(false)) playSeconds.put(UUID.fromString(k), pt.getLong(k));
        ConfigurationSection os = data.getConfigurationSection("orders");
        if (os != null) for (String k : os.getKeys(false)) {
            ConfigurationSection s = os.getConfigurationSection(k);
            Material mat = Material.matchMaterial(s.getString("item", ""));
            if (mat == null) continue;
            int id = Integer.parseInt(k);
            Order lo = new Order(id, UUID.fromString(s.getString("owner")), mat, s.getInt("left"), s.getDouble("price"));
            lo.delivered = s.getInt("delivered");
            orders.add(lo);
            nextOrderId = Math.max(nextOrderId, id + 1);
        }
        ConfigurationSection as = data.getConfigurationSection("auctions");
        if (as != null) for (String k : as.getKeys(false)) {
            ConfigurationSection s = as.getConfigurationSection(k);
            ItemStack it = s.getItemStack("item");
            if (it == null) continue;
            int id = Integer.parseInt(k);
            listings.add(new Listing(id, UUID.fromString(s.getString("seller")), it, s.getDouble("price"), s.getLong("time")));
            nextListingId = Math.max(nextListingId, id + 1);
        }
        ConfigurationSection cs = data.getConfigurationSection("claims");
        if (cs != null) for (String owner : cs.getKeys(false)) {
            Map<String, Integer> map = new HashMap<>();
            ConfigurationSection items = cs.getConfigurationSection(owner);
            for (String mat : items.getKeys(false)) map.put(mat, items.getInt(mat));
            claims.put(UUID.fromString(owner), map);
        }
        loadProtects();
        ConfigurationSection sps = data.getConfigurationSection("spawners");
        if (sps != null) for (String k : sps.getKeys(false)) {
            ConfigurationSection sc = sps.getConfigurationSection(k);
            try {
                SpawnerData sd = new SpawnerData(UUID.fromString(sc.getString("owner")), EntityType.valueOf(sc.getString("type")),
                        sc.getString("world"), sc.getInt("x"), sc.getInt("y"), sc.getInt("z"));
                sd.stack = Math.max(1, sc.getInt("stack", 1));
                sd.xp = sc.getLong("xp");
                ConfigurationSection its = sc.getConfigurationSection("items");
                if (its != null) for (String mk : its.getKeys(false)) {
                    Material mm = Material.matchMaterial(mk);
                    if (mm != null) sd.items.put(mm, its.getLong(mk));
                }
                for (String dn : sc.getStringList("disabled")) {
                    Material dm = Material.matchMaterial(dn);
                    if (dm != null) sd.disabled.add(dm);
                }
                spawners.put(sd.id, sd);
            } catch (Exception ex) { getLogger().warning("bad spawner entry " + k); }
        }
        ConfigurationSection bns = data.getConfigurationSection("bans");
        if (bns != null) for (String k : bns.getKeys(false)) {
            try {
                bans.put(UUID.fromString(k), new BanInfo(bns.getString(k + ".reason", "Cheating"), bns.getLong(k + ".until"), bns.getString(k + ".id", "UNKNOWN")));
            } catch (Exception ex) { getLogger().warning("bad ban entry " + k); }
        }
        ConfigurationSection fo = data.getConfigurationSection("follows");
        if (fo != null) for (String k : fo.getKeys(false)) {
            Set<UUID> fset = new HashSet<>();
            for (String u : fo.getStringList(k)) fset.add(UUID.fromString(u));
            following.put(UUID.fromString(k), fset);
        }
        ConfigurationSection tr = data.getConfigurationSection("tiers");
        if (tr != null) for (String k : tr.getKeys(false)) { String tv = tr.getString(k); if (tv != null) tiers.put(UUID.fromString(k), tv); }
        ConfigurationSection lv = data.getConfigurationSection("levels");
        if (lv != null) for (String k : lv.getKeys(false)) levels.put(UUID.fromString(k), lv.getInt(k));
        ConfigurationSection mst = data.getConfigurationSection("stats.mined");
        if (mst != null) for (String k : mst.getKeys(false)) mined.put(UUID.fromString(k), mst.getLong(k));
        ConfigurationSection pst = data.getConfigurationSection("stats.placed");
        if (pst != null) for (String k : pst.getKeys(false)) placed.put(UUID.fromString(k), pst.getLong(k));
    }

    void saveData() {
        data.set("money", null);
        money.forEach((k, v) -> data.set("money." + k, v));
        data.set("shards", null);
        shards.forEach((k, v) -> data.set("shards." + k, v));
        data.set("bounties", null);
        bounties.forEach((k, v) -> data.set("bounties." + k, v));
        data.set("playtime", null);
        playSeconds.forEach((k, v) -> data.set("playtime." + k, v));
        data.set("orders", null);
        for (Order o : orders) {
            String p = "orders." + o.id + ".";
            data.set(p + "owner", o.owner.toString());
            data.set(p + "item", o.mat.name());
            data.set(p + "left", o.left);
            data.set(p + "delivered", o.delivered);
            data.set(p + "price", o.price);
        }
        data.set("auctions", null);
        for (Listing l : listings) {
            String p = "auctions." + l.id + ".";
            data.set(p + "seller", l.seller.toString());
            data.set(p + "item", l.item);
            data.set(p + "price", l.price);
            data.set(p + "time", l.time);
        }
        data.set("claims", null);
        claims.forEach((k, map) -> map.forEach((mat, n) -> data.set("claims." + k + "." + mat, n)));
        saveProtects();
        data.set("spawners", null);
        int si = 0;
        for (SpawnerData sd : spawners.values()) {
            String b = "spawners." + (si++) + ".";
            data.set(b + "world", sd.world);
            data.set(b + "x", sd.x); data.set(b + "y", sd.y); data.set(b + "z", sd.z);
            data.set(b + "owner", sd.owner.toString());
            data.set(b + "type", sd.type.name());
            data.set(b + "stack", sd.stack);
            data.set(b + "xp", sd.xp);
            data.set(b + "disabled", sd.disabled.stream().map(Material::name).collect(Collectors.toList()));
            for (Map.Entry<Material, Long> en : sd.items.entrySet()) data.set(b + "items." + en.getKey().name(), en.getValue());
        }
        data.set("stats", null);
        mined.forEach((k, v) -> data.set("stats.mined." + k, v));
        data.set("follows", null);
        following.forEach((k, v) -> { if (!v.isEmpty()) data.set("follows." + k, v.stream().map(UUID::toString).collect(Collectors.toList())); });
        data.set("tiers", null);
        tiers.forEach((k, v) -> data.set("tiers." + k, v));
        data.set("levels", null);
        levels.forEach((k, v) -> data.set("levels." + k, v));
        placed.forEach((k, v) -> data.set("stats.placed." + k, v));
        data.set("bans", null);
        bans.forEach((k, v) -> {
            data.set("bans." + k + ".reason", v.reason());
            data.set("bans." + k + ".until", v.until());
            data.set("bans." + k + ".id", v.id());
        });
        data.set("keyall", null); // purge old Keyall data
        try { data.save(dataFile); } catch (IOException e) { getLogger().warning("save failed: " + e.getMessage()); }
    }

    // ---------- Scoreboard ----------
    // Date shown under the server name, in the time zone of the region (default Thailand), e.g. 2/4/2026
    String boardDate() {
        try {
            java.time.ZoneId z = java.time.ZoneId.of(getConfig().getString("scoreboard.timezone", "Asia/Bangkok"));
            return java.time.ZonedDateTime.now(z).format(java.time.format.DateTimeFormatter.ofPattern(getConfig().getString("scoreboard.date-format", "d/M/yyyy")));
        } catch (Exception ex) {
            return java.time.LocalDate.now().toString();
        }
    }

    String boardTime() {
        try {
            java.time.ZoneId z = java.time.ZoneId.of(getConfig().getString("scoreboard.timezone", "Asia/Bangkok"));
            return java.time.ZonedDateTime.now(z).format(java.time.format.DateTimeFormatter.ofPattern(getConfig().getString("scoreboard.time-format", "HH:mm:ss")));
        } catch (Exception ex) {
            return java.time.LocalTime.now().withNano(0).toString();
        }
    }

    // approximate width (in pixels) of a character in Minecraft's default font, including the 1px gap
    static int charPx(char ch) {
        switch (ch) {
            case 'i': case '.': case ',': case ':': case ';': case '!': case '|': case '\'': return 2;
            case 'l': return 3;
            case ' ': case 'I': case 't': case '(': case ')': case '[': case ']': case '{': case '}': case '*': case '"': return 4;
            case 'f': case 'k': case '<': case '>': return 5;
            case '@': case '~': return 7;
            default: return 6;
        }
    }

    static int pxWidth(String plain, boolean bold) {
        int w = 0;
        for (int i = 0; i < plain.length(); i++) w += charPx(plain.charAt(i)) + (bold ? 1 : 0);
        return w;
    }

    // Level: every block a player mines has a small random chance to give +1 level
    void rollLevel(Player p) {
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        double chance = getConfig().getDouble("level.chance", 0.002);
        int max = getConfig().getInt("level.max", 100);
        UUID id = p.getUniqueId();
        int cur = levels.getOrDefault(id, 0);
        if (cur >= max || ThreadLocalRandom.current().nextDouble() >= chance) return;
        levels.put(id, cur + 1);
        p.sendActionBar(Component.text("LEVEL UP! You are now level " + lvl(cur + 1), NamedTextColor.AQUA));
        p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        updateBoard(p);
    }

    // Title with a left-to-right multi-colour gradient (default: white -> yellow -> purple)
    Component boardTitle() {
        String text = getConfig().getString("scoreboard.title", "Lastlight SMP");
        if (text == null || text.isEmpty()) return Component.text(" ");
        List<String> hex = getConfig().getStringList("scoreboard.gradient");
        if (hex.size() < 2) hex = List.of("#FFFFFF", "#FFE14D", "#A855F7");
        int[] stops = new int[hex.size()];
        for (int i = 0; i < stops.length; i++) {
            try { stops[i] = Integer.parseInt(hex.get(i).replace("#", "").trim(), 16); }
            catch (NumberFormatException ex) { stops[i] = 0xFFFFFF; }
        }
        int n = text.length();
        Component out = Component.empty();
        for (int i = 0; i < n; i++) {
            double t = n <= 1 ? 0 : (double) i / (n - 1);
            double pos = t * (stops.length - 1);
            int k = Math.min((int) Math.floor(pos), stops.length - 2);
            double f = pos - k;
            int c1 = stops[k], c2 = stops[k + 1];
            int r = (int) Math.round(((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * f);
            int g = (int) Math.round(((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * f);
            int bl = (int) Math.round((c1 & 255) + ((c2 & 255) - (c1 & 255)) * f);
            out = out.append(Component.text(String.valueOf(text.charAt(i)))
                    .color(net.kyori.adventure.text.format.TextColor.color(r, g, bl))
                    .decorate(net.kyori.adventure.text.format.TextDecoration.BOLD));
        }
        return out;
    }

    String teamName(UUID id) {
        String key = data.getString("playerTeam." + id);
        if (key == null) return "N/A";
        return data.getString("teams." + key + ".name", "N/A");
    }

    boolean hasTeam(UUID id) { return data.getString("playerTeam." + id) != null; }

    // shown in front of the name above the head, e.g. "[Wolves] "
    String teamTag(UUID id) { return hasTeam(id) ? c("&9[" + teamName(id) + "] &r") : ""; }

    // ping with a colour: green = good, yellow = ok, red = bad
    String pingText(Player p) {
        int ms = Math.max(0, p.getPing());
        return (ms < 80 ? "&a" : ms < 150 ? "&e" : "&c") + ms + "ms";
    }

    void setupBoard(Player p) {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective o = sb.registerNewObjective("donut", Criteria.DUMMY, boardTitle());
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        o.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.blank());
        Objective bn = sb.registerNewObjective("donut_money", Criteria.DUMMY, Component.empty());
        bn.setDisplaySlot(DisplaySlot.BELOW_NAME);
        int n = Math.min(15, getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < n; i++) {
            Team t = sb.registerNewTeam("l" + i);
            String entry = "\u00a7" + Integer.toHexString(i) + "\u00a7r";
            t.addEntry(entry);
            o.getScore(entry).setScore(n - i);
        }
        p.setScoreboard(sb);
        updateBoard(p);
    }

    void updateBoard(Player p) {
        UUID id = p.getUniqueId();
        Scoreboard sb = p.getScoreboard();
        if (sb.getObjective("donut") == null) { setupBoard(p); return; }
        updateNameTags(sb);
        boolean show = setting(id, "scoreboard", true);
        sb.getObjective("donut").setDisplaySlot(show ? DisplaySlot.SIDEBAR : null);
        if (!show) return;
        List<String> lines = getConfig().getStringList("scoreboard.lines");
        int n = Math.min(15, lines.size());
        boolean[] vis = new boolean[n];
        int visCount = 0;
        for (int i = 0; i < n; i++) {
            String key = lineKey(lines.get(i));
            vis[i] = key == null || setting(id, "sb_" + key, true);
            if (vis[i]) visCount++;
        }
        Objective obj = sb.getObjective("donut");
        String[] done = new String[n];
        boolean[] mid = new boolean[n];
        int maxW = pxWidth(ChatColor.stripColor(c(getConfig().getString("scoreboard.title", "Lastlight SMP"))), true);
        for (int i = 0; i < n; i++) {
            if (!vis[i]) continue;
            String raw = lines.get(i);
            if (raw.startsWith("<center>")) { mid[i] = true; raw = raw.substring(8); }
            String line = raw
                    .replace("{money}", fmt(bal(id)))
                    .replace("{shards}", fmt(shards.getOrDefault(id, 0L)))
                    .replace("{date}", boardDate())
                    .replace("{time}", boardTime())
                    .replace("{level}", lvl(levels.getOrDefault(id, 0)))
                    .replace("{kd}", "&c" + kills(id) + "&7/&6" + deaths(id))
                    .replace("{kills}", String.valueOf(kills(id)))
                    .replace("{deaths}", String.valueOf(deaths(id)))
                    .replace("{playtime}", shortTime(playSeconds.getOrDefault(id, 0L)))
                    .replace("{team}", teamName(id))
                    .replace("{player}", p.getName())
                    .replace("{ping}", pingText(p))
                    .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()));
            done[i] = line;
            if (!mid[i]) maxW = Math.max(maxW, pxWidth(ChatColor.stripColor(c(line.replace("{head}", "  "))), false));
        }
        int pos = 0;
        for (int i = 0; i < n; i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String entry = "§" + Integer.toHexString(i) + "§r";
            if (!vis[i]) { sb.resetScores(entry); continue; }
            String line = done[i];
            if (mid[i]) {
                int w = pxWidth(ChatColor.stripColor(c(line.replace("{head}", "  "))), false);   // the head icon is ~8px wide
                int pad = Math.max(0, (int) Math.round((maxW - w) / 2.0 / 4.0));   // a space is 4px wide
                line = " ".repeat(pad) + line;
            }
            int hi = line.indexOf("{head}");
            if (hi >= 0) {
                // {head} = the player's own skin head icon (needs a 1.21.9+ client)
                LegacyComponentSerializer lg = LegacyComponentSerializer.legacySection();
                Component comp = lg.deserialize(c(line.substring(0, hi)))
                        .append(Component.object(net.kyori.adventure.text.object.ObjectContents.playerHead(p.getUniqueId())))
                        .append(lg.deserialize(c(line.substring(hi + 6))));
                t.prefix(comp);
            } else {
                t.setPrefix(c(line));
            }
            obj.getScore(entry).setScore(visCount - pos);
            pos++;
        }
    }

    // =====================================================================
    //  Follow system:  /follow <player>  |  /unfollow <player>  |  /follow list  |  /follow settings
    //  Followers see what the player they follow buys / sells / teleports to, in chat.
    // =====================================================================
    private final Map<UUID, Set<UUID>> following = new HashMap<>();   // player -> players they follow

    boolean isFollowing(UUID who, UUID target) {
        Set<UUID> st = following.get(who);
        return st != null && st.contains(target);
    }

    List<UUID> followersOf(UUID target) {
        List<UUID> out = new ArrayList<>();
        for (Map.Entry<UUID, Set<UUID>> en : following.entrySet()) if (en.getValue().contains(target)) out.add(en.getKey());
        return out;
    }

    // kind: "buy", "sell" or "tp" - sent only to online followers who have that notification turned on
    void notifyFollowers(Player who, String kind, String text) {
        UUID wid = who.getUniqueId();
        for (Map.Entry<UUID, Set<UUID>> en : following.entrySet()) {
            if (!en.getValue().contains(wid)) continue;
            Player f = Bukkit.getPlayer(en.getKey());
            if (f == null || !setting(f.getUniqueId(), "follow_" + kind, true)) continue;
            f.sendMessage(w("[Follow] " + who.getName() + " " + text));
        }
    }

    // follows (or unfollows when already following); returns true if the player is now followed
    boolean toggleFollow(Player p, OfflinePlayer t) {
        UUID id = p.getUniqueId(), tid = t.getUniqueId();
        String tn = t.getName() == null ? "?" : t.getName();
        Set<UUID> st = following.computeIfAbsent(id, k -> new HashSet<>());
        if (st.remove(tid)) {
            msg(p, "&eYou unfollowed " + tn);
            return false;
        }
        if (st.size() >= getConfig().getInt("follow.max", 100)) { msg(p, "&cYou can't follow more players"); return false; }
        st.add(tid);
        msg(p, "&aYou are now following " + tn);
        if (t.getPlayer() != null) msg(t.getPlayer(), p.getName() + " started following you");
        return true;
    }

    boolean followCmd(CommandSender s, String n, String[] a) {
        if (!(s instanceof Player p)) { msg(s, "&cOnly players can use this command"); return true; }
        UUID id = p.getUniqueId();
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "";
        if (n.equals("follow") && (sub.equals("settings") || sub.equals("setting"))) { openFollowSettings(p); return true; }
        if (n.equals("follow") && sub.equals("list")) {
            List<String> fg = new ArrayList<>(), fr = new ArrayList<>();
            for (UUID u : following.getOrDefault(id, Set.of())) { String nn = Bukkit.getOfflinePlayer(u).getName(); fg.add(nn == null ? "?" : nn); }
            for (UUID u : followersOf(id)) { String nn = Bukkit.getOfflinePlayer(u).getName(); fr.add(nn == null ? "?" : nn); }
            Collections.sort(fg, String.CASE_INSENSITIVE_ORDER);
            Collections.sort(fr, String.CASE_INSENSITIVE_ORDER);
            msg(p, "&6Following (" + fg.size() + "): &f" + (fg.isEmpty() ? "-" : String.join(", ", fg)));
            msg(p, "&6Followers (" + fr.size() + "): &f" + (fr.isEmpty() ? "-" : String.join(", ", fr)));
            return true;
        }
        if (a.length < 1) {
            msg(p, "&e/follow <player> &7- follow  &e/unfollow <player>  &e/follow list  &e/follow settings");
            return true;
        }
        OfflinePlayer t = findPlayer(a[0]);
        if (t == null) { msg(p, "&cPlayer not found (they must have joined the server before)"); return true; }
        if (t.getUniqueId().equals(id)) { msg(p, "&cYou can't follow yourself"); return true; }
        boolean already = isFollowing(id, t.getUniqueId());
        if (n.equals("follow")) {
            if (already) { msg(p, "&eYou already follow " + a[0] + " (use /unfollow " + a[0] + ")"); return true; }
            toggleFollow(p, t);
        } else {
            if (!already) { msg(p, "&eYou do not follow " + a[0]); return true; }
            toggleFollow(p, t);
        }
        return true;
    }

    private static final String[][] FOLLOW_SETTINGS = {
            {"follow_buy", "Show what they BUY", "true", "EMERALD", "10"},
            {"follow_sell", "Show what they SELL", "true", "GOLD_INGOT", "11"},
            {"follow_tp", "Show their TELEPORTS (rtp / home / tpa)", "true", "ENDER_PEARL", "12"},
            {"tpa_followers", "Only followers can send me TPA / TPHERE", "false", "REPEATER", "14"},
    };

    void openFollowSettings(Player p) {
        Gui g = new Gui("followset");
        g.inv = Bukkit.createInventory(g, 27, c("&8Follow Settings"));
        for (String[] fs : FOLLOW_SETTINGS) {
            boolean on = setting(p.getUniqueId(), fs[0], Boolean.parseBoolean(fs[2]));
            ItemStack st = item(Material.valueOf(fs[3]), (on ? "&a" : "&c") + fs[1],
                    on ? "&7Status: &a\u2714 ON" : "&7Status: &c\u2718 OFF", "", "&eClick to toggle");
            if (on) {
                ItemMeta sm = st.getItemMeta();
                sm.setEnchantmentGlintOverride(true);
                st.setItemMeta(sm);
            }
            g.inv.setItem(Integer.parseInt(fs[4]), st);
        }
        g.inv.setItem(16, item(Material.PAPER, "&6Following: &f" + following.getOrDefault(p.getUniqueId(), Set.of()).size(),
                "&6Followers: &f" + followersOf(p.getUniqueId()).size(), "&7/follow list"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // =====================================================================
    //  Custom ranks:  /createrank <name> <color> <abilities>   |   /deleterank <name>
    //  Give them with /givera <player> <name>.  Abilities: fly, homes, or any permission node (has a dot)
    // =====================================================================
    static final Map<String, String> COLOR_NAMES = new LinkedHashMap<>();
    static {
        String[][] cs = {{"black", "0"}, {"dark_blue", "1"}, {"dark_green", "2"}, {"dark_aqua", "3"}, {"dark_red", "4"}, {"dark_purple", "5"},
                {"gold", "6"}, {"gray", "7"}, {"dark_gray", "8"}, {"blue", "9"}, {"green", "a"}, {"aqua", "b"}, {"red", "c"},
                {"light_purple", "d"}, {"yellow", "e"}, {"white", "f"}};
        for (String[] x : cs) COLOR_NAMES.put(x[0], "&" + x[1]);
    }

    // "red" / "&c" / "#FF8800"  ->  legacy colour code string, or null if it is not a colour
    static String colorCode(String in) {
        String c = in.toLowerCase(Locale.ROOT).replace('-', '_');
        if (COLOR_NAMES.containsKey(c)) return COLOR_NAMES.get(c);
        if (c.matches("&[0-9a-f]")) return c;
        if (c.matches("#[0-9a-f]{6}")) {
            StringBuilder sb = new StringBuilder("&x");
            for (char ch : c.substring(1).toCharArray()) sb.append('&').append(ch);
            return sb.toString();
        }
        return null;
    }

    boolean rankExists(String r) { return getConfig().contains("ranks." + r) || data.contains("customranks." + r); }

    String rankPrefixOf(String r) {
        String custom = data.getString("customranks." + r + ".prefix");
        return custom != null ? custom : getConfig().getString("ranks." + r, "");
    }

    List<String> customRankNames() {
        ConfigurationSection cr = data.getConfigurationSection("customranks");
        return cr == null ? new ArrayList<>() : new ArrayList<>(cr.getKeys(false));
    }

    boolean hasAbility(UUID id, String ab) {
        for (String r : ranksOf(id)) if (data.getStringList("customranks." + r + ".abilities").contains(ab)) return true;
        return false;
    }

    Set<String> rankNodes(UUID id) {
        Set<String> out = new LinkedHashSet<>();
        for (String r : ranksOf(id))
            for (String ab : data.getStringList("customranks." + r + ".abilities")) if (ab.contains(".")) out.add(ab);
        return out;
    }

    boolean createRankCmd(CommandSender s, String[] a) {
        if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
        if (a.length < 2) {
            msg(s, "&e/createrank <name> <color> <abilities>  &7e.g. /createrank VIP gold fly,homes");
            msg(s, "&7Colors: " + String.join(", ", COLOR_NAMES.keySet()) + ", &c, #RRGGBB");
            msg(s, "&7Abilities: fly, homes (20 homes), none, or any permission node like essentials.back");
            return true;
        }
        String name = a[0];
        if (!name.matches("[A-Za-z0-9_]{1,12}")) { msg(s, "&cThe rank name must be 1-12 letters, numbers or _"); return true; }
        String key = name.toUpperCase(Locale.ROOT);
        if (getConfig().contains("ranks." + key) || RANK_ORDER.contains(key) || key.equals("ALL") || key.equals("NONE") || key.equals("REMOVE")) {
            msg(s, "&cThat name is used by a built-in rank");
            return true;
        }
        String col = colorCode(a[1]);
        if (col == null) { msg(s, "&cUnknown color. Use a name (red, gold, dark_purple ...), a code like &c, or #RRGGBB"); return true; }
        List<String> abil = new ArrayList<>();
        for (int i = 2; i < a.length; i++)
            for (String tok : a[i].toLowerCase(Locale.ROOT).split("[,;]+")) {
                tok = tok.trim();
                if (tok.isEmpty() || tok.equals("none")) continue;
                if (!tok.equals("fly") && !tok.equals("homes") && !tok.contains(".")) {
                    msg(s, "&cUnknown ability '" + tok + "' - use fly, homes, none, or a permission node (with a dot)");
                    return true;
                }
                if (!abil.contains(tok)) abil.add(tok);
            }
        String base = "customranks." + key;
        data.set(base + ".name", name);
        data.set(base + ".color", a[1]);
        data.set(base + ".prefix", col + "&l" + name + " &r");
        data.set(base + ".abilities", abil);
        saveData();
        Bukkit.getOnlinePlayers().forEach(this::refreshStaffPerms);
        msg(s, "&aRank " + key + " created. Abilities: " + (abil.isEmpty() ? "none" : String.join(", ", abil)) + ". Give it with /givera <player> " + key);
        return true;
    }

    boolean deleteRankCmd(CommandSender s, String[] a) {
        if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
        if (a.length < 1) { msg(s, "&e/deleterank <name>"); return true; }
        String key = a[0].toUpperCase(Locale.ROOT);
        if (!data.contains("customranks." + key)) { msg(s, "&cNo custom rank called " + a[0] + " (built-in ranks cannot be deleted)"); return true; }
        data.set("customranks." + key, null);
        saveData();
        Bukkit.getOnlinePlayers().forEach(this::refreshStaffPerms);
        msg(s, "&aRank " + key + " deleted");
        return true;
    }

    // =====================================================================
    //  Tier ranking:  /tia list | /tia give <player> <tier> | /tia remove <player> | /tia <name>
    //  Tiers (best first): HT1 HT2 HT3 HT4 HT5 LT1 LT2 LT3 LT4 LT5
    // =====================================================================
    private final Map<UUID, String> tiers = new HashMap<>();
    static final List<String> TIER_ORDER = List.of("HT1", "HT2", "HT3", "HT4", "HT5", "LT1", "LT2", "LT3", "LT4", "LT5");

    static String normTier(String in) {
        String t = in.toUpperCase(Locale.ROOT).replace("-", "").replace("_", "").trim();
        return TIER_ORDER.contains(t) ? t : null;
    }

    static String tierShow(String t) { return t.substring(0, 2) + "-" + t.charAt(2); }

    boolean tiaCmd(CommandSender s, String[] a) {
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "";
        if (sub.equals("list")) {
            boolean any = false;
            for (String t : TIER_ORDER) {
                List<String> who = new ArrayList<>();
                for (Map.Entry<UUID, String> en : tiers.entrySet())
                    if (en.getValue().equals(t)) { String nn = Bukkit.getOfflinePlayer(en.getKey()).getName(); who.add(nn == null ? "?" : nn); }
                if (who.isEmpty()) continue;
                Collections.sort(who, String.CASE_INSENSITIVE_ORDER);
                msg(s, "&6" + tierShow(t) + " &7- &f" + String.join(", ", who));
                any = true;
            }
            if (!any) msg(s, "&7No player has a tier yet");
            return true;
        }
        if (sub.equals("give") || sub.equals("remove")) {
            if (!isStaff(s)) { msg(s, "&cYou do not have permission"); return true; }
            boolean give = sub.equals("give");
            if (a.length < (give ? 3 : 2)) { msg(s, give ? "&e/tia give <player> <HT1-5 / LT1-5>" : "&e/tia remove <player>"); return true; }
            OfflinePlayer t = findPlayer(a[1]);
            if (t == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
            if (give) {
                String tier = normTier(a[2]);
                if (tier == null) { msg(s, "&cUnknown tier. Use HT5 HT4 HT3 HT2 HT1 or LT5 LT4 LT3 LT2 LT1"); return true; }
                tiers.put(t.getUniqueId(), tier);
                msg(s, "&a" + a[1] + " is now " + tierShow(tier));
                if (t.getPlayer() != null && t.getPlayer() != s) msg(t.getPlayer(), "&aYour tier is now " + tierShow(tier));
            } else {
                if (tiers.remove(t.getUniqueId()) == null) { msg(s, "&e" + a[1] + " has no tier"); return true; }
                msg(s, "&aRemoved the tier of " + a[1]);
            }
            saveData();
            return true;
        }
        // /tia <name>  (or just /tia for yourself): shows the tier only if the player has one
        UUID target;
        boolean self;
        String shownName;
        if (a.length == 0) {
            if (!(s instanceof Player me)) { msg(s, "&e/tia <player>"); return true; }
            target = me.getUniqueId(); self = true; shownName = me.getName();
        } else {
            OfflinePlayer t = findPlayer(a[0]);
            if (t == null) { msg(s, "&cPlayer not found"); return true; }
            target = t.getUniqueId();
            self = s instanceof Player me2 && me2.getUniqueId().equals(target);
            shownName = t.getName() == null ? a[0] : t.getName();
        }
        String tier = tiers.get(target);
        if (tier == null) return true;   // no tier -> nothing is shown
        msg(s, (self ? "You" : shownName) + " tier " + tierShow(tier));
        return true;
    }

    // =====================================================================
    //  Login system: /register <password> <confirm>  |  /login <password>  |  /loginauto
    //  Until a player is logged in they can only use /register or /login.
    // =====================================================================
    private final Set<UUID> unauth = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final Map<UUID, Integer> authFails = new HashMap<>();
    private final Map<UUID, Long> authJoinTime = new HashMap<>();
    private int authTicks = 0;
    private File authFile;
    private YamlConfiguration authData;

    void loadAuth() {
        getDataFolder().mkdirs();
        authFile = new File(getDataFolder(), "auth.yml");
        authData = YamlConfiguration.loadConfiguration(authFile);
    }

    void saveAuth() {
        try { authData.save(authFile); } catch (IOException ex) { getLogger().warning("Could not save auth.yml: " + ex.getMessage()); }
    }

    static String hashPw(String pw, byte[] salt) {
        try {
            javax.crypto.spec.PBEKeySpec spec = new javax.crypto.spec.PBEKeySpec(pw.toCharArray(), salt, 20000, 256);
            byte[] h = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(h);
        } catch (Exception ex) {
            throw new IllegalStateException(ex);
        }
    }

    boolean pwMatches(UUID id, String pw) {
        String hash = authData.getString("players." + id + ".hash");
        String salt = authData.getString("players." + id + ".salt");
        if (hash == null || salt == null) return false;
        String test = hashPw(pw, Base64.getDecoder().decode(salt));
        return java.security.MessageDigest.isEqual(test.getBytes(java.nio.charset.StandardCharsets.UTF_8), hash.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    boolean hasPassword(UUID id) { return authData.contains("players." + id + ".hash"); }

    boolean locked(Player p) { return unauth.contains(p.getUniqueId()); }

    static String ipOf(Player p) {
        return p.getAddress() == null ? "" : p.getAddress().getAddress().getHostAddress();
    }

    void authOnJoin(Player p) {
        UUID id = p.getUniqueId();
        boolean reg = hasPassword(id);
        if (reg && authData.getBoolean("players." + id + ".auto", false)
                && ipOf(p).equals(authData.getString("players." + id + ".ip", ""))) {
            msg(p, "&aAuto login successful");
            return;
        }
        unauth.add(id);
        authJoinTime.put(id, System.currentTimeMillis());
        authFails.remove(id);
        msg(p, reg ? "&e/login <password>" : "&e/register <password> <confirm>");
    }

    void authSuccess(Player p) {
        UUID id = p.getUniqueId();
        unauth.remove(id);
        authJoinTime.remove(id);
        authFails.remove(id);
        authData.set("players." + id + ".name", p.getName());
        authData.set("players." + id + ".ip", ipOf(p));
        saveAuth();
        p.sendActionBar(Component.empty());
    }

    void authTick() {
        authTicks++;
        long limit = getConfig().getLong("auth.timeout-seconds", 60) * 1000L;
        for (UUID id : new ArrayList<>(unauth)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) { unauth.remove(id); continue; }
            boolean reg = hasPassword(id);
            p.sendActionBar(Component.text(reg ? "Login: /login <password>" : "Register: /register <password> <confirm>", NamedTextColor.YELLOW));
            if (authTicks % 5 == 0) msg(p, reg ? "&e/login <password>" : "&e/register <password> <confirm>");
            long since = System.currentTimeMillis() - authJoinTime.getOrDefault(id, System.currentTimeMillis());
            if (limit > 0 && since > limit) p.kick(Component.text("You took too long to log in"));
        }
    }

    boolean authCommand(CommandSender s, String n, String[] a) {
        if (n.equals("unregister")) {
            if (!isStaff(s)) { msg(s, "&cYou do not have permission"); return true; }
            if (a.length < 1) { msg(s, "&e/unregister <player> &7- remove a player's password so they can /register again"); return true; }
            OfflinePlayer t = findPlayer(a[0]);
            if (t == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
            authData.set("players." + t.getUniqueId(), null);
            saveAuth();
            msg(s, "&aPassword of " + a[0] + " removed");
            Player on = t.getPlayer();
            if (on != null) authOnJoin(on);
            return true;
        }
        if (!(s instanceof Player p)) { msg(s, "&cOnly players can use this command"); return true; }
        UUID id = p.getUniqueId();
        int min = getConfig().getInt("auth.min-length", 4);
        switch (n) {
            case "register" -> {
                if (hasPassword(id)) { msg(p, "&cYou already have a password. Use /login <password>"); return true; }
                if (a.length < 2) { msg(p, "&e/register <password> <confirm>"); return true; }
                if (!a[0].equals(a[1])) { msg(p, "&cThe two passwords do not match"); return true; }
                if (a[0].length() < min) { msg(p, "&cThe password must be at least " + min + " characters"); return true; }
                if (a[0].length() > 64) { msg(p, "&cThe password is too long (max 64)"); return true; }
                byte[] salt = new byte[16];
                new java.security.SecureRandom().nextBytes(salt);
                authData.set("players." + id + ".salt", Base64.getEncoder().encodeToString(salt));
                authData.set("players." + id + ".hash", hashPw(a[0], salt));
                authSuccess(p);
                msg(p, "&aRegistered! You can now play. Use /loginauto to log in automatically next time");
            }
            case "login" -> {
                if (!hasPassword(id)) { msg(p, "&cYou have no password yet. Use /register <password> <confirm>"); return true; }
                if (!locked(p)) { msg(p, "&cYou are already logged in"); return true; }
                if (a.length < 1) { msg(p, "&e/login <password>"); return true; }
                if (!pwMatches(id, a[0])) {
                    int f = authFails.merge(id, 1, Integer::sum);
                    int max = getConfig().getInt("auth.max-attempts", 5);
                    if (f >= max) { p.kick(Component.text("Too many wrong passwords")); return true; }
                    msg(p, "&cWrong password (" + f + "/" + max + ")");
                    return true;
                }
                authSuccess(p);
                msg(p, "&aLogged in");
            }
            case "loginauto" -> {
                if (locked(p) || !hasPassword(id)) { msg(p, "&cLog in first"); return true; }
                boolean now = !authData.getBoolean("players." + id + ".auto", false);
                authData.set("players." + id + ".auto", now);
                authData.set("players." + id + ".ip", ipOf(p));
                saveAuth();
                msg(p, now ? "&aAuto login is ON (only from this IP address)" : "&eAuto login is OFF");
            }
            default -> { }
        }
        return true;
    }

    // ---- everything below stops a player who has not logged in yet ----
    @EventHandler(priority = EventPriority.HIGH)
    public void onAuthJoin(PlayerJoinEvent e) { authOnJoin(e.getPlayer()); }

    @EventHandler
    public void onAuthQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        unauth.remove(id); authJoinTime.remove(id); authFails.remove(id);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthMove(org.bukkit.event.player.PlayerMoveEvent e) {
        if (!locked(e.getPlayer())) return;
        Location f = e.getFrom(), t = e.getTo();
        if (t == null) return;
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
            Location back = f.clone();
            back.setYaw(t.getYaw());
            back.setPitch(t.getPitch());
            e.setTo(back);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthCommand(org.bukkit.event.player.PlayerCommandPreprocessEvent e) {
        if (!locked(e.getPlayer())) return;
        String m = e.getMessage().trim();
        if (m.startsWith("/")) m = m.substring(1);
        String first = m.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int colon = first.indexOf(':');
        if (colon >= 0) first = first.substring(colon + 1);
        if (first.equals("login") || first.equals("register")) return;
        e.setCancelled(true);
        msg(e.getPlayer(), hasPassword(e.getPlayer().getUniqueId()) ? "&cLog in first: /login <password>" : "&cRegister first: /register <password> <confirm>");
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthChat(AsyncChatEvent e) {
        if (!locked(e.getPlayer())) return;
        e.setCancelled(true);
        msg(e.getPlayer(), hasPassword(e.getPlayer().getUniqueId()) ? "&cLog in first: /login <password>" : "&cRegister first: /register <password> <confirm>");
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthBreak(BlockBreakEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthPlace(BlockPlaceEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthInteract(PlayerInteractEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthInteractEntity(org.bukkit.event.player.PlayerInteractEntityEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthDrop(org.bukkit.event.player.PlayerDropItemEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthSwap(org.bukkit.event.player.PlayerSwapHandItemsEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthConsume(org.bukkit.event.player.PlayerItemConsumeEvent e) { if (locked(e.getPlayer())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthPickup(org.bukkit.event.entity.EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player pl && locked(pl)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthInvClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player pl && locked(pl)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthInvOpen(org.bukkit.event.inventory.InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player pl && locked(pl)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthDamage(org.bukkit.event.entity.EntityDamageEvent e) {
        if (e.getEntity() instanceof Player pl && locked(pl)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthHit(org.bukkit.event.entity.EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player pl && locked(pl)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onAuthTarget(org.bukkit.event.entity.EntityTargetLivingEntityEvent e) {
        if (e.getTarget() instanceof Player pl && locked(pl)) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        e.joinMessage(Component.text(p.getName() + " joined the game", NamedTextColor.WHITE));
        if (!money.containsKey(p.getUniqueId())) money.put(p.getUniqueId(), getConfig().getDouble("start-money", 0));
        knownNames.add(p.getName());
        setupBoard(p);
        applyNv(p);
        refreshStaffPerms(p);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) applyNv(p); }, 2L);
    }

    // Auto respawn: skip the death screen and respawn the player right away (each player can toggle it in /settings)
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeathAutoRespawn(org.bukkit.event.entity.PlayerDeathEvent e) {
        if (!getConfig().getBoolean("auto-respawn.enabled", true)) return;
        Player p = e.getEntity();
        if (!setting(p.getUniqueId(), "autorespawn", true)) return;   // player turned it off in /settings
        long delay = Math.max(1L, getConfig().getLong("auto-respawn.delay-ticks", 1L));
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && p.isDead()) p.spigot().respawn();
        }, delay);
    }

    private boolean inFxFree = false;

    // ---------- Combat tag ----------
    private final Map<UUID, Long> combatUntil = new HashMap<>();

    boolean inCombat(Player p) {
        Long u = combatUntil.get(p.getUniqueId());
        if (u == null) return false;
        if (u < System.currentTimeMillis()) { combatUntil.remove(p.getUniqueId()); return false; }
        return true;
    }

    @EventHandler(ignoreCancelled = true)
    public void onCombatHit(org.bukkit.event.entity.EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player dp) attacker = dp;
        else if (e.getDamager() instanceof org.bukkit.entity.Projectile pr && pr.getShooter() instanceof Player sp) attacker = sp;
        if (attacker == null || attacker.equals(victim)) return;
        long until = System.currentTimeMillis() + getConfig().getInt("combat.seconds", 20) * 1000L;
        combatUntil.put(victim.getUniqueId(), until);
        combatUntil.put(attacker.getUniqueId(), until);
    }

    @EventHandler
    public void onCombatDeath(org.bukkit.event.entity.PlayerDeathEvent e) {
        combatUntil.remove(e.getEntity().getUniqueId());
    }

    private final Map<UUID, Long> spawnerOpenAt = new HashMap<>();

    // merge a drop into the existing stacks (up to the max stack size) so an explosion spawns very few items
    void addMergedDrop(List<ItemStack> stacks, List<Location> where, ItemStack it, Location at) {
        for (ItemStack ex : stacks) {
            if (it.getAmount() <= 0) return;
            if (!ex.isSimilar(it) || ex.getAmount() >= ex.getMaxStackSize()) continue;
            int mv = Math.min(ex.getMaxStackSize() - ex.getAmount(), it.getAmount());
            ex.setAmount(ex.getAmount() + mv);
            it.setAmount(it.getAmount() - mv);
        }
        if (it.getAmount() > 0) { stacks.add(it); where.add(at); }
    }

    // "noexplode" = hide the explosion effect (particles + sound) only. Blocks and entities are still damaged.
    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onExplosionProtect(EntityExplodeEvent e) {
        Entity en = e.getEntity();
        if (!(en instanceof TNTPrimed || en instanceof EnderCrystal || en instanceof ExplosiveMinecart)) return;
        Location loc = e.getLocation();
        boolean hide = false;
        for (Player pl : loc.getWorld().getNearbyPlayers(loc, 24)) {
            if (setting(pl.getUniqueId(), "noexplode", false)) { hide = true; break; }
        }
        if (!hide) return;
        // Cancelling the event removes the vanilla particles/sound; we apply the destruction + damage ourselves
        e.setCancelled(true);
        // keep the explosion SOUND (only the particles are hidden)
        ThreadLocalRandom sr = ThreadLocalRandom.current();
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0f,
                (1.0f + (sr.nextFloat() - sr.nextFloat()) * 0.2f) * 0.7f);
        float power = en instanceof EnderCrystal ? 6f : 4f;
        List<Block> blocks = new ArrayList<>(e.blockList());
        float yield = e.getYield();
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        List<ItemStack> dropStacks = new ArrayList<>();
        List<Location> dropWhere = new ArrayList<>();
        for (Block b : blocks) {
            Material t = b.getType();
            if (t.isAir()) continue;
            if (t == Material.TNT) {
                b.setType(Material.AIR);
                TNTPrimed tnt = (TNTPrimed) b.getWorld().spawnEntity(b.getLocation().add(0.5, 0, 0.5), EntityType.TNT);
                tnt.setFuseTicks(10 + rnd.nextInt(20));
                continue;
            }
            // vanilla-like drops: collect the drops, merge them into full stacks, spawn few item entities (no lag)
            if (rnd.nextFloat() <= yield) {
                for (ItemStack d : b.getDrops(new ItemStack(Material.NETHERITE_PICKAXE))) {
                    if (d == null || d.getType().isAir()) continue;
                    addMergedDrop(dropStacks, dropWhere, d.clone(), b.getLocation().add(0.5, 0.5, 0.5));
                }
            }
            b.setType(Material.AIR);
        }
        for (int i = 0; i < dropStacks.size(); i++) loc.getWorld().dropItem(dropWhere.get(i), dropStacks.get(i));
        double r = power * 2;
        for (Entity t : loc.getWorld().getNearbyEntities(loc, r, r, r)) {
            if (t == en) continue;
            // like vanilla: spectators and flying creative players are not pushed or hurt by explosions
            if (t instanceof Player tp0 && (tp0.getGameMode() == GameMode.SPECTATOR
                    || (tp0.getGameMode() == GameMode.CREATIVE && tp0.isFlying()))) continue;
            double dist = t.getLocation().distance(loc) / r;
            if (dist > 1) continue;
            double impact = 1 - dist;
            if (t instanceof org.bukkit.entity.LivingEntity le) {
                double dmg = ((impact * impact + impact) / 2 * 7 * r + 1);
                le.damage(dmg, en);
            }
            org.bukkit.util.Vector kb = t.getLocation().toVector().subtract(loc.toVector());
            if (kb.lengthSquared() > 0) t.setVelocity(t.getVelocity().add(kb.normalize().multiply(impact)));
        }
        en.remove();
    }


    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        // "@Name" works like "Name" for any known player (selectors such as @a @p @r @s @e @n are left alone)
        for (int ai = 0; ai < a.length; ai++) {
            if (a[ai].length() > 2 && a[ai].startsWith("@") && !SELECTORS.contains(a[ai].substring(1).toLowerCase(Locale.ROOT))
                    && knownNames.contains(a[ai].substring(1))) a[ai] = a[ai].substring(1);
        }

        if (n.equals("createrank")) return createRankCmd(s, a);
        if (n.equals("deleterank")) return deleteRankCmd(s, a);
        if (n.equals("tia")) return tiaCmd(s, a);
        if (n.equals("follow") || n.equals("unfollow")) return followCmd(s, n, a);
        if (n.equals("register") || n.equals("login") || n.equals("loginauto") || n.equals("unregister")) return authCommand(s, n, a);

        if (n.equals("eco")) {
            if (!isStaff(s)) { msg(s, "&cYou do not have permission"); return true; }
            String usage = "&e/eco <give|take|set> <player> <money|shard|kill|death|time> <amount>  &7|  &e/eco reset <player> [type]  &7|  &e/eco proset <player> [all|type]";
            if (a.length < 2) { msg(s, usage); return true; }
            String act = a[0].toLowerCase(Locale.ROOT);
            if (a[1].startsWith("@")) {
                List<Player> targets = new ArrayList<>();
                try {
                    for (Entity en : Bukkit.selectEntities(s, a[1])) if (en instanceof Player tp) targets.add(tp);
                } catch (IllegalArgumentException ex) { msg(s, "&cInvalid selector. Use @a @e @n @p @r @s"); return true; }
                if (targets.isEmpty()) { msg(s, "&cNo players matched " + a[1]); return true; }
                for (Player tp : targets) {
                    String[] b = a.clone();
                    b[1] = tp.getName();
                    onCommand(s, cmd, label, b);
                }
                return true;
            }
            OfflinePlayer t = findPlayer(a[1]);
            if (t == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
            UUID tid = t.getUniqueId();
            Player online = t.getPlayer();

            if (act.equals("reset")) {
                String what = a.length >= 3 ? a[2].toLowerCase(Locale.ROOT) : "all";
                boolean all = what.equals("all");
                boolean done = false;
                if (all || what.equals("money")) { money.put(tid, getConfig().getDouble("start-money", 0)); done = true; }
                if (all || what.equals("level") || what.equals("lvl")) { levels.put(tid, 0); done = true; }
                if (all || what.equals("shard") || what.equals("shards")) { shards.put(tid, 0L); done = true; }
                if (all || what.equals("kill") || what.equals("kills")) { setKills(tid, 0); done = true; }
                if (all || what.equals("death") || what.equals("deaths")) { setDeaths(tid, 0); done = true; }
                if (all || what.equals("time") || what.equals("playtime")) { playSeconds.put(tid, 0L); done = true; }
                if (!done) { msg(s, "&cType must be money / shard / kill / death / time"); return true; }
                if (online != null) updateBoard(online);
                msg(s, "&aReset " + (all ? "all stats" : what) + " of &f" + a[1]);
                return true;
            }

            if (act.equals("proset")) {
                String what = a.length >= 3 ? a[2].toLowerCase(Locale.ROOT) : "all";
                boolean all = what.equals("all");
                ThreadLocalRandom r = ThreadLocalRandom.current();
                boolean done = false;
                if (all || what.equals("money")) { money.put(tid, (double) r.nextLong(1000, 5_000_001)); done = true; }
                if (all || what.equals("shard") || what.equals("shards")) { shards.put(tid, r.nextLong(0, 50_001)); done = true; }
                if (all || what.equals("kill") || what.equals("kills")) { setKills(tid, r.nextInt(0, 501)); done = true; }
                if (all || what.equals("death") || what.equals("deaths")) { setDeaths(tid, r.nextInt(0, 501)); done = true; }
                if (all || what.equals("time") || what.equals("playtime")) { playSeconds.put(tid, r.nextLong(3600, 500L * 3600 + 1)); done = true; }
                if (!done) { msg(s, "&cType must be all / money / shard / kill / death / time"); return true; }
                if (online != null) updateBoard(online);
                msg(s, "&aRandomized " + (all ? "all stats" : what) + " of &f" + a[1]
                        + " &7($" + fmt(bal(tid)) + " | " + fmt(shards.getOrDefault(tid, 0L)) + " shards | "
                        + kills(tid) + " kills | " + deaths(tid) + " deaths | " + dh(playSeconds.getOrDefault(tid, 0L)) + ")");
                return true;
            }

            if (!(act.equals("give") || act.equals("take") || act.equals("set"))) { msg(s, usage); return true; }
            if (a.length < 4) { msg(s, usage); return true; }
            String kind = a[2].toLowerCase(Locale.ROOT);
            String amtStr = a[3];
            switch (kind) {
                case "money" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    switch (act) {
                        case "give" -> add(tid, amt);
                        case "take" -> add(tid, -amt);
                        default -> money.put(tid, amt);
                    }
                    msg(s, "&a" + a[1] + "'s money is now $" + fmt(bal(tid)));
                }
                case "shard", "shards" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    long v = (long) amt;
                    long cur = shards.getOrDefault(tid, 0L);
                    switch (act) {
                        case "give" -> shards.put(tid, cur + v);
                        case "take" -> shards.put(tid, Math.max(0, cur - v));
                        default -> shards.put(tid, v);
                    }
                    msg(s, "&d" + a[1] + "'s Shards are now " + fmt(shards.getOrDefault(tid, 0L)));
                }
                case "level", "lvl" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    int v = (int) amt;
                    int curLv = levels.getOrDefault(tid, 0);
                    switch (act) {
                        case "give" -> levels.put(tid, curLv + v);
                        case "take" -> levels.put(tid, Math.max(0, curLv - v));
                        default -> levels.put(tid, v);
                    }
                    msg(s, "&b" + a[1] + "'s Level is now " + lvl(levels.getOrDefault(tid, 0)));
                }
                case "kill", "kills" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    int v = (int) amt;
                    switch (act) {
                        case "give" -> setKills(tid, kills(tid) + v);
                        case "take" -> setKills(tid, kills(tid) - v);
                        default -> setKills(tid, v);
                    }
                    msg(s, "&c" + a[1] + "'s Kills are now " + kills(tid));
                }
                case "death", "deaths" -> {
                    double amt = parseAmount(amtStr);
                    if (amt < 0) { msg(s, "&cInvalid amount"); return true; }
                    int v = (int) amt;
                    switch (act) {
                        case "give" -> setDeaths(tid, deaths(tid) + v);
                        case "take" -> setDeaths(tid, deaths(tid) - v);
                        default -> setDeaths(tid, v);
                    }
                    msg(s, "&6" + a[1] + "'s Deaths are now " + deaths(tid));
                }
                case "time", "playtime" -> {
                    long secs = parseTime(amtStr);
                    if (secs < 0) { msg(s, "&cInvalid time (examples: 5 = 5 hours, 90m, 2d)"); return true; }
                    long cur = playSeconds.getOrDefault(tid, 0L);
                    switch (act) {
                        case "give" -> playSeconds.put(tid, cur + secs);
                        case "take" -> playSeconds.put(tid, Math.max(0, cur - secs));
                        default -> playSeconds.put(tid, secs);
                    }
                    msg(s, "&e" + a[1] + "'s Playtime is now " + dh(playSeconds.getOrDefault(tid, 0L)));
                }
                default -> { msg(s, "&cType must be money / shard / kill / death / time"); return true; }
            }
            if (online != null) updateBoard(online);
            return true;
        }

        if (n.equals("help-smp")) {
            for (String l : getConfig().getStringList("help-smp.lines")) s.sendMessage(w(l));
            return true;
        }

        if (n.equals("afk")) {
            if (a.length == 0) {   // everyone: teleport to the AFK spot
                if (!(s instanceof Player ap)) { msg(s, "&cPlayers only"); return true; }
                Location al = data.getLocation("afk");
                if (al == null || al.getWorld() == null) { msg(s, "&cThe AFK spot has not been set yet"); return true; }
                ap.teleportAsync(al);
                msg(s, "Teleporting to the AFK spot");
                return true;
            }
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (sub.equals("reset")) {
                data.set("afk", null);
                saveData();
                msg(s, "AFK spot removed");
                return true;
            }
            if (sub.equals("set")) {
                Location base = s instanceof Player sp ? sp.getLocation() : Bukkit.getWorlds().get(0).getSpawnLocation();
                Location target;
                try {
                    String[] xyz;
                    if (a.length == 4) xyz = new String[]{a[1], a[2], a[3]};
                    else if (a.length == 2 && a[1].matches("-?\\d+(\\.\\d+)?-(-?\\d+(\\.\\d+)?)-(-?\\d+(\\.\\d+)?)")) {
                        java.util.regex.Matcher mt = java.util.regex.Pattern.compile("(-?\\d+(?:\\.\\d+)?)-(-?\\d+(?:\\.\\d+)?)-(-?\\d+(?:\\.\\d+)?)").matcher(a[1]);
                        mt.matches();
                        xyz = new String[]{mt.group(1), mt.group(2), mt.group(3)};
                    } else if (a.length == 1 && s instanceof Player) xyz = null;   // no coordinates = your position
                    else { msg(s, "/afk set <x> <y> <z>  |  /afk set  (your position)  |  /afk reset"); return true; }
                    if (xyz == null) target = base.clone();
                    else target = new Location(base.getWorld(), Double.parseDouble(xyz[0]), Double.parseDouble(xyz[1]), Double.parseDouble(xyz[2]), base.getYaw(), base.getPitch());
                } catch (NumberFormatException ex) { msg(s, "&cInvalid coordinates"); return true; }
                data.set("afk", target);
                saveData();
                msg(s, "AFK spot set at " + target.getBlockX() + " " + target.getBlockY() + " " + target.getBlockZ() + " (" + target.getWorld().getName() + ")");
                return true;
            }
            msg(s, "/afk  |  /afk set <x> <y> <z>  |  /afk reset");
            return true;
        }

        if (n.equals("givera")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
            // /givera re <rank|all> <player>  -> remove a rank (or all ranks)
            if (a.length >= 1 && (a[0].equalsIgnoreCase("re") || a[0].equalsIgnoreCase("remove"))) {
                if (a.length < 3) { msg(s, "/givera re <rank|all> <player>"); return true; }
                OfflinePlayer rt = findPlayer(a[2]);
                if (rt == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
                String rk = normalizeRank(a[1]);
                List<String> cur = new ArrayList<>(ranksOf(rt.getUniqueId()));
                if (rk.equals("ALL")) {
                    cur.clear();
                    msg(s, "Removed all ranks of " + a[2]);
                } else if (cur.remove(rk)) {
                    msg(s, "Removed rank " + rk + " from " + a[2]);
                } else {
                    msg(s, a[2] + " does not have rank " + rk);
                    return true;
                }
                saveRanks(rt.getUniqueId(), cur);
                return true;
            }
            if (a.length < 2) { msg(s, "/givera <player> <OWNER|ADMIN|CREATOR|+|++|+++>   |   /givera re <rank|all> <player>"); return true; }
            OfflinePlayer rt = findPlayer(a[0]);
            if (rt == null) { msg(s, "&cPlayer not found (they must have joined the server before)"); return true; }
            String rk = normalizeRank(a[1]);
            if (rk.equals("NONE") || rk.equals("REMOVE")) {   // legacy: clear everything
                saveRanks(rt.getUniqueId(), new ArrayList<>());
                msg(s, "Removed all ranks of " + a[0]);
            } else if (rankExists(rk)) {
                List<String> cur = new ArrayList<>(ranksOf(rt.getUniqueId()));
                if (rk.startsWith("PLUS")) cur.removeIf(x -> x.startsWith("PLUS"));   // only one of + / ++ / +++
                if (!cur.contains(rk)) cur.add(rk);
                saveRanks(rt.getUniqueId(), cur);
                msg(s, "Gave rank " + rk + " to " + a[0]);
            } else {
                msg(s, "Unknown rank (OWNER, ADMIN, CREATOR, +, ++, +++)");
            }
            return true;
        }

        if (n.equals("spawner")) {
            if (!s.hasPermission("donutsmp.admin")) { msg(s, "&cYou do not have permission"); return true; }
            if (a.length >= 2 && a[0].equalsIgnoreCase("fill")) {
                if (!(s instanceof Player fp)) { msg(s, "&cPlayers only"); return true; }
                EntityType ft;
                try { ft = EntityType.valueOf(a[1].toUpperCase(Locale.ROOT)); } catch (Exception ex) { ft = null; }
                if (ft == null) { msg(s, "&cUnknown mob type"); return true; }
                int stackN = 1;
                if (a.length > 2) { try { stackN = Math.max(1, Math.min(getConfig().getInt("spawner.max-stack", 100000), Integer.parseInt(a[2]))); } catch (NumberFormatException ex) { stackN = 1; } }
                Block floor = fp.getLocation().getBlock().getRelative(0, -1, 0);
                if (floor.getY() < fp.getWorld().getMinHeight() || floor.getType() == Material.BEDROCK || floor.getState() instanceof TileState) {
                    msg(s, "&cYou can't place it here");
                    return true;
                }
                SpawnerData ex0 = spawners.get(key(floor));
                int maxStack = getConfig().getInt("spawner.max-stack", 100000);
                if (ex0 != null && floor.getType() == Material.SPAWNER) {
                    if (ex0.type != ft) { msg(s, "&cThere is already a " + nice(ex0.type) + " spawner here"); return true; }
                    int add = Math.min(stackN, maxStack - ex0.stack);
                    if (add <= 0) { msg(s, "&cMaximum stack reached"); return true; }
                    ex0.stack += add;
                    msg(s, "&aAdded " + add + " " + nice(ft) + " spawner(s). Now x" + ex0.stack);
                    return true;
                }
                placeSpawner(floor, ft, fp.getUniqueId(), stackN);
                msg(s, "&aPlaced " + nice(ft) + " spawner x" + stackN + " under your feet (1x1)");
                return true;
            }
            if (a.length < 3 || !a[0].equalsIgnoreCase("give")) { msg(s, "&e/spawner give <player> <mob> [amount] | /spawner fill <mob> [stack]"); return true; }
            Player t = Bukkit.getPlayerExact(a[1]);
            EntityType et;
            try { et = EntityType.valueOf(a[2].toUpperCase(Locale.ROOT)); } catch (Exception ex) { et = null; }
            if (t == null || et == null) { msg(s, "&cPlayer or mob type not found"); return true; }
            int amt = 1;
            if (a.length > 3) { try { amt = Math.max(1, Math.min(getConfig().getInt("spawner.give-max", 100000), Integer.parseInt(a[3]))); } catch (NumberFormatException ex) { amt = 1; } }
            giveSpawners(t, et, amt);
            msg(s, "&aGave " + nice(et) + " Spawner x" + amt + " to " + t.getName());
            return true;
        }

        if (!(s instanceof Player p)) { s.sendMessage("Players only"); return true; }
        UUID id = p.getUniqueId();

        switch (n) {
            case "shop" -> openShop(p);
            case "sell" -> openSell(p);
            case "order" -> orderCmd(p, a);
            case "ah" -> ahCmd(p, a);
            case "rtp" -> rtpCmd(p, a);
            case "offend" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                if (a.length < 3) { msg(p, "&e/offend <player> <ESP|AutoClicker|HackedClient|Cheating|XRAY> <time: 30m, 12h, 14d, 1d12h, perm>"); return true; }
                long banSecs = parseBanSeconds(a[a.length - 1]);
                if (banSecs < 0) { msg(p, "&cInvalid time. Examples: 30m, 12h, 14d, 1d12h, perm"); return true; }
                String off = offenceOf(String.join(" ", Arrays.copyOfRange(a, 1, a.length - 1)));
                if (off == null) { msg(p, "&cReason must be one of: ESP, AutoClicker, HackedClient, Cheating, XRAY"); return true; }
                Player onT = Bukkit.getPlayerExact(a[0]);
                OfflinePlayer offT = onT != null ? onT : findPlayer(a[0]);
                if (offT == null) { msg(p, "&cPlayer not found"); return true; }
                if (offT.getUniqueId().equals(p.getUniqueId())) { msg(p, "&cYou cannot ban yourself"); return true; }
                String offName = offT.getName() != null ? offT.getName() : a[0];
                BanInfo bi = new BanInfo(off, banSecs == 0 ? 0L : System.currentTimeMillis() + banSecs * 1000L, genBanId());
                bans.put(offT.getUniqueId(), bi);
                Player kickT = Bukkit.getPlayer(offT.getUniqueId());
                if (kickT != null) kickT.kick(banScreen(bi));
                saveData();
                msg(p, "Banned " + offName + " for " + off + " (" + (banSecs == 0 ? "permanent" : dhms(banSecs)) + ")");
            }
            case "unoffend" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                if (a.length < 1) { msg(p, "&e/unoffend <player>"); return true; }
                Player unOn = Bukkit.getPlayerExact(a[0]);
                OfflinePlayer unT = unOn != null ? unOn : findPlayer(a[0]);
                if (unT == null) { msg(p, "&cPlayer not found"); return true; }
                String unName = unT.getName() != null ? unT.getName() : a[0];
                if (bans.remove(unT.getUniqueId()) != null) { saveData(); msg(p, "Unbanned " + unName); }
                else msg(p, "&c" + unName + " is not banned by /offend");
            }
            case "settingall" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                openSettingAll(p);
            }
            case "settingmn" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                openPriceMgr(p, 0);
            }
            case "sus" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                openSus(p, 0);
            }
            case "gmst" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                p.setGameMode(GameMode.SPECTATOR);
                msg(p, "Game mode set to Spectator");
            }
            case "gmse" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return true; }
                p.setGameMode(GameMode.SURVIVAL);
                msg(p, "Game mode set to Survival");
            }
            case "fly" -> {
                if (!canFly(p)) { msg(p, "&cYou do not have permission"); return true; }
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) { msg(p, "&cYou can already fly in this game mode"); return true; }
                boolean flyOn = !p.getAllowFlight();
                p.setAllowFlight(flyOn);
                if (flyOn) { if (!p.isOnGround()) p.setFlying(true); }
                else p.setFlying(false);
                msg(p, flyOn ? "Fly enabled" : "Fly disabled");
            }
            case "balance" -> {
                if (a.length == 0) { msg(p, "You have " + fullMoney(bal(id))); return true; }
                UUID tid = null;
                String tname = a[0];
                Player online = Bukkit.getPlayerExact(a[0]);
                if (online != null) { tid = online.getUniqueId(); tname = online.getName(); }
                else {
                    OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(a[0]);
                    if (op != null) { tid = op.getUniqueId(); if (op.getName() != null) tname = op.getName(); }
                }
                if (tid == null) { msg(p, "&cPlayer not found"); return true; }
                msg(p, tname + " have " + fullMoney(bal(tid)));
            }
            case "pay" -> pay(p, a);
            case "tpa" -> tpaCmd(p, a, false);
            case "tphere" -> tpaCmd(p, a, true);
            case "tpaccept" -> tpAcceptCmd(p, a.length > 0 ? a[0] : null);
            case "tpdeny" -> tpRespond(p, false, a.length > 0 ? a[0] : null);
            case "tpgui" -> {
                TpaReq rq = tpaReqs.get(id);
                Player rf = a.length > 0 ? Bukkit.getPlayerExact(a[0]) : null;
                if (rq == null || rf == null || !rq.from.equals(rf.getUniqueId()) || rq.expire < System.currentTimeMillis()) {
                    msg(p, "&cNo pending teleport request");
                } else {
                    openTpConfirm(p, rf, rq.here);
                }
            }
            case "rtpq" -> {
                if (rtpQueue.contains(id)) joinRtpQueue(p); else openRtpQueue(p);
            }
            case "baltop" -> openBaltop(p, 0);
            case "dounty" -> bountyCmd(p, a);
            case "stats" -> {
                UUID su = id;
                if (a.length > 0) {
                    OfflinePlayer fp0 = findPlayer(a[0]);
                    su = fp0 == null ? null : fp0.getUniqueId();
                    if (su == null) { msg(p, "&cPlayer not found"); return true; }
                }
                openProfile(p, su);
            }
            case "tpauto" -> {
                boolean v = !setting(id, "tpauto", false);
                setSetting(id, "tpauto", v);
                msg(p, "&eAuto-accept TPA: " + (v ? "&aON" : "&cOFF"));
            }
            case "settings" -> openSettings(p);
            case "nv" -> {
                boolean on = !setting(id, "nv", false);
                setNv(p, on);
                msg(p, "&eNight Vision: " + (on ? "&aON" : "&cOFF"));
            }
            case "team" -> teamCmd(p, a);
            case "sethome" -> {
                String name = a.length > 0 ? cleanHomeName(a[0]) : "home";
                if (name == null) { msg(p, "&cInvalid home name (use letters, numbers, _ or -, max 16 characters)"); return true; }
                setHome(p, name);
            }
            case "home" -> {
                if (a.length == 0) { openHomes(p); return true; }
                String name = a[0].toLowerCase(Locale.ROOT);
                Location l = data.getLocation("homes." + id + "." + name);
                if (l == null) { msg(p, "&cHome not found: " + name); return true; }
                p.teleportAsync(l);
                msg(p, "&aTeleported to home &e" + name);
                notifyFollowers(p, "tp", "teleported to their home");
            }
            case "delhome" -> {
                if (a.length < 1) { msg(p, "&e/delhome <name>"); return true; }
                String path = "homes." + id + "." + a[0].toLowerCase(Locale.ROOT);
                if (!data.contains(path)) { msg(p, "&cHome not found"); return true; }
                data.set(path, null);
                msg(p, "&aHome deleted");
            }
            case "rules" -> openRules(p);
            case "shardshop" -> openShardShop(p);
            case "shards" -> shardsCmd(p, a);
            case "protect" -> protectCmd(p, a);
            case "bless" -> blessCmd(p, a);
        }
        return true;
    }

    void pay(Player p, String[] a) {
        if (a.length < 2) { msg(p, "&e/pay <player> <amount>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        double amt = parseAmount(a[1]);
        if (t == null || t == p) { msg(p, "&cPlayer not found"); return; }
        if (amt <= 0) { msg(p, "&cInvalid amount"); return; }
        if (!setting(t.getUniqueId(), "pay", true)) { msg(p, "&cThis player has disabled receiving payments"); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cNot enough money"); return; }
        add(t.getUniqueId(), amt);
        msg(p, "&aYou sent $" + fmt(amt) + " to &9" + t.getName());
        msg(t, "&9" + p.getName() + " &apaid you &e$" + fmt(amt));
        t.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(w(p.getName() + " paid you $" + fmt(amt))));
        t.playSound(t.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    // ---------- TPA ----------
    void tpaCmd(Player p, String[] a, boolean here) {
        if (a.length < 1) { msg(p, "&e/" + (here ? "tphere" : "tpa") + " <player>"); return; }
        Player t = Bukkit.getPlayerExact(a[0]);
        if (t == null || t == p) { msg(p, "&cPlayer not found"); return; }
        if (inCombat(t)) { msg(p, "That user is in combat"); return; }
        if (!setting(t.getUniqueId(), here ? "tphere" : "tpa", true)) { msg(p, "&cThis player has disabled teleport requests"); return; }
        if (setting(t.getUniqueId(), "tpa_followers", false) && !isFollowing(p.getUniqueId(), t.getUniqueId())) {
            msg(p, "&cThis player only accepts teleport requests from followers (use /follow " + t.getName() + ")");
            return;
        }
        if (setting(t.getUniqueId(), "tpauto", false)) { doTp(p, t, here); return; }
        tpaReqs.put(t.getUniqueId(), new TpaReq(p.getUniqueId(), here, System.currentTimeMillis() + 60_000));
        String reqWord = here ? "tpahere" : "tpa";
        msg(p, "You sent " + t.getName() + " a " + reqWord);
        t.sendMessage(w(p.getName() + " sent " + reqWord + " You"));
        TextComponent tc = new TextComponent(TextComponent.fromLegacyText(w("type: /tpaccept")));
        tc.setClickEvent(new net.md_5.bungee.api.chat.ClickEvent(net.md_5.bungee.api.chat.ClickEvent.Action.RUN_COMMAND, "/tpaccept"));
        t.spigot().sendMessage(tc);
        t.playSound(t.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.5f);   // ping only: the window opens when /tpaccept is used
    }

    // /tpaccept opens the Accept / Deny window (nothing opens by itself when a request arrives)
    void tpAcceptCmd(Player p, String who) {
        TpaReq r = tpaReqs.get(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { tpaReqs.remove(p.getUniqueId()); msg(p, "&cNo pending teleport request"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (from == null) { tpaReqs.remove(p.getUniqueId()); msg(p, "&cThe requester is offline"); return; }
        if (who != null && !from.getName().equalsIgnoreCase(who)) { msg(p, "&cNo request from that player"); return; }
        openTpConfirm(p, from, r.here);
    }

    void doTp(Player requester, Player target, boolean here) {
        requester.sendMessage(w(target.getName() + " accepted the " + (here ? "tpahere" : "tpa") + "."));
        requester.playSound(requester.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        if (here) target.teleportAsync(requester.getLocation());
        else requester.teleportAsync(target.getLocation());
        if (here) notifyFollowers(target, "tp", "teleported to " + requester.getName());
        else notifyFollowers(requester, "tp", "teleported to " + target.getName());
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (requester.isOnline()) requester.playSound(requester.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
            if (target.isOnline()) target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
        }, 10L);
    }

    void tpRespond(Player p, boolean accept, String who) {
        TpaReq r = tpaReqs.get(p.getUniqueId());
        if (r == null || r.expire < System.currentTimeMillis()) { tpaReqs.remove(p.getUniqueId()); msg(p, "&cNo pending teleport request"); return; }
        Player from = Bukkit.getPlayer(r.from);
        if (who != null && (from == null || !from.getName().equalsIgnoreCase(who))) { msg(p, "&cNo request from that player"); return; }
        tpaReqs.remove(p.getUniqueId());
        if (from == null) { msg(p, "&cThe requester is offline"); return; }
        if (accept && inCombat(from)) { msg(p, "That user is in combat"); return; }
        if (!accept) {
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.8f);
            msg(p, "&cRequest denied");
            msg(from, "&c" + p.getName() + " denied your teleport request");
            return;
        }
        doTp(from, p, r.here);
    }

    void openTpConfirm(Player p, Player from, boolean here) {
        Gui g = new Gui("tpconfirm");
        g.filter = from.getName();
        g.inv = Bukkit.createInventory(g, 27, c("&8" + (here ? "TPAHERE" : "TPA") + " Request"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cDeny", "&7Click to deny the request"));
        World.Environment env = from.getWorld().getEnvironment();
        Material wm = env == World.Environment.NETHER ? Material.NETHERRACK : env == World.Environment.THE_END ? Material.END_STONE : Material.GRASS_BLOCK;
        g.inv.setItem(12, item(wm, "&fWorld: &e" + from.getWorld().getName()));
        g.inv.setItem(13, item(Material.NETHERITE_SWORD, "&6" + (here ? "TPAHERE" : "TPA") + " Request",
                "&f" + from.getName() + " &7" + (here ? "wants you to teleport to them" : "wants to teleport to you"), "&7Do you accept?"));
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta sm = (SkullMeta) head.getItemMeta();
        sm.setOwningPlayer(from);
        sm.setDisplayName(c("&f" + from.getName()));
        head.setItemMeta(sm);
        g.inv.setItem(14, head);
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aAccept", "&7Click to accept the request"));
        p.openInventory(g.inv);
    }

    // ---------- /rtpq ----------
    void openRtpQueue(Player p) {
        Gui g = new Gui("rtpq");
        g.inv = Bukkit.createInventory(g, 27, c("&8RTP Queue"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cDeny"));
        g.inv.setItem(13, item(Material.NETHERITE_SWORD, "&6RTP Queue", "&7You will be matched with another player in the queue", "&7and teleport to them", "&7Do you want to join the RTPQ?"));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aConfirm"));
        p.openInventory(g.inv);
    }

    void joinRtpQueue(Player p) {
        UUID id = p.getUniqueId();
        if (rtpQueue.remove(id)) { msg(p, "&eYou left the RTPQ"); return; }
        rtpQueue.removeIf(u -> Bukkit.getPlayer(u) == null);
        UUID other = rtpQueue.stream().filter(u -> !u.equals(id)).findFirst().orElse(null);
        if (other != null) {
            rtpQueue.remove(other);
            Player op = Bukkit.getPlayer(other);
            if (op != null) {
                p.teleportAsync(op.getLocation());
                msg(p, "&aMatched! Teleporting to &e" + op.getName());
                msg(op, "&e" + p.getName() + " &ateleported to you via RTPQ");
                return;
            }
        }
        rtpQueue.add(id);
        msg(p, "&eYou joined the RTPQ. Waiting for another player... (type /rtpq again to leave)");
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (rtpQueue.remove(id)) {
                Player q = Bukkit.getPlayer(id);
                if (q != null) msg(q, "&cRTPQ timed out");
            }
        }, 20L * 120);
    }


    // ---------- Bounty: /dounty (view)  |  /dounty add <player> <amount> ----------
    void bountyCmd(Player p, String[] a) {
        if (a.length == 0) { openBounty(p, 0); return; }
        if (!a[0].equalsIgnoreCase("add") || a.length < 3) {
            msg(p, "&e/dounty &7- view all bounties  |  &e/dounty add <player> <amount> &7- put a bounty on a player's head");
            return;
        }
        OfflinePlayer t = findPlayer(a[1]);
        if (t == null) { msg(p, "&cPlayer not found (they must have joined the server before)"); return; }
        if (t.getUniqueId().equals(p.getUniqueId())) { msg(p, "&cYou can't put a bounty on yourself"); return; }
        double amt = parseAmount(a[2]);
        double min = getConfig().getDouble("bounty.min", 1000);
        if (amt <= 0) { msg(p, "&cInvalid amount"); return; }
        if (amt < min) { msg(p, "&cMinimum bounty is $" + fmt(min)); return; }
        if (!take(p.getUniqueId(), amt)) { msg(p, "&cYou don't have enough money"); return; }
        double total = bounties.merge(t.getUniqueId(), amt, Double::sum);
        String tn = t.getName() == null ? a[1] : t.getName();
        Bukkit.broadcastMessage(w(p.getName() + " put a $" + fmt(amt) + " bounty on " + tn + " (total $" + fmt(total) + ")"));
        updateBoard(p);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBountyDeath(org.bukkit.event.entity.PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.getUniqueId().equals(victim.getUniqueId())) return;
        Double b = bounties.remove(victim.getUniqueId());
        if (b == null || b <= 0) return;
        add(killer.getUniqueId(), b);
        Bukkit.broadcastMessage(w(killer.getName() + " claimed the $" + fmt(b) + " bounty on " + victim.getName()));
        updateBoard(killer);
    }

    void openBounty(Player p, int page) {
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(bounties.entrySet());
        list.sort((x, y) -> Double.compare(y.getValue(), x.getValue()));
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("bounty");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8Bounties (Page " + (page + 1) + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            UUID u = list.get(i).getKey();
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.setDisplayName(c("&e#" + (i + 1) + " &f" + Optional.ofNullable(op.getName()).orElse("?")));
            sm.setLore(List.of(c("&7Bounty: &a$" + fmt(list.get(i).getValue())), c(op.isOnline() ? "&aOnline" : "&7Offline"), c("&eKill them to claim it")));
            head.setItemMeta(sm);
            g.inv.setItem(g.uuids.size(), head);
            g.uuids.add(u);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        g.inv.setItem(49, item(Material.PAPER, "&6Add a bounty", "&7/dounty add <player> <amount>", "&7Minimum: &a$" + fmt(getConfig().getDouble("bounty.min", 1000))));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        p.openInventory(g.inv);
    }

    void openBaltop(Player p, int page) {
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(money.entrySet());
        list.sort((x, y) -> Double.compare(y.getValue(), x.getValue()));
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("baltop");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8Most Money (Page " + (page + 1) + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            UUID u = list.get(i).getKey();
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(op);
            sm.setDisplayName(c("&e#" + (i + 1) + " &f" + Optional.ofNullable(op.getName()).orElse("?")));
            sm.setLore(List.of(c("&7Money: &a$" + fmt(list.get(i).getValue())), c("&eClick to view profile")));
            head.setItemMeta(sm);
            g.inv.setItem(g.uuids.size(), head);
            g.uuids.add(u);
        }
        int myRank = 1;
        for (Map.Entry<UUID, Double> en : list) { if (en.getKey().equals(p.getUniqueId())) break; myRank++; }
        ItemStack mine = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta ms = (SkullMeta) mine.getItemMeta();
        ms.setOwningPlayer(p);
        ms.setDisplayName(c("&aMy Profile"));
        ms.setLore(List.of(c("&7Rank: &e#" + myRank), c("&7Money: &a$" + fmt(bal(p.getUniqueId())))));
        mine.setItemMeta(ms);
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        g.inv.setItem(48, mine);
        g.inv.setItem(49, item(Material.EMERALD, "&aYour Money", "&7Click to see your balance"));
        g.inv.setItem(50, item(Material.OAK_SIGN, "&eSearch Player", "&7Click to type a player name"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        p.openInventory(g.inv);
    }

    int kills(UUID id) {
        return Math.max(0, stat(Bukkit.getOfflinePlayer(id), Statistic.PLAYER_KILLS) + data.getInt("statoffset.kills." + id, 0));
    }

    int deaths(UUID id) {
        return Math.max(0, stat(Bukkit.getOfflinePlayer(id), Statistic.DEATHS) + data.getInt("statoffset.deaths." + id, 0));
    }

    void setKills(UUID id, int v) {
        data.set("statoffset.kills." + id, Math.max(0, v) - stat(Bukkit.getOfflinePlayer(id), Statistic.PLAYER_KILLS));
    }

    void setDeaths(UUID id, int v) {
        data.set("statoffset.deaths." + id, Math.max(0, v) - stat(Bukkit.getOfflinePlayer(id), Statistic.DEATHS));
    }

    // time: plain number = hours, or with suffix s / m / h / d (e.g. 90m, 2d)
    long parseTime(String t) {
        try {
            t = t.toLowerCase(Locale.ROOT).trim();
            long mul = 3600;
            char last = t.charAt(t.length() - 1);
            if (last == 's') { mul = 1; t = t.substring(0, t.length() - 1); }
            else if (last == 'm') { mul = 60; t = t.substring(0, t.length() - 1); }
            else if (last == 'h') { t = t.substring(0, t.length() - 1); }
            else if (last == 'd') { mul = 86400; t = t.substring(0, t.length() - 1); }
            return (long) (Double.parseDouble(t) * mul);
        } catch (Exception e) { return -1; }
    }

    int stat(OfflinePlayer op, Statistic st) {
        try { return op.getStatistic(st); } catch (Exception e) { return 0; }
    }

    void openProfile(Player viewer, UUID target) {
        OfflinePlayer op = Bukkit.getOfflinePlayer(target);
        String name = Optional.ofNullable(op.getName()).orElse("?");
        Gui g = new Gui("profile");
        g.inv = Bukkit.createInventory(g, 36, c("&8" + name + " Stats"));
        g.inv.setItem(10, item(Material.EMERALD, "&aMoney", "&f$" + fmt(bal(target))));
        g.inv.setItem(11, item(Material.AMETHYST_SHARD, "&dShards", "&f" + fmt(shards.getOrDefault(target, 0L))));
        g.inv.setItem(12, item(Material.DIAMOND_SWORD, "&cKills", "&f" + kills(target)));
        g.inv.setItem(13, item(Material.SKELETON_SKULL, "&6Deaths", "&f" + deaths(target)));
        g.inv.setItem(14, item(Material.CLOCK, "&ePlaytime", "&f" + dh(playSeconds.getOrDefault(target, 0L))));
        g.inv.setItem(15, item(Material.STONE, "&bBlocks Mined", "&f" + fmt(mined.getOrDefault(target, 0L))));
        g.inv.setItem(16, item(Material.COBBLESTONE, "&7Blocks Placed", "&f" + fmt(placed.getOrDefault(target, 0L))));
        g.inv.setItem(19, item(Material.ZOMBIE_HEAD, "&2Monsters Killed", "&f" + stat(op, Statistic.MOB_KILLS)));
        g.inv.setItem(27, item(Material.RED_STAINED_GLASS_PANE, "&c« Back"));
        g.filter = name;
        Player online = Bukkit.getPlayer(target);
        if (online != null && !online.equals(viewer)) {
            g.inv.setItem(30, item(Material.ENDER_PEARL, "&bTPA", "&7Request to teleport to &f" + name, "&eClick to send"));
            g.inv.setItem(32, item(Material.ENDER_EYE, "&bTPHERE", "&7Ask &f" + name + " &7to teleport to you", "&eClick to send"));
        }
        if (!viewer.getUniqueId().equals(target)) {
            boolean fl = isFollowing(viewer.getUniqueId(), target);
            g.inv.setItem(34, item(fl ? Material.RED_DYE : Material.LIME_DYE, fl ? "&cUnfollow" : "&aFollow",
                    "&7See what &f" + name + " &7buys, sells and teleports to", "&eClick to " + (fl ? "unfollow" : "follow")));
        }
        viewer.openInventory(g.inv);
    }

    void searchPlayerProfile(Player p, String text) {
        for (UUID u : money.keySet()) {
            String n = Bukkit.getOfflinePlayer(u).getName();
            if (n != null && n.equalsIgnoreCase(text)) {
                msg(p, "&f" + n + " &7has &a$" + fmt(bal(u)));
                openProfile(p, u);
                return;
            }
        }
        msg(p, "&cPlayer not found: " + text);
    }


    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMine(BlockBreakEvent e) { mined.merge(e.getPlayer().getUniqueId(), 1L, Long::sum); rollLevel(e.getPlayer()); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlaceCount(BlockPlaceEvent e) { placed.merge(e.getPlayer().getUniqueId(), 1L, Long::sum); }

    @EventHandler(ignoreCancelled = true)
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL) return;
        if (!(e.getEntity() instanceof org.bukkit.entity.Enemy)) return;
        Collection<Player> near = e.getLocation().getWorld().getNearbyPlayers(e.getLocation(), 128);
        if (near.isEmpty()) return;
        for (Player pl : near) if (!setting(pl.getUniqueId(), "nomobs", false)) return;
        e.setCancelled(true);
    }

    // ---------- /settings ----------
    // key, name, default, icon
    private static final String[][] SETTINGS = {
            {"chat", "Global Chat", "true", "PAPER"},
            {"tpa", "Accept TPA Requests", "true", "ENDER_PEARL"},
            {"tphere", "Accept TPHERE Requests", "true", "ENDER_EYE"},
            {"tpauto", "Auto-Accept TPA/TPHERE", "false", "REPEATER"},
            {"pay", "Accept Payments (/pay)", "true", "EMERALD"},
            {"nomobs", "Disable Monsters & Phantoms Around You", "false", "ZOMBIE_HEAD"},
            {"noexplode", "Hide TNT & End Crystal Particles", "false", "TNT"},
            {"nv", "Night Vision", "false", "GOLDEN_CARROT"},
            {"autorespawn", "Auto Respawn", "true", "TOTEM_OF_UNDYING"},
            {"scoreboard", "Show Scoreboard", "true", "ITEM_FRAME"},
            {"sb_money", "Scoreboard: Money", "true", "GOLD_INGOT"},
            {"sb_shards", "Scoreboard: Shards", "true", "AMETHYST_SHARD"},
            {"sb_kd", "Scoreboard: K/D", "true", "DIAMOND_SWORD"},
            {"sb_level", "Scoreboard: Level", "true", "EXPERIENCE_BOTTLE"},
            {"sb_playtime", "Scoreboard: Playtime", "true", "CLOCK"},
            {"sb_team", "Scoreboard: Team", "true", "WHITE_BANNER"}};
    private static final int[] SETTING_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30};

    void fill(Inventory inv, Material m) {
        for (int i = 0; i < inv.getSize(); i++) if (inv.getItem(i) == null) inv.setItem(i, item(m, " "));
    }

    void openSettings(Player p) {
        Gui g = new Gui("settings");
        g.inv = Bukkit.createInventory(g, 45, c("&8Settings"));
        for (int i = 0; i < SETTINGS.length; i++) {
            boolean on = setting(p.getUniqueId(), SETTINGS[i][0], Boolean.parseBoolean(SETTINGS[i][2]));
            ItemStack st = item(Material.valueOf(SETTINGS[i][3]), (on ? "&a" : "&c") + SETTINGS[i][1],
                    on ? "&7Status: &a\u2714 ON" : "&7Status: &c\u2718 OFF", "", "&eClick to toggle");
            if (on) {
                ItemMeta sm = st.getItemMeta();
                sm.setEnchantmentGlintOverride(true);
                st.setItemMeta(sm);
            }
            g.inv.setItem(SETTING_SLOTS[i], st);
        }
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    // ---------- Night vision (kept after death) ----------
    void setNv(Player p, boolean on) {
        setSetting(p.getUniqueId(), "nv", on);
        if (on) p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        else p.removePotionEffect(PotionEffectType.NIGHT_VISION);
    }

    void applyNv(Player p) {
        if (setting(p.getUniqueId(), "nv", false))
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION, 0, false, false, false));
    }

    // ---------- /home GUI ----------
    private static final int HOME_MAX_ALL = 20;
    private static final int[] HOME_POS = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24, 29, 30, 31, 32, 33, 38, 39, 40, 41, 42};

    int homeLimit(UUID id) {
        if (ranksOf(id).contains("CREATOR") || hasAbility(id, "homes")) return Math.min(HOME_MAX_ALL, getConfig().getInt("homes.creator-max", 20));
        return Math.min(5, getConfig().getInt("homes.max", 5));
    }

    private final Map<UUID, String> homeSearch = new HashMap<>();

    int[] homePositions(int limit) { return Arrays.copyOf(HOME_POS, Math.max(1, Math.min(limit, HOME_MAX_ALL))); }

    String cleanHomeName(String s) {
        if (s == null) return null;
        String n = s.toLowerCase(Locale.ROOT).trim().replace(' ', '_');
        return n.matches("[a-z0-9_\\-]{1,16}") ? n : null;
    }

    // fixed slot -> home name; homes that have no slot yet fill the free slots
    String[] homeSlots(UUID id, int limit) {
        String[] out = new String[limit];
        ConfigurationSection hs = data.getConfigurationSection("homes." + id);
        Set<String> existing = hs == null ? new HashSet<>() : hs.getKeys(false);
        Set<String> used = new HashSet<>();
        for (int i = 0; i < HOME_MAX_ALL; i++) {
            String nm = data.getString("homeslot." + id + "." + i);
            if (nm != null && existing.contains(nm) && used.add(nm) && i < limit) out[i] = nm;
        }
        TreeSet<String> rest = new TreeSet<>(Comparator.comparing(String::length).thenComparing(Comparator.naturalOrder()));
        for (String k : existing) if (!used.contains(k)) rest.add(k);
        for (int i = 0; i < limit; i++) {
            if (out[i] == null && !rest.isEmpty()) out[i] = rest.pollFirst();
            data.set("homeslot." + id + "." + i, out[i]);
        }
        return out;
    }

    boolean setHome(Player p, String name) { return setHome(p, name, -1); }

    boolean setHome(Player p, String name, int preferred) {
        UUID id = p.getUniqueId();
        String base = "homes." + id;
        int limit = homeLimit(id);
        String[] sl = homeSlots(id, limit);
        boolean exists = data.contains(base + "." + name);
        int free = -1;
        if (preferred >= 0 && preferred < limit && sl[preferred] == null) free = preferred;
        else for (int i = 0; i < limit; i++) if (sl[i] == null) { free = i; break; }
        if (!exists && free < 0) { msg(p, "&cYou can only set up to " + limit + " homes"); return false; }
        data.set(base + "." + name, p.getLocation());
        if (!exists) data.set("homeslot." + id + "." + free, name);
        msg(p, "&aHome &e" + name + " &aset");
        return true;
    }

    void openHomes(Player p) {
        UUID id = p.getUniqueId();
        int limit = homeLimit(id);
        String[] sl = homeSlots(id, limit);
        String f = homeSearch.getOrDefault(id, "").toLowerCase(Locale.ROOT).trim();
        Gui g = new Gui("homes");
        g.filter = f.isEmpty() ? "" : "search";
        g.inv = Bukkit.createInventory(g, 54, c("&8&lHomes"));
        if (f.isEmpty()) {
            for (int i = 0; i < 45; i++) {
                String nm = i < limit ? sl[i] : null;
                g.names.add(nm);
                if (i >= limit) {
                    g.inv.setItem(i, item(Material.RED_STAINED_GLASS_PANE, "&cLocked", "&7You cannot set a home here"));
                } else if (nm != null) {
                    g.inv.setItem(i, homeItem(id, nm));
                } else {
                    g.inv.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, "&7Empty Home Slot", "&eClick to set a home here"));
                }
            }
        } else {
            int pos = 0;
            for (String nm : sl) {
                if (nm == null || !nm.toLowerCase(Locale.ROOT).contains(f) || pos >= 45) continue;
                g.names.add(nm);
                g.inv.setItem(pos, homeItem(id, nm));
                pos++;
            }
            g.inv.setItem(51, item(Material.BARRIER, "&cClear search"));
        }
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Homes", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a home name"));
        p.openInventory(g.inv);
    }

    ItemStack homeItem(UUID id, String nm) {
        Location l = data.getLocation("homes." + id + "." + nm);
        String loc = (l != null && l.getWorld() != null)
                ? l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() : "?";
        return item(Material.LIME_STAINED_GLASS_PANE, "&a" + nm, "&7" + loc, "", "&eClick to open");
    }

    void openHomeManage(Player p, String name) {
        Location l = data.getLocation("homes." + p.getUniqueId() + "." + name);
        String loc = (l != null && l.getWorld() != null)
                ? l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() : "?";
        Gui g = new Gui("homemanage");
        g.filter = name;
        g.inv = Bukkit.createInventory(g, 27, c("&8Home: " + name));
        g.inv.setItem(10, item(Material.NAME_TAG, "&eRename Home", "&7Current name: &f" + name, "&7Click to change it"));
        g.inv.setItem(13, item(Material.ENDER_PEARL, "&aTeleport", "&7" + loc, "&7Click to teleport home"));
        g.inv.setItem(16, item(Material.BARRIER, "&4Delete Home", "&7Click to delete this home"));
        g.inv.setItem(22, item(Material.ARROW, "&e« Back", "&7Go back to your homes"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    String nextHomeName(UUID id) {
        int n = 1;
        while (data.contains("homes." + id + ".home" + n)) n++;
        return "home" + n;
    }

    // ---------- /rules GUI ----------
    void openRules(Player p) {
        int size = Math.max(9, Math.min(54, getConfig().getInt("rules-gui.size", 27) / 9 * 9));
        Gui g = new Gui("rules");
        g.inv = Bukkit.createInventory(g, size, c(getConfig().getString("rules-gui.title", "&8Rules")));
        for (Map<?, ?> m : getConfig().getMapList("rules-gui.items")) {
            try {
                int slot = ((Number) m.get("slot")).intValue();
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null || slot < 0 || slot >= size) continue;
                List<String> lore = new ArrayList<>();
                Object lo = m.get("lore");
                if (lo instanceof List<?> ll) for (Object o : ll) lore.add(String.valueOf(o));
                g.inv.setItem(slot, item(mat, String.valueOf(m.get("name")), lore.toArray(new String[0])));
            } catch (Exception ignored) { }
        }
        Material fm = Material.matchMaterial(getConfig().getString("rules-gui.filler", "BLACK_STAINED_GLASS_PANE"));
        if (fm != null) fill(g.inv, fm);
        p.openInventory(g.inv);
    }

    // ---------- Virtual Spawner ----------
    String nice(EntityType t) {
        String n = t.name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(n.charAt(0)) + n.substring(1);
    }

    String key(Block b) { return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ(); }

    ItemStack spawnerItem(EntityType t, int amt) {
        ItemStack it = new ItemStack(Material.SPAWNER, amt);
        BlockStateMeta bm = (BlockStateMeta) it.getItemMeta();
        CreatureSpawner cs = (CreatureSpawner) bm.getBlockState();
        cs.setSpawnedType(t);
        bm.setBlockState(cs);
        bm.setDisplayName(c("&5Spawners"));
        bm.setLore(List.of(c("&7Type: &f" + nice(t)), c("&7Place it, then interact with an empty hand to open"), c("&7Interact with the same spawner type to stack (sneak = all, normal = one)")));
        it.setItemMeta(bm);
        return it;
    }

    // any amount: split into stacks of 64
    void giveSpawners(Player p, EntityType t, int total) {
        int left = total;
        while (left > 0) {
            int n = Math.min(64, left);
            give(p, spawnerItem(t, n));
            left -= n;
        }
    }

    EntityType spawnerType(ItemStack it) {
        if (it == null || it.getType() != Material.SPAWNER) return null;
        if (it.getItemMeta() instanceof BlockStateMeta bm && bm.getBlockState() instanceof CreatureSpawner cs) return cs.getSpawnedType();
        return null;
    }

    boolean canUse(Player p, SpawnerData sd) {
        return !getConfig().getBoolean("spawner.owner-only", false) || sd.owner.equals(p.getUniqueId()) || p.hasPermission("donutsmp.admin");
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawnerPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.SPAWNER) return;
        EntityType t = spawnerType(e.getItemInHand());
        if (t == null) return;
        Block b = e.getBlockPlaced();
        SpawnerData sd = new SpawnerData(e.getPlayer().getUniqueId(), t, b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        spawners.put(sd.id, sd);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0);
            cs.update();
        }
        msg(e.getPlayer(), "&aPlaced spawner &e" + nice(t) + " &7(interact with an empty hand to open)");
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawnerInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        boolean empty = hand == null || hand.getType().isAir();
        EntityType ht = spawnerType(hand);
        if (!empty && ht == null) return;
        e.setCancelled(true);
        if (!canUse(p, sd)) { msg(p, "&cThis spawner belongs to someone else"); return; }
        if (ht != null) {
            if (ht != sd.type) { msg(p, "&cSpawner types do not match"); return; }
            int room = getConfig().getInt("spawner.max-stack", 100000) - sd.stack;
            if (room <= 0) { msg(p, "&cMaximum stack reached"); return; }
            // sneaking = put in the whole stack in your hand, standing = one at a time
            int put = p.isSneaking() ? Math.min(hand.getAmount(), room) : 1;
            sd.stack += put;
            hand.setAmount(hand.getAmount() - put);
            msg(p, (put == 1 ? "You just added another spawner!" : "You just added " + put + " spawners!") + " There are now " + sd.stack + " spawners in the stack");
            return;
        }
        long nowMs = System.currentTimeMillis();
        Long lastOpen = spawnerOpenAt.get(p.getUniqueId());
        boolean menuOpen = p.getOpenInventory().getTopInventory().getHolder(false) instanceof Gui;
        if (menuOpen || (lastOpen != null && nowMs - lastOpen < 600)) {
            msg(p, "You cannot do this while having a menu open");
            return;
        }
        spawnerOpenAt.put(p.getUniqueId(), nowMs);
        openSpawner(p, sd, 0);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawnerBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getType() != Material.SPAWNER) return;
        SpawnerData sd = spawners.get(key(b));
        if (sd == null) return;
        Player p = e.getPlayer();
        if (!canUse(p, sd)) { e.setCancelled(true); msg(p, "&cThis spawner belongs to someone else"); return; }
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (getConfig().getBoolean("spawner.require-silk-touch", true)
                && (!tool.containsEnchantment(Enchantment.SILK_TOUCH) || !tool.getType().name().endsWith("_PICKAXE"))) {
            e.setCancelled(true);
            msg(p, "&cYou need a Pickaxe with Silk Touch");
            return;
        }
        e.setExpToDrop(0);
        e.setDropItems(false);
        int take = p.isSneaking() ? Math.min(sd.stack, Math.max(1, Math.min(64, getConfig().getInt("spawner.break-amount", 64)))) : 1;
        giveSpawners(p, sd.type, take);
        if (sd.stack > take) {
            sd.stack -= take;
            e.setCancelled(true);
            msg(p, "&eCollected " + take + " spawner(s), remaining &fx" + sd.stack);
        } else {
            spawners.remove(sd.id);
            msg(p, "&eSpawner collected (items left inside are lost)");
        }
    }

    @EventHandler
    public void onSpawnerExplode(EntityExplodeEvent e) {
        if (getConfig().getBoolean("spawner.explosion-protect", true))
            e.blockList().removeIf(b -> b.getType() == Material.SPAWNER && spawners.containsKey(key(b)));
    }

    void produceAll() {
        double dist = getConfig().getDouble("spawner.activation-distance", 16);
        double d2 = dist * dist;
        for (SpawnerData sd : spawners.values()) {
            World w = Bukkit.getWorld(sd.world);
            if (w == null) continue;
            boolean near = false;
            for (Player p : w.getPlayers()) {
                double dx = p.getX() - sd.x, dy = p.getY() - sd.y, dz = p.getZ() - sd.z;
                if (dx * dx + dy * dy + dz * dz <= d2) { near = true; break; }
            }
            if (near) produce(sd);
        }
    }

    void produce(SpawnerData sd) {
        long cap = getConfig().getLong("spawner.max-items", 50000);
        long total = sd.items.values().stream().mapToLong(Long::longValue).sum();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            try {
                String[] a = entry.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null || sd.disabled.contains(m)) continue;
                String[] range = a[1].split("-");
                long lo = Long.parseLong(range[0]) * sd.stack, hi = Long.parseLong(range[1]) * sd.stack;
                long amt = lo >= hi ? lo : r.nextLong(lo, hi + 1);
                amt = Math.min(amt, Math.max(0, cap - total));
                if (amt <= 0) continue;
                sd.items.merge(m, amt, Long::sum);
                total += amt;
            } catch (Exception ignored) { }
        }
        long maxXp = getConfig().getLong("spawner.max-xp", 100000);
        sd.xp = Math.min(maxXp, sd.xp + getConfig().getLong("spawner.xp-per-cycle", 5) * sd.stack);
    }

    long takeFromSpawner(Player p, SpawnerData sd, Material m, long want) {
        long have = sd.items.getOrDefault(m, 0L);
        want = Math.min(want, have);
        long given = 0;
        while (given < want) {
            int st = (int) Math.min(want - given, m.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(m, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        if (given > 0) {
            long rem = have - given;
            if (rem <= 0) sd.items.remove(m); else sd.items.put(m, rem);
        }
        return given;
    }

    Material mobIconMat(EntityType t) {
        Material m = switch (t) {
            case ZOMBIE -> Material.ZOMBIE_HEAD;
            case SKELETON -> Material.SKELETON_SKULL;
            case WITHER_SKELETON -> Material.WITHER_SKELETON_SKULL;
            case CREEPER -> Material.CREEPER_HEAD;
            case ZOMBIFIED_PIGLIN -> Material.PIGLIN_HEAD;
            default -> null;
        };
        if (m == null) m = Material.matchMaterial(t.name() + "_SPAWN_EGG");
        return m == null ? Material.PLAYER_HEAD : m;
    }

    // chance (percent) that an item is produced in one spawn cycle, from the "ITEM:min-max" config entries
    List<String> dropChanceLines(SpawnerData sd) {
        List<String> lines = new ArrayList<>();
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            try {
                String[] a = entry.split(":");
                Material m = Material.matchMaterial(a[0]);
                if (m == null) continue;
                String[] range = a[1].split("-");
                long lo = Long.parseLong(range[0]), hi = Long.parseLong(range[1]);
                double chance = hi <= 0 ? 0 : (lo > 0 ? 100.0 : 100.0 * hi / (hi + 1.0));
                boolean off = sd.disabled.contains(m);
                lines.add(c((off ? "&c" : "&7") + pretty(m) + ": " + (off ? "&c" : "&a") + Math.round(chance) + "%" + (off ? " (OFF)" : "")));
            } catch (Exception ignored) { }
        }
        return lines;
    }

    double spawnerTotalValue(SpawnerData sd) {
        double total = 0;
        for (Map.Entry<Material, Long> en : sd.items.entrySet()) total += en.getValue() * sellPrice(en.getKey());
        return total;
    }

    void openSpawner(Player p, SpawnerData sd, int page) {
        List<Material> mats = new ArrayList<>(sd.items.keySet());
        mats.removeIf(x -> sd.items.getOrDefault(x, 0L) <= 0);
        mats.sort(Comparator.comparing(Enum::name));
        List<Material> sm = new ArrayList<>();
        List<Integer> sc = new ArrayList<>();
        for (Material mm : mats) {
            long left = sd.items.get(mm);
            int max = mm.getMaxStackSize();
            while (left > 0 && sm.size() < 5000) {
                int st = (int) Math.min(left, max);
                sm.add(mm);
                sc.add(st);
                left -= st;
            }
        }
        int pages = Math.max(1, (sm.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("spawner");
        g.sp = sd;
        g.page = page;
        String title = sd.stack + " " + nice(sd.type).toUpperCase(Locale.ROOT) + " SPAWNERS" + (pages > 1 ? " (" + (page + 1) + "/" + pages + ")" : "");
        g.inv = Bukkit.createInventory(g, 54, c("&8" + title));
        for (int i = page * 45; i < Math.min(sm.size(), page * 45 + 45); i++) {
            Material m = sm.get(i);
            int cnt = sc.get(i);
            ItemStack it = new ItemStack(m, cnt);
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7Value: &a$" + fmt(cnt * sellPrice(m))), c("&eClick = take this stack")));
            it.setItemMeta(mt);
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
            g.counts.add(cnt);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        g.inv.setItem(48, item(Material.GOLD_BLOCK, "&6Sell", "&7Sell everything stored in this spawner", "&eClick to open"));
        g.inv.setItem(50, item(Material.DROPPER, "&6Drop Items", "&7Drops the items on this page", "&7in the direction you are looking"));
        List<String> headLore = new ArrayList<>();
        headLore.add(c("&7Spawners: &f" + sd.stack));
        headLore.add("");
        headLore.addAll(dropChanceLines(sd));
        g.inv.setItem(49, item(mobIconMat(sd.type), "&f" + nice(sd.type) + " Spawners", headLore.toArray(new String[0])));
        p.openInventory(g.inv);
    }

    void openSpawnerSell(Player p, SpawnerData sd) {
        Gui g = new Gui("spawnersell");
        g.sp = sd;
        g.inv = Bukkit.createInventory(g, 27, c("&8Sell Items"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cCancel", "&7Go back"));
        double total = spawnerTotalValue(sd);
        g.inv.setItem(13, item(mobIconMat(sd.type), "&f" + nice(sd.type) + " Spawners",
                "&7Level: &f" + sd.stack,
                "&7Price: &a$" + fmt(total)));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aConfirm", "&7Click to sell everything"));
        p.openInventory(g.inv);
    }

    void openSpawnerFilter(Player p, SpawnerData sd) {
        Gui g = new Gui("spawnerfilter");
        g.sp = sd;
        g.inv = Bukkit.createInventory(g, 27, c("&8" + nice(sd.type) + " - Choose Dropped Items"));
        int i = 0;
        for (String entry : getConfig().getStringList("spawner.drops." + sd.type.name())) {
            if (i >= 9) break;
            Material m = Material.matchMaterial(entry.split(":")[0]);
            if (m == null) continue;
            boolean off = sd.disabled.contains(m);
            g.inv.setItem(i, item(m, (off ? "&c" : "&a") + m.name(), off ? "&c✘ OFF (won't drop)" : "&a✔ ON (drops)", "&eClick to toggle"));
            g.inv.setItem(i + 9, item(off ? Material.RED_DYE : Material.LIME_DYE, off ? "&cOFF" : "&aON", "&7Click to toggle"));
            g.mats.add(m);
            i++;
        }
        g.inv.setItem(22, item(Material.ARROW, "&e« Back"));
        p.openInventory(g.inv);
    }

    void placeSpawner(Block b, EntityType t, UUID owner, int stack) {
        b.setType(Material.SPAWNER, false);
        if (b.getState() instanceof CreatureSpawner cs) {
            cs.setSpawnedType(t);
            cs.setRequiredPlayerRange(0);
            cs.update(true, false);
        }
        SpawnerData sd = new SpawnerData(owner, t, b.getWorld().getName(), b.getX(), b.getY(), b.getZ());
        sd.stack = stack;
        spawners.put(sd.id, sd);
    }

    // ---------- 3x3 Tools ----------
    private NamespacedKey hammerKey;

    NamespacedKey hk() {
        if (hammerKey == null) hammerKey = new NamespacedKey(this, "hammer3x3");
        return hammerKey;
    }

    void tagHammer(ItemStack it) {
        ItemMeta mt = it.getItemMeta();
        mt.getPersistentDataContainer().set(hk(), PersistentDataType.BYTE, (byte) 1);
        mt.setLore(List.of(c("&dAmethyst 3x3 Mining"), c("&7Front: 3x3  |  Up/Down: 3x1"), c("&7Hold Shift = mine a single block")));
        it.setItemMeta(mt);
    }

    // ---------- Sell Axe: breaking a container sells everything inside it ----------
    private NamespacedKey sellAxeKey;

    NamespacedKey sk() {
        if (sellAxeKey == null) sellAxeKey = new NamespacedKey(this, "sellaxe");
        return sellAxeKey;
    }

    void tagSellAxe(ItemStack it) {
        ItemMeta mt = it.getItemMeta();
        mt.getPersistentDataContainer().set(sk(), PersistentDataType.BYTE, (byte) 1);
        mt.setLore(List.of(c("&6Sell Axe"), c("&7Break a chest / barrel / shulker box"), c("&7and everything inside is sold automatically")));
        it.setItemMeta(mt);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSellAxeBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir() || !tool.hasItemMeta()) return;
        if (!tool.getItemMeta().getPersistentDataContainer().has(sk(), PersistentDataType.BYTE)) return;
        Block b = e.getBlock();
        if (!(b.getState() instanceof org.bukkit.block.Container cont)) return;
        Inventory inv = cont instanceof org.bukkit.block.Chest ch ? ch.getBlockInventory() : cont.getInventory();
        double total = 0;
        long count = 0;
        for (ItemStack st : inv.getContents()) {
            if (st == null || st.getType().isAir()) continue;
            total += st.getAmount() * sellPrice(st.getType());
            count += st.getAmount();
        }
        e.setCancelled(true);   // the container is NOT broken, only its contents are sold
        if (count <= 0) { msg(p, "&cNothing to sell in this container"); return; }
        inv.clear();
        add(p.getUniqueId(), total);
        msg(p, "You sold " + count + " items for $" + fmt(total));
        notifyFollowers(p, "sell", "sold " + count + " items for $" + fmt(total));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    boolean canHammer(Block b, ItemStack tool) {
        Material t = b.getType();
        if (t.isAir() || b.isLiquid() || t == Material.BEDROCK || t == Material.SPAWNER || t.getHardness() < 0) return false;
        if (!b.isPreferredTool(tool)) return false;
        if (b.getState() instanceof TileState) return false;
        return !spawners.containsKey(key(b));
    }

    void damageTool(Player p, ItemStack tool, int amount) {
        if (tool.getItemMeta() instanceof Damageable d && !d.isUnbreakable()) {
            int nd = d.getDamage() + amount;
            if (nd >= tool.getType().getMaxDurability()) {
                p.getInventory().setItemInMainHand(null);
            } else {
                d.setDamage(nd);
                tool.setItemMeta(d);
            }
        }
    }

    void purpleFx(Block b) {
        b.getWorld().spawnParticle(Particle.DUST, b.getLocation().add(0.5, 0.5, 0.5), 12, 0.3, 0.3, 0.3, 0,
                new Particle.DustOptions(Color.fromRGB(170, 0, 255), 1.6f));
        b.getWorld().spawnParticle(Particle.WITCH, b.getLocation().add(0.5, 0.5, 0.5), 6, 0.3, 0.3, 0.3, 0);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHammerBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir() || !tool.hasItemMeta()) return;
        if (!tool.getItemMeta().getPersistentDataContainer().has(hk(), PersistentDataType.BYTE)) return;
        if (p.isSneaking()) return;
        Block origin = e.getBlock();
        BlockFace face = BlockFace.UP;
        RayTraceResult r = p.rayTraceBlocks(8);
        if (r != null && r.getHitBlockFace() != null && origin.equals(r.getHitBlock())) face = r.getHitBlockFace();
        purpleFx(origin);
        origin.getWorld().playSound(origin.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.0f);
        origin.getWorld().playSound(origin.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1.0f, 1.0f);
        int broken = 0;
        boolean vertical = face == BlockFace.UP || face == BlockFace.DOWN;
        BlockFace look = p.getFacing();
        boolean alongX = look == BlockFace.NORTH || look == BlockFace.SOUTH;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;
                if (vertical && dy != 0) continue;   // mining up/down = a row of 3 (3x1)
                Block b = switch (face) {
                    case UP, DOWN -> alongX ? origin.getRelative(dx, 0, 0) : origin.getRelative(0, 0, dx);
                    case NORTH, SOUTH -> origin.getRelative(dx, dy, 0);
                    default -> origin.getRelative(0, dy, dx);
                };
                if (!canBuild(p, b)) continue;
                if (!canHammer(b, tool)) continue;
                purpleFx(b);
                b.breakNaturally(tool);
                broken++;
            }
        }
        if (broken > 0) {
            mined.merge(p.getUniqueId(), (long) broken, Long::sum);
            // hammers are tough: only 1 durability per 3 extra blocks, and Unbreaking still applies
            int wear = 0;
            int ub = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
            for (int i = 0; i < Math.max(1, broken / 3); i++)
                if (ub <= 0 || ThreadLocalRandom.current().nextInt(ub + 1) == 0) wear++;
            if (wear > 0) damageTool(p, tool, wear);
        }
    }


    // Display order: OWNER, ADMIN, camera (CREATOR), then + / ++ / +++ always AFTER the camera
    static final List<String> RANK_ORDER = List.of("OWNER", "ADMIN", "CREATOR", "PLUS", "PLUS2", "PLUS3");

    static String normalizeRank(String in) {
        String rk = in.toUpperCase(Locale.ROOT);
        if (rk.equals("+\uD83D\uDCF7") || rk.equals("\uD83D\uDCF7") || rk.equals("CAMERA") || rk.equals("CAM") || rk.equals("CREATE")) return "CREATOR";
        if (rk.equals("+") || rk.equals("1")) return "PLUS";
        if (rk.equals("++") || rk.equals("2")) return "PLUS2";
        if (rk.equals("+++") || rk.equals("3")) return "PLUS3";
       
        return rk;
    }

    List<String> ranksOf(UUID id) {
        List<String> out = new ArrayList<>();
        if (data.isList("ranks." + id)) out.addAll(data.getStringList("ranks." + id));
        else if (data.isString("ranks." + id)) out.add(data.getString("ranks." + id));   // old single-rank data
        out.removeIf(r -> !rankExists(r));
        out.sort(Comparator.comparingInt((String r) -> { int k = RANK_ORDER.indexOf(r); return k < 0 ? 99 : k; }));
        return out;
    }

    void saveRanks(UUID id, List<String> list) {
        data.set("ranks." + id, list.isEmpty() ? null : list);
        Bukkit.getScheduler().runTask(this, () -> {
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) refreshStaffPerms(pl);
        });
    }

    // ---------- Bans made with /offend ----------
    record BanInfo(String reason, long until, String id) { }   // until = 0 -> permanent

    private final Map<UUID, BanInfo> bans = new java.util.concurrent.ConcurrentHashMap<>();

    static String dhms(long sec) {
        sec = Math.max(0, sec);
        return (sec / 86400) + "d " + (sec % 86400 / 3600) + "h " + (sec % 3600 / 60) + "m " + (sec % 60) + "s";
    }

    // 0 = permanent, -1 = invalid. Accepts 30m, 12h, 14d, 2w, 1d12h30m, perm
    long parseBanSeconds(String t) {
        t = t.toLowerCase(Locale.ROOT).trim();
        if (t.equals("perm") || t.equals("permanent") || t.equals("forever")) return 0;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)([wdhms])").matcher(t);
        long total = 0;
        int end = 0;
        while (m.find()) {
            if (m.start() != end) return -1;
            end = m.end();
            long n = Long.parseLong(m.group(1));
            long unit = switch (m.group(2).charAt(0)) { case 'w' -> 604800L; case 'd' -> 86400L; case 'h' -> 3600L; case 'm' -> 60L; default -> 1L; };
            total += n * unit;
        }
        return end == t.length() && total > 0 ? total : -1;
    }

    String genBanId() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) sb.append(chars.charAt(ThreadLocalRandom.current().nextInt(chars.length())));
        return sb.toString();
    }

    Component banScreen(BanInfo b) {
        String left = b.until() == 0 ? "Permanent" : dhms((b.until() - System.currentTimeMillis()) / 1000);
        return LegacyComponentSerializer.legacySection().deserialize("\u00a7fConnection Lost\n\n\u00a7cYou have been banned for " + b.reason()
                + "\n\n\u00a7fTime left: " + left + "\n\n\u00a7fBan ID: " + b.id());
    }

    @EventHandler
    public void onPreLogin(org.bukkit.event.player.AsyncPlayerPreLoginEvent e) {
        BanInfo b = bans.get(e.getUniqueId());
        if (b == null) return;
        if (b.until() != 0 && b.until() <= System.currentTimeMillis()) { bans.remove(e.getUniqueId()); return; }
        e.disallow(org.bukkit.event.player.AsyncPlayerPreLoginEvent.Result.KICK_BANNED, banScreen(b));
    }

    // /pardon <name> also lifts a ban made with /offend
    void handlePardon(String text) {
        String[] parts = text.trim().split("\\s+");
        if (parts.length < 2) return;
        String cmd = parts[0].toLowerCase(Locale.ROOT).replace("/", "").replace("minecraft:", "");
        if (!cmd.equals("pardon")) return;
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(parts[1]);
        if (op != null && bans.remove(op.getUniqueId()) != null) saveData();
    }

    @EventHandler
    public void onPardonPlayer(org.bukkit.event.player.PlayerCommandPreprocessEvent e) {
        if (e.getPlayer().hasPermission("minecraft.command.pardon")) handlePardon(e.getMessage());
    }

    @EventHandler
    public void onPardonConsole(org.bukkit.event.server.ServerCommandEvent e) {
        handlePardon("/" + e.getCommand());
    }

    // ---------- /settingall : change everything on the server ----------
    void openSettingAll(Player p) {
        Gui g = new Gui("settingall");
        g.inv = Bukkit.createInventory(g, 27, c("&8Server Settings"));
        g.inv.setItem(11, item(Material.GOLD_INGOT, "&6Prices", "&7Change the /sell and /shop price of every item"));
        g.inv.setItem(13, item(Material.COMPARATOR, "&bServer Settings", "&7Change every value of the plugin config", "&7(spawners, shards, homes, combat ...)"));
        g.inv.setItem(15, item(Material.EMERALD, "&aReload config", "&7Reload config.yml from the disk"));
        p.openInventory(g.inv);
    }

    void openCfg(Player p, String path, int page) {
        ConfigurationSection sec = path.isEmpty() ? getConfig() : getConfig().getConfigurationSection(path);
        if (sec == null) { openCfg(p, "", 0); return; }
        List<String> keys = new ArrayList<>(sec.getKeys(false));
        keys.remove("config-version");
        int pages = Math.max(1, (keys.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("cfg");
        g.page = page;
        g.filter = path;
        String shown = path.isEmpty() ? "Settings" : path;
        if (shown.length() > 26) shown = "..." + shown.substring(shown.length() - 23);
        g.inv = Bukkit.createInventory(g, 54, c("&8" + shown + " (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(keys.size(), page * 45 + 45); i++) {
            String k = keys.get(i);
            String full = path.isEmpty() ? k : path + "." + k;
            Object v = sec.get(k);
            ItemStack it;
            String kind;
            if (v instanceof ConfigurationSection sub) {
                kind = "S";
                it = item(Material.CHEST, "&6" + k, "&7" + sub.getKeys(false).size() + " entries", "&eClick to open");
            } else if (v instanceof Boolean bv) {
                kind = "B";
                it = item(bv ? Material.LIME_DYE : Material.GRAY_DYE, "&f" + k, "&7Value: " + (bv ? "&atrue" : "&cfalse"), "&eClick to toggle");
            } else if (v instanceof Number) {
                kind = "N";
                it = item(Material.PAPER, "&f" + k, "&7Value: &e" + v, "&eClick to change");
            } else if (v instanceof String sv) {
                kind = "T";
                it = item(Material.NAME_TAG, "&f" + k, "&7Value: &f" + (sv.length() > 40 ? sv.substring(0, 40) + "..." : sv).replace('&', '+'), "&eClick to change");
            } else {
                kind = "L";
                it = item(Material.BOOK, "&f" + k, "&7List - edit it in config.yml");
            }
            g.inv.setItem(i - page * 45, it);
            g.names.add(kind + "|" + full);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(48, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.PAPER, "&e" + (path.isEmpty() ? "config.yml" : path), "&7Some settings need a restart to apply"));
        p.openInventory(g.inv);
    }

    // ---------- /settingmn : change /sell and /shop prices ----------
    private final Map<UUID, Boolean> priceShopMode = new HashMap<>();   // false = sell prices, true = shop prices
    private final Map<UUID, String> priceSearch = new HashMap<>();

    void openPriceMgr(Player p, int page) {
        UUID id = p.getUniqueId();
        boolean shop = priceShopMode.getOrDefault(id, false);
        String f = priceSearch.getOrDefault(id, "").toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Material> icons = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        if (!shop) {
            for (Material m : allItems()) if (f.isEmpty() || m.name().contains(f)) { icons.add(m); keys.add(m.name()); }
        } else {
            ConfigurationSection si = getConfig().getConfigurationSection("shop-items");
            if (si != null) for (String cat : si.getKeys(false)) {
                ConfigurationSection cs = si.getConfigurationSection(cat);
                if (cs == null) continue;
                for (String key : cs.getKeys(false)) {
                    Material m = isSetKey(key)
                            ? Material.matchMaterial(key.substring(0, key.length() - "_ARMOR_SET".length()) + "_CHESTPLATE")
                            : Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
                    if (m == null || !m.isItem()) continue;
                    if (!f.isEmpty() && !key.toUpperCase(Locale.ROOT).contains(f)) continue;
                    icons.add(m);
                    keys.add(cat + "|" + key);
                }
            }
        }
        int pages = Math.max(1, (icons.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("pricemgr");
        g.page = page;
        g.filter = shop ? "shop" : "sell";
        g.inv = Bukkit.createInventory(g, 54, c("&8Price Manager - " + (shop ? "Shop" : "Sell") + " (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(icons.size(), page * 45 + 45); i++) {
            Material m = icons.get(i);
            String pkey = keys.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta mt = it.getItemMeta();
            if (mt == null) continue;
            if (shop) {
                String cat = pkey.substring(0, pkey.indexOf('|'));
                String key = pkey.substring(pkey.indexOf('|') + 1);
                mt.setDisplayName(c("&f" + key + " &7[" + cat + "]"));
                mt.setLore(List.of(c("&7Shop price: &a$" + fmt(shopPrice(cat, key))), c("&eClick to change the price")));
            } else {
                mt.setLore(List.of(c("&7Sell price: &a$" + fmt(sellPrice(m))), c("&eClick to change the price")));
            }
            it.setItemMeta(mt);
            g.inv.setItem(i - page * 45, it);
            g.names.add(pkey);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(47, item(shop ? Material.CHEST : Material.GOLD_INGOT, "&6Editing: &f" + (shop ? "Shop prices" : "Sell prices"), "&7Click to switch"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Item", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a name"));
        if (!f.isEmpty()) g.inv.setItem(51, item(Material.BARRIER, "&cClear search"));
        p.openInventory(g.inv);
    }

    // text: a price (1000, 1.5k, 2m) or "reset" to go back to the default
    String applyPriceEdit(boolean shop, String pkey, String text) {
        if (text == null || text.isBlank()) return null;
        String path;
        String label;
        if (shop) {
            String cat = pkey.substring(0, pkey.indexOf('|'));
            String key = pkey.substring(pkey.indexOf('|') + 1);
            path = "prices.shop." + cat + "." + key;
            label = key;
        } else {
            path = "prices.sell." + pkey;
            label = pkey;
        }
        if (text.trim().equalsIgnoreCase("reset")) {
            data.set(path, null);
            saveData();
            return "&aPrice of &e" + label + " &areset to default";
        }
        double v = parseAmount(text.trim());
        if (v < 0 || (shop && v <= 0)) return "&cInvalid price";
        data.set(path, v);
        saveData();
        return "&aPrice of &e" + label + " &aset to &e$" + fmt(v);
    }

    // ---------- /offend + /sus ----------
    static final String[] OFFENCES = {"ESP", "AutoClicker", "HackedClient", "Cheating", "XRAY"};

    static String offenceKey(String in) { return in.toLowerCase(Locale.ROOT).replaceAll("[\\s_\\-]", ""); }

    String offenceOf(String in) {
        String k = offenceKey(in);
        for (String o : OFFENCES) if (offenceKey(o).equals(k)) return o;
        return null;
    }

    void openSus(Player p, int page) {
        List<Player> list = new ArrayList<>(Bukkit.getOnlinePlayers());
        list.remove(p);
        list.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("sus");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8Players (" + list.size() + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Player t = list.get(i);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(t);
            sm.setDisplayName(c("&f" + t.getName()));
            Location tl = t.getLocation();
            sm.setLore(List.of(c("&7" + tl.getWorld().getName() + " " + tl.getBlockX() + ", " + tl.getBlockY() + ", " + tl.getBlockZ()), c("&eClick to teleport")));
            head.setItemMeta(sm);
            g.inv.setItem(i - page * 45, head);
            g.uuids.add(t.getUniqueId());
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e« Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page »"));
        p.openInventory(g.inv);
    }

    // ---------- Rank permissions ----------
    private final Map<UUID, org.bukkit.permissions.PermissionAttachment> permAttach = new HashMap<>();

    // ADMIN / OWNER rank (or op / console)
    boolean isStaff(CommandSender s) {
        if (!(s instanceof Player pl)) return true;
        if (pl.hasPermission("donutsmp.admin")) return true;
        List<String> r = ranksOf(pl.getUniqueId());
        return r.contains("ADMIN") || r.contains("OWNER");
    }

    // /fly: ADMIN, OWNER and the +++ rank
    boolean canFly(Player p) {
        return isStaff(p) || ranksOf(p.getUniqueId()).contains("PLUS3") || hasAbility(p.getUniqueId(), "fly");
    }

    // staff ranks get the vanilla /ban /ban-ip /pardon commands; flight is removed again when the rank is gone
    void refreshStaffPerms(Player p) {
        org.bukkit.permissions.PermissionAttachment old = permAttach.remove(p.getUniqueId());
        if (old != null) {
            try { p.removeAttachment(old); } catch (IllegalArgumentException ignored) { }
        }
        Set<String> nodes = new LinkedHashSet<>(rankNodes(p.getUniqueId()));   // permission nodes given by custom ranks
        if (isStaff(p)) nodes.addAll(List.of("minecraft.command.ban", "minecraft.command.ban-ip", "minecraft.command.pardon"));
        if (!nodes.isEmpty()) {
            org.bukkit.permissions.PermissionAttachment at = p.addAttachment(this);
            for (String node : nodes) at.setPermission(node, true);
            permAttach.put(p.getUniqueId(), at);
        }
        GameMode gm = p.getGameMode();
        if (!canFly(p) && p.getAllowFlight() && (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE)) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
        p.updateCommands();
    }

    String rankPrefix(UUID id) {
        StringBuilder sb = new StringBuilder();
        for (String r : ranksOf(id)) sb.append(rankPrefixOf(r));
        return c(sb.toString());
    }

    void updateNameTags(Scoreboard sb) {
        Objective bn = sb.getObjective("donut_money");
        for (Player t : Bukkit.getOnlinePlayers()) {
            if (bn != null) {
                Score sc = bn.getScore(t.getName());
                double money0 = bal(t.getUniqueId());
                sc.setScore((int) Math.min(Integer.MAX_VALUE, money0));
                // show the money short, e.g. 10.5M instead of 10500000
                // under the name: "$10.5M | N/A"  (money | team, N/A when the player has no team)
                boolean ht = hasTeam(t.getUniqueId());
                sc.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.fixed(
                        Component.text("$" + fmt(money0), NamedTextColor.GREEN)
                                .append(Component.text(" | ", NamedTextColor.GRAY))
                                .append(Component.text(teamName(t.getUniqueId()), ht ? NamedTextColor.BLUE : NamedTextColor.GRAY))));
            }
            String tn = "rk_" + t.getUniqueId().toString().replace("-", "").substring(0, 12);
            Team tm = sb.getTeam(tn);
            if (tm == null) tm = sb.registerNewTeam(tn);
            if (!tm.hasEntry(t.getName())) tm.addEntry(t.getName());
            tm.setPrefix(rankPrefix(t.getUniqueId()) + teamTag(t.getUniqueId()));   // [team] above the head
            tm.setSuffix(c(" &8[" + pingText(t) + "&8]"));   // ping after the name above the head, refreshed every second
        }
        for (Team tm : new ArrayList<>(sb.getTeams())) {
            if (!tm.getName().startsWith("rk_")) continue;
            boolean alive = false;
            for (String en : tm.getEntries()) {
                if (Bukkit.getPlayerExact(en) != null) { alive = true; break; }
            }
            if (!alive) tm.unregister();
        }
    }

    // Chat: hover over a player's name -> click opens their stats window (with TPA / TPHERE buttons)
    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncChatEvent e) {
        Player sender = e.getPlayer();
        e.viewers().removeIf(v -> v instanceof Player r && !r.equals(sender) && !setting(r.getUniqueId(), "chat", true));
        final String pre = rankPrefix(sender.getUniqueId());
        final String pname = sender.getName();
        e.renderer((source, displayName, message, viewer) -> {
            Component name = displayName
                    .hoverEvent(HoverEvent.showText(Component.text(pname, NamedTextColor.AQUA)
                            .append(Component.newline())
                            .append(Component.text("Click to view stats", NamedTextColor.YELLOW))
                            .append(Component.newline())
                            .append(Component.text("(TPA / TPHERE available there)", NamedTextColor.GRAY))))
                    .clickEvent(ClickEvent.runCommand("/stats " + pname));
            Component out = Component.empty();
            if (!pre.isEmpty()) {
                out = out.append(LegacyComponentSerializer.legacySection().deserialize(pre)).append(name).append(Component.text(": "));
            } else {
                out = out.append(Component.text("<")).append(name).append(Component.text("> "));
            }
            return out.append(message.colorIfAbsent(NamedTextColor.WHITE));
        });
    }


    static class SignPrompt {
        final Location loc; final BlockData original; final Consumer<String> cb;
        SignPrompt(Location loc, BlockData original, Consumer<String> cb) { this.loc = loc; this.original = original; this.cb = cb; }
    }

    private final Map<UUID, SignPrompt> signPrompts = new HashMap<>();

    boolean signPrompt(Player p, String[] lines, Consumer<String> cb) {
        restoreSign(p.getUniqueId());
        Block base = p.getLocation().getBlock();
        World w = p.getWorld();
        int[][] offs = {{0, 2, 0}, {1, 2, 0}, {-1, 2, 0}, {0, 2, 1}, {0, 2, -1}, {0, 3, 0}, {1, 1, 0}, {-1, 1, 0}, {0, 1, 1}, {0, 1, -1}};
        Block target = null;
        for (int[] o : offs) {
            Block b = base.getRelative(o[0], o[1], o[2]);
            if (b.getY() < w.getMinHeight() || b.getY() >= w.getMaxHeight()) continue;
            if (b.isLiquid() || b.getState() instanceof TileState) continue;
            target = b;
            break;
        }
        if (target == null) { msg(p, "&cCannot open a sign here. Move to an open area and try again."); return false; }
        BlockData orig = target.getBlockData();
        target.setType(Material.OAK_SIGN, false);
        if (target.getState() instanceof Sign sign) {
            org.bukkit.block.sign.SignSide front = sign.getSide(Side.FRONT);
            for (int i = 0; i < 4; i++) front.line(i, Component.text(i < lines.length ? lines[i] : ""));
            sign.update(true, false);
            signPrompts.put(p.getUniqueId(), new SignPrompt(target.getLocation(), orig, cb));
            final Block tb = target;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                SignPrompt cur = signPrompts.get(p.getUniqueId());
                if (cur == null || !p.isOnline() || !(tb.getState() instanceof Sign s2)) return;
                p.openSign(s2, Side.FRONT);
                StringBuilder pb = new StringBuilder();
                for (int i = 1; i < lines.length; i++) {
                    String ln = lines[i];
                    if (ln == null || ln.isBlank() || ln.startsWith("^")) continue;
                    if (pb.length() > 0) pb.append(' ');
                    pb.append(ln);
                }
                if (pb.length() > 0) {
                    p.showTitle(net.kyori.adventure.title.Title.title(Component.empty(), Component.text(pb.toString(), NamedTextColor.YELLOW),
                            net.kyori.adventure.title.Title.Times.times(java.time.Duration.ZERO, java.time.Duration.ofSeconds(60), java.time.Duration.ZERO)));
                }
            }, 2L);
            return true;
        } else {
            target.setBlockData(orig, false);
            return false;
        }
    }

    void restoreSign(UUID id) {
        SignPrompt sp = signPrompts.remove(id);
        if (sp != null) {
            sp.loc.getBlock().setBlockData(sp.original, false);
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) pl.clearTitle();
        }
    }

    @EventHandler
    public void onSignChange(SignChangeEvent e) {
        SignPrompt sp = signPrompts.get(e.getPlayer().getUniqueId());
        if (sp == null || !e.getBlock().equals(sp.loc.getBlock())) return;
        e.setCancelled(true);
        e.getPlayer().clearTitle();
        String text = e.getLine(0);
        String result = text == null ? "" : text.trim();
        signPrompts.remove(e.getPlayer().getUniqueId());
        sp.loc.getBlock().setBlockData(sp.original, false);
        Bukkit.getScheduler().runTask(this, () -> sp.cb.accept(result));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID q = e.getPlayer().getUniqueId();
        e.quitMessage(Component.text(e.getPlayer().getName() + " left the game", NamedTextColor.WHITE));
        restoreSign(q);
        ItemStack pend = ahPending.remove(q);
        if (pend != null) give(e.getPlayer(), pend);
        rtpQueue.remove(q);
        combatUntil.remove(q);
        permAttach.remove(q);
    }

    // ---------- Team ----------
    void teamCmd(Player p, String[] a) {
        UUID id = p.getUniqueId();
        if (a.length == 0) { msg(p, "&e/team create <name> | invite <player> | accept | leave | info"); return; }
        String cur = data.getString("playerTeam." + id);
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (cur != null) { msg(p, "&cYou are already in a team"); return; }
                if (a.length < 2 || !a[1].matches("[A-Za-z0-9_]{2,12}")) { msg(p, "&e/team create <name> &7(A-Z 0-9 _ , 2-12 characters)"); return; }
                String key = a[1].toLowerCase(Locale.ROOT);
                if (data.contains("teams." + key)) { msg(p, "&cThat team name is already taken"); return; }
                data.set("teams." + key + ".name", a[1]);
                data.set("teams." + key + ".leader", id.toString());
                data.set("teams." + key + ".members", new ArrayList<>(List.of(id.toString())));
                data.set("playerTeam." + id, key);
                msg(p, "&aCreated team &e" + a[1]);
            }
            case "invite" -> {
                if (cur == null) { msg(p, "&cYou are not in a team"); return; }
                if (a.length < 2) { msg(p, "&e/team invite <player>"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null || t == p) { msg(p, "&cPlayer not found"); return; }
                if (data.getString("playerTeam." + t.getUniqueId()) != null) { msg(p, "&cThat player already has a team"); return; }
                teamInvites.put(t.getUniqueId(), cur);
                msg(p, "&aInvited &e" + t.getName());
                msg(t, "&e" + p.getName() + " &finvited you to team &e" + teamName(id) + " &7- type &a/team accept");
            }
            case "accept" -> {
                String key = teamInvites.remove(id);
                if (key == null || !data.contains("teams." + key)) { msg(p, "&cNo pending invite"); return; }
                if (cur != null) { msg(p, "&cYou are already in a team"); return; }
                List<String> members = data.getStringList("teams." + key + ".members");
                if (members.size() >= getConfig().getInt("team.max-members", 5)) { msg(p, "&cThe team is full"); return; }
                members.add(id.toString());
                data.set("teams." + key + ".members", members);
                data.set("playerTeam." + id, key);
                msg(p, "&aJoined team &e" + data.getString("teams." + key + ".name"));
            }
            case "leave" -> {
                if (cur == null) { msg(p, "&cYou are not in a team"); return; }
                List<String> members = data.getStringList("teams." + cur + ".members");
                if (id.toString().equals(data.getString("teams." + cur + ".leader"))) {
                    for (String m : members) data.set("playerTeam." + m, null);
                    data.set("teams." + cur, null);
                    msg(p, "&eYou were the leader, so the team was disbanded");
                } else {
                    members.remove(id.toString());
                    data.set("teams." + cur + ".members", members);
                    data.set("playerTeam." + id, null);
                    msg(p, "&eYou left the team");
                }
            }
            case "info" -> {
                if (cur == null) { msg(p, "&cYou are not in a team"); return; }
                String names = data.getStringList("teams." + cur + ".members").stream()
                        .map(u -> Optional.ofNullable(Bukkit.getOfflinePlayer(UUID.fromString(u)).getName()).orElse("?"))
                        .collect(Collectors.joining(", "));
                msg(p, "&eTeam &f" + teamName(id) + " &7| Members: &f" + names);
            }
            default -> msg(p, "&e/team create | invite | accept | leave | info");
        }
    }

    // ---------- /shop ----------
    // ---------- /shop : one big paged page, black glass = slots staff can fill with any item ----------
    private static final int[] SHOP_NAV = {45, 48, 49, 50};   // 45 = buy amount, 48 = previous, 49 = search, 50 = next
    private static final int SHOP_PER_PAGE = 50;
    private static final int SHOP_MAX_PAGES = 5;   // the shop never has more than 5 pages
    private static final List<Integer> SHOP_SLOTS = new ArrayList<>();
    static {
        // every cell except the navigation buttons is a black glass slot that staff can fill
        for (int i = 0; i < 54; i++) {
            boolean nav = false;
            for (int n : SHOP_NAV) if (n == i) nav = true;
            if (!nav) SHOP_SLOTS.add(i);
        }
    }
    private final Map<UUID, String> shopSearch = new HashMap<>();
    private final Map<UUID, String> shopPickSearch = new HashMap<>();

    static boolean inArr(int[] arr, int v) {
        for (int x : arr) if (x == v) return true;
        return false;
    }

    // what sits in one slot: "cus:MATERIAL|quantity" or null (black glass)
    String shopSlotContent(int page, int slot) {
        String b = "shopslots." + page + "." + slot;
        String cm = data.getString(b + ".item");
        if (cm == null || cm.equals("NONE")) return null;
        return "cus:" + cm + "|" + data.getInt(b + ".qty", 1);
    }

    // last page (0-based) that has at least one item, 0 when the shop is empty
    int shopLastUsedPage() {
        int last = 0;
        for (int pg = 0; pg < SHOP_MAX_PAGES; pg++)
            for (int sl : SHOP_SLOTS) if (shopSlotContent(pg, sl) != null) { last = pg; break; }
        return last;
    }

    // every shop entry as "category|key", categories in menu order, cheapest first inside a category
    List<String> shopEntries(String f) {
        List<String> out = new ArrayList<>();
        ConfigurationSection si = getConfig().getConfigurationSection("shop-items");
        if (si == null) return out;
        List<String> cats = new ArrayList<>();
        for (Map<?, ?> m : getConfig().getMapList("shop-menu.categories")) cats.add(String.valueOf(m.get("id")));
        for (String k : si.getKeys(false)) if (!cats.contains(k)) cats.add(k);
        for (String cat : cats) {
            ConfigurationSection cs = si.getConfigurationSection(cat);
            if (cs == null) continue;
            List<String> keys = new ArrayList<>(cs.getKeys(false));
            keys.sort((x, y) -> { int cmp = Double.compare(shopPrice(cat, x), shopPrice(cat, y)); return cmp != 0 ? cmp : x.compareTo(y); });
            for (String key : keys) {
                if (!f.isEmpty() && !key.toUpperCase(Locale.ROOT).contains(f)) continue;
                out.add(cat + "|" + key);
            }
        }
        return out;
    }

    ItemStack shopEntryItem(String cat, String key, int qty) {
        double price = shopPrice(cat, key);
        if (price < 0) return null;
        if (isSetKey(key)) {
            String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
            Material icon = Material.matchMaterial(tier + "_CHESTPLATE");
            if (icon == null) return null;
            String nm = tier.substring(0, 1) + tier.substring(1).toLowerCase(Locale.ROOT);
            return item(icon, tierName(price).substring(0, 2) + "Full " + nm + " Armor Set",
                    "&7Tier: " + tierName(price), "&7Price: &a$" + fmt(price), "&7Includes all 4 pieces", "&eClick to buy");
        }
        Material m = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
        if (m == null || !m.isItem()) return null;
        ItemStack it = new ItemStack(m);
        List<String> ench = getConfig().getStringList("shop-enchants." + key);
        boolean enchanted = !ench.isEmpty();
        int shown = enchanted ? 1 : qty;
        if (enchanted) applyEnchants(it, ench);
        ItemMeta meta = it.getItemMeta();
        meta.setLore(List.of(c("&7Tier: " + tierName(price)), c("&7Price: &a$" + fmt(price) + " &7each"),
                c("&7Total for " + shown + ": &a$" + fmt(price * shown)), c("&eClick to buy " + shown)));
        it.setItemMeta(meta);
        return it;
    }

    void buyShopEntry(Player p, String cat, String key) {
        UUID pid = p.getUniqueId();
        double price = shopPrice(cat, key);
        if (price < 0) return;
        if (isSetKey(key)) {
            String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
            if (!take(pid, price)) { msg(p, "&cNot enough money (need $" + fmt(price) + ")"); return; }
            giveArmorSet(p, tier);
            msg(p, pretty(Material.matchMaterial(tier + "_CHESTPLATE")).replace(" Chestplate", "") + " Armor Set for $" + fmt(price));
            notifyFollowers(p, "buy", "bought a " + tier.toLowerCase(Locale.ROOT) + " armor set for $" + fmt(price));
            return;
        }
        String variant = key.contains(":") ? key.substring(key.indexOf(':') + 1) : null;
        Material sm = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
        if (sm == null) return;
        List<String> ench = getConfig().getStringList("shop-enchants." + key);
        int amt = ench.isEmpty() ? shopQty.getOrDefault(pid, 1) : 1;
        double total = price * amt;
        if (!take(pid, total)) { msg(p, "&cNot enough money (need $" + fmt(total) + ")"); return; }
        ItemStack bought = new ItemStack(sm, amt);
        if (!ench.isEmpty()) applyEnchants(bought, ench);
        give(p, bought);
        msg(p, (variant != null ? variantName(variant) + " " : "") + pretty(sm) + (amt > 1 ? " x" + amt : "") + " for $" + fmt(total));
        notifyFollowers(p, "buy", "bought " + pretty(sm) + (amt > 1 ? " x" + amt : "") + " for $" + fmt(total));
    }

    void openShop(Player p) { openShopPage(p, 0); }

    ItemStack shopContentItem(String ct, int qty, boolean staff) {
        String body = ct.substring(4);
        ItemStack it;
        if (ct.startsWith("cfg:")) {
            it = shopEntryItem(body.substring(0, body.indexOf('|')), body.substring(body.indexOf('|') + 1), qty);
        } else {
            Material cm = Material.matchMaterial(body.substring(0, body.indexOf('|')));
            if (cm == null || !cm.isItem()) return null;
            int cq = 1;
            try { cq = Math.max(1, Integer.parseInt(body.substring(body.indexOf('|') + 1))); } catch (NumberFormatException ignored) { }
            double unit = sellPrice(cm);
            it = new ItemStack(cm, Math.min(cq, cm.getMaxStackSize()));
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7Price: &a$" + fmt(unit) + " &7each"), c("&7Quantity: &f" + cq),
                    c("&7Total: &a$" + fmt(unit * cq)), c("&eClick to buy")));
            it.setItemMeta(mt);
        }
        if (it != null && staff) {
            ItemMeta m2 = it.getItemMeta();
            List<String> lo = m2.getLore() == null ? new ArrayList<>() : new ArrayList<>(m2.getLore());
            lo.add(c("&6Shift-click to change this slot"));
            m2.setLore(lo);
            it.setItemMeta(m2);
        }
        return it;
    }

    String shopContentName(String ct) {
        String body = ct.substring(4);
        String n = ct.startsWith("cfg:") ? body.substring(body.indexOf('|') + 1) : body.substring(0, body.indexOf('|'));
        return n.toUpperCase(Locale.ROOT);
    }

    void buyShopCustom(Player p, String ct) {
        String body = ct.substring(4);
        Material cm = Material.matchMaterial(body.substring(0, body.indexOf('|')));
        if (cm == null) return;
        int cq = 1;
        try { cq = Math.max(1, Integer.parseInt(body.substring(body.indexOf('|') + 1))); } catch (NumberFormatException ignored) { }
        double total = sellPrice(cm) * cq;
        if (total <= 0) return;
        if (!take(p.getUniqueId(), total)) { msg(p, "&cNot enough money (need $" + fmt(total) + ")"); return; }
        int left = cq;
        while (left > 0) {
            int n = Math.min(left, cm.getMaxStackSize());
            give(p, new ItemStack(cm, n));
            left -= n;
        }
        msg(p, pretty(cm) + (cq > 1 ? " x" + cq : "") + " for $" + fmt(total));
    }

    void openShopPage(Player p, int page) {
        UUID id = p.getUniqueId();
        boolean staff = isStaff(p);
        String f = shopSearch.getOrDefault(id, "").toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        int qty = shopQty.getOrDefault(id, 1);
        Gui g = new Gui("shop");
        g.filter = f;
        int pages;
        if (f.isEmpty()) {
            // staff always see all 5 pages so they can add items; players only see the pages that have items
            pages = staff ? SHOP_MAX_PAGES : shopLastUsedPage() + 1;
            page = Math.max(0, Math.min(page, pages - 1));
            g.page = page;
            g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-menu.title", "&8SHOP") + (pages > 1 ? " &7(" + (page + 1) + "/" + pages + ")" : "")));
            for (int sl : SHOP_SLOTS) {
                String ct = shopSlotContent(page, sl);
                ItemStack it = ct == null ? null : shopContentItem(ct, qty, staff);
                if (it == null) {
                    g.inv.setItem(sl, staff ? item(Material.BLACK_STAINED_GLASS_PANE, "&7Empty Slot", "&eClick to add an item")
                            : item(Material.BLACK_STAINED_GLASS_PANE, " "));
                    g.names.add("empty");
                } else {
                    g.inv.setItem(sl, it);
                    g.names.add(ct);
                }
                g.slotIdx.put(sl, g.names.size() - 1);
            }
        } else {
            List<String> matches = new ArrayList<>();
            for (int pg = 0; pg < SHOP_MAX_PAGES; pg++) {
                for (int sl : SHOP_SLOTS) {
                    String ct = shopSlotContent(pg, sl);
                    if (ct != null && shopContentName(ct).contains(f)) matches.add(ct);
                }
            }
            pages = Math.max(1, (matches.size() + SHOP_PER_PAGE - 1) / SHOP_PER_PAGE);
            page = Math.max(0, Math.min(page, pages - 1));
            g.page = page;
            g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("shop-menu.title", "&8SHOP") + " &7- " + f + (pages > 1 ? " (" + (page + 1) + "/" + pages + ")" : "")));
            int pos = 0;
            for (int i = page * SHOP_PER_PAGE; i < Math.min(matches.size(), page * SHOP_PER_PAGE + SHOP_PER_PAGE); i++) {
                ItemStack it = shopContentItem(matches.get(i), qty, false);
                if (it == null) continue;
                int sl = SHOP_SLOTS.get(pos++);
                g.inv.setItem(sl, it);
                g.slotIdx.put(sl, g.names.size());
                g.names.add(matches.get(i));
            }
        }
        if (page > 0) g.inv.setItem(48, item(Material.ARROW, "&e\u00ab Previous page"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type an item name", "&7(empty = show all)"));
        if (page < pages - 1) g.inv.setItem(50, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(45, item(Material.HOPPER, "&eBuy amount: &f" + qty, "&7Click to change (1 / 16 / 64)"));
        p.openInventory(g.inv);
    }

    // staff: choose the item (and quantity) of one slot of the shop
    void openShopPick(Player p, int shopPage, int shopSlot, int page) {
        UUID id = p.getUniqueId();
        String f = shopPickSearch.getOrDefault(id, "").toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Material> list = allItems().stream().filter(m -> f.isEmpty() || m.name().contains(f)).collect(Collectors.toList());
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("shoppick");
        g.page = page;
        g.counts.add(shopPage);
        g.counts.add(shopSlot);
        g.inv = Bukkit.createInventory(g, 54, c("&8Choose an item for this slot (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Material m = list.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta mt = it.getItemMeta();
            if (mt != null) { mt.setLore(List.of(c("&7Price: &a$" + fmt(sellPrice(m)) + " &7each"), c("&eClick to choose this item"))); it.setItemMeta(mt); }
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        if (data.getString("shopslots." + shopPage + "." + shopSlot + ".item") != null)
            g.inv.setItem(47, item(Material.BARRIER, "&cRemove this item", "&7The slot becomes black glass again"));
        g.inv.setItem(48, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Item", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a name"));
        p.openInventory(g.inv);
    }

    void openShopCategory(Player p, String id) {
        int qty = shopQty.getOrDefault(p.getUniqueId(), 1);
        Gui g = new Gui("shopcat");
        g.filter = id;
        g.inv = Bukkit.createInventory(g, 54, c("&8SHOP - " + id.toUpperCase(Locale.ROOT)));
        ConfigurationSection s = getConfig().getConfigurationSection("shop-items." + id);
        if (s != null) {
            // cheapest first -> most expensive last, so similar tiers sit together
            List<String> keys = new ArrayList<>(s.getKeys(false));
            keys.sort((x, y) -> { int cmp = Double.compare(shopPrice(id, x), shopPrice(id, y)); return cmp != 0 ? cmp : x.compareTo(y); });
            for (String key : keys) {
                if (g.names.size() >= 45) break;
                double price = shopPrice(id, key);
                ItemStack it;
                if (isSetKey(key)) {
                    String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
                    Material icon = Material.matchMaterial(tier + "_CHESTPLATE");
                    if (icon == null) continue;
                    String nm = tier.substring(0, 1) + tier.substring(1).toLowerCase(Locale.ROOT);
                    it = item(icon, tierName(price).substring(0, 2) + "Full " + nm + " Armor Set",
                            "&7Tier: " + tierName(price), "&7Price: &a$" + fmt(price), "&7Includes all 4 pieces", "&eClick to buy");
                } else {
                    Material m = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
                    if (m == null || !m.isItem()) continue;
                    it = new ItemStack(m);
                    List<String> ench = getConfig().getStringList("shop-enchants." + key);
                    boolean enchanted = !ench.isEmpty();
                    int shown = enchanted ? 1 : qty;
                    if (enchanted) applyEnchants(it, ench);
                    ItemMeta meta = it.getItemMeta();
                    meta.setLore(List.of(c("&7Tier: " + tierName(price)), c("&7Price: &a$" + fmt(price) + " &7each"),
                            c("&7Total for " + shown + ": &a$" + fmt(price * shown)), c("&eClick to buy " + shown)));
                    it.setItemMeta(meta);
                }
                g.inv.setItem(g.names.size(), it);
                g.names.add(key);
            }
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.HOPPER, "&eBuy amount: &f" + qty, "&7Click to change (1 / 16 / 64)"));
        for (int i = 45; i < 54; i++) if (g.inv.getItem(i) == null) g.inv.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, " "));
        p.openInventory(g.inv);
    }


    private static final int SELL_BTN = 53;

    void openSell(Player p) {
        Gui g = new Gui("sell");
        g.inv = Bukkit.createInventory(g, 54, c(getConfig().getString("sell-title")));
        refreshSellButton(g);
        p.openInventory(g.inv);
    }

    // the green glass: hover = total price of the items in the window, click = sell them
    void refreshSellButton(Gui g) {
        double total = 0;
        long n = 0;
        for (int i = 0; i < g.inv.getSize(); i++) {
            if (i == SELL_BTN) continue;
            ItemStack it = g.inv.getItem(i);
            if (it == null || it.getType().isAir()) continue;
            total += sellPrice(it.getType()) * it.getAmount();
            n += it.getAmount();
        }
        g.inv.setItem(SELL_BTN, item(Material.LIME_STAINED_GLASS_PANE, "&aSell Items", "&7Items: &f" + n, "&7Total price: &a$" + fmt(total), "", "&eClick to sell"));
    }

    void sellContents(Player p, Gui g, boolean warn) {
        double total = 0;
        long sold = 0;
        for (int i = 0; i < g.inv.getSize(); i++) {
            if (i == SELL_BTN) continue;
            ItemStack it = g.inv.getItem(i);
            if (it == null || it.getType().isAir()) continue;
            double price = sellPrice(it.getType());
            if (price > 0) { total += price * it.getAmount(); sold += it.getAmount(); }
            else give(p, it);
            g.inv.setItem(i, null);
        }
        if (total > 0) {
            add(p.getUniqueId(), total);
            msg(p, "&aSold " + sold + " items for &e$" + fmt(total));
            notifyFollowers(p, "sell", "sold " + sold + " items for $" + fmt(total));
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        } else if (warn && sold == 0) {
            msg(p, "&cPlace the items you want to sell first");
        }
    }

    private final Map<UUID, Integer> shopQty = new HashMap<>();
    private final Map<UUID, Integer> ahSort = new HashMap<>();
    private final Map<UUID, String> ahSearch = new HashMap<>();
    private final Map<UUID, ItemStack> ahPending = new HashMap<>();

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        Player p = (Player) e.getPlayer();
        if (g.type.equals("orderdeposit")) { handleDeposit(p, g); return; }
        if (g.type.equals("ahsell")) {
            if (!"done".equals(g.filter)) {
                ItemStack back = e.getInventory().getItem(13);
                if (back != null && !back.getType().isAir()) give(p, back);
            }
            e.getInventory().clear();
            return;
        }
        if (!g.type.equals("sell")) return;
        e.getInventory().setItem(SELL_BTN, null);
        sellContents(p, g, false);
    }

    // ---------- /order ----------
    void orderCmd(Player p, String[] a) {
        if (a.length == 0) { openOrders(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 4) { msg(p, "&e/order create <item> <amount> <price per piece>"); return; }
                Material m = Material.matchMaterial(a[1]);
                int amt;
                try { amt = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { amt = -1; }
                double price = parseAmount(a[3]);
                if (m == null || !m.isItem() || amt <= 0 || price <= 0) { msg(p, "&cInvalid input"); return; }
                double cost = amt * price;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cNot enough money (need $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, amt, price));
                msg(p, "&aBuy order created: " + m.name() + " x" + amt + " at $" + fmt(price) + " each");
            }
            case "claim" -> {
                Map<String, Integer> map = claims.remove(p.getUniqueId());
                if (map == null || map.isEmpty()) { msg(p, "&cNothing to claim"); return; }
                map.forEach((mat, n) -> {
                    Material m = Material.matchMaterial(mat);
                    if (m == null) return;
                    int left = n;
                    while (left > 0) {
                        int st = Math.min(left, m.getMaxStackSize());
                        give(p, new ItemStack(m, st));
                        left -= st;
                    }
                });
                msg(p, "&aClaimed items from your orders");
            }
            default -> openOrders(p);
        }
    }

    void openOrders(Player p) { openOrders(p, 0); }

    void openOrders(Player p, int page) {
        UUID pid = p.getUniqueId();
        int mode = orderSort.getOrDefault(pid, 0);
        String q = orderSearch.get(pid);
        String qf = q == null ? "" : q.toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Order> active = orders.stream().filter(o -> o.left > 0)
                .filter(o -> qf.isEmpty() || o.mat.name().contains(qf)).collect(Collectors.toList());
        List<Double> prices = active.stream().map(o -> o.price).sorted().collect(Collectors.toList());
        final double med = prices.isEmpty() ? 0 : prices.get(prices.size() / 2);
        if (mode == 0) active.sort((x, y) -> Double.compare(y.price, x.price));
        else if (mode == 1) active.sort(Comparator.comparingDouble(o -> Math.abs(o.price - med)));
        else active.sort(Comparator.comparingDouble(o -> o.price));
        int pages = Math.max(1, (active.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("orders");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&8" + getConfig().getString("order-title", "Orders") + " (Page " + (page + 1) + ")"));
        for (int i = page * 45; i < Math.min(active.size(), page * 45 + 45); i++) {
            Order o = active.get(i);
            ItemStack it = new ItemStack(o.mat);
            ItemMeta meta = it.getItemMeta();
            String owner = Optional.ofNullable(Bukkit.getOfflinePlayer(o.owner).getName()).orElse("?");
            meta.setLore(List.of(
                    c("&7Ordered by: &f" + owner),
                    c("&7Still needed: &f" + o.left),
                    c("&7Price per piece: &a$" + fmt(o.price)),
                    c(o.owner.equals(pid) ? "&eClick to manage your order" : "&aClick to deliver items to this order")));
            it.setItemMeta(meta);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        String[] modes = {"Highest price", "Median price", "Lowest price"};
        String[] sortLore = new String[4];
        for (int i = 0; i < 3; i++) sortLore[i] = (i == mode ? "&a\u25b6 " : "&7  ") + modes[i];
        sortLore[3] = "&eClick to change";
        g.inv.setItem(47, item(Material.HOPPER, "&eSort", sortLore));
        g.inv.setItem(48, item(Material.AMETHYST_SHARD, "&dShard Shop", "&7Click to open the Shard Shop"));
        g.inv.setItem(49, item(Material.BOOK, "&aCreate New Order", "&7Pick an item, then set the amount and price"));
        g.inv.setItem(50, item(Material.OAK_SIGN, "&eSearch", "&7Current: &f" + (qf.isEmpty() ? "All" : qf), "&7Click to type an item name"));
        g.inv.setItem(51, item(Material.CHEST, "&6My Orders", "&7View delivered items / cancel orders"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        p.openInventory(g.inv);
    }

    void openMyOrders(Player p) {
        Gui g = new Gui("myorders");
        g.inv = Bukkit.createInventory(g, 54, c("&8My Orders"));
        for (Order o : orders) {
            if (!o.owner.equals(p.getUniqueId())) continue;
            if (g.orders.size() >= 45) break;
            ItemStack it = new ItemStack(o.mat);
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&7Still needed: &f" + o.left), c("&7Price per piece: &a$" + fmt(o.price)),
                    c("&7Delivered: &f" + o.delivered), c("&eClick to manage")));
            it.setItemMeta(mt);
            g.inv.setItem(g.orders.size(), it);
            g.orders.add(o);
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void openOrderManage(Player p, Order o) {
        Gui g = new Gui("ordermanage");
        g.ord = o;
        g.inv = Bukkit.createInventory(g, 27, c("&8Manage Order"));
        ItemStack it = new ItemStack(o.mat);
        ItemMeta mt = it.getItemMeta();
        mt.setLore(List.of(c("&7Still needed: &f" + o.left), c("&7Price per piece: &a$" + fmt(o.price)), c("&7Delivered: &f" + o.delivered)));
        it.setItemMeta(mt);
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cBack", "&7Go back to My Orders"));
        g.inv.setItem(13, it);
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aCancel Order & Collect",
                "&7Refund for the rest: &a$" + fmt(o.left * o.price), "&7Delivered items: &f" + o.delivered));
        g.inv.setItem(22, item(Material.CHEST, "&bView Delivered Items", "&7Take items one stack at a time"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void cancelOrder(Player p, Order o) {
        if (!orders.contains(o)) { openMyOrders(p); return; }
        if (o.left > 0) {
            double refund = o.left * o.price;
            add(p.getUniqueId(), refund);
            msg(p, "&eOrder cancelled. Refunded &a$" + fmt(refund));
            o.left = 0;
        }
        int got = takeDelivered(p, o, Integer.MAX_VALUE);
        if (got > 0) msg(p, "&aCollected " + got + " items");
        if (o.delivered <= 0) orders.remove(o);
        else msg(p, "&eYour inventory is full. Open the order again to collect the rest.");
        openMyOrders(p);
    }

    void openOrderClaim(Player p, Order o) {
        Gui g = new Gui("orderclaim");
        g.ord = o;
        g.inv = Bukkit.createInventory(g, 54, c("&8Delivered: " + o.mat.name()));
        int rem = o.delivered;
        int slot = 0;
        while (rem > 0 && slot < 45) {
            int n = Math.min(rem, o.mat.getMaxStackSize());
            ItemStack it = new ItemStack(o.mat, n);
            ItemMeta mt = it.getItemMeta();
            mt.setLore(List.of(c("&eClick to take")));
            it.setItemMeta(mt);
            g.inv.setItem(slot++, it);
            rem -= n;
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.LIME_STAINED_GLASS_PANE, "&aCollect All", "&7Total: &f" + o.delivered));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    int takeDelivered(Player p, Order o, int want) {
        want = Math.min(want, o.delivered);
        int given = 0;
        while (given < want) {
            int st = Math.min(want - given, o.mat.getMaxStackSize());
            Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(o.mat, st));
            int notGiven = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            given += st - notGiven;
            if (notGiven > 0) break;
        }
        o.delivered -= given;
        if (o.delivered <= 0 && o.left <= 0) orders.remove(o);
        return given;
    }

    void openOrderDeposit(Player p, Order o) {
        Gui g = new Gui("orderdeposit");
        g.ord = o;
        g.inv = Bukkit.createInventory(g, 54, c("&8Deliver " + o.mat.name() + " ($" + fmt(o.price) + " each)"));
        p.openInventory(g.inv);
        msg(p, "&ePlace &f" + o.mat.name() + " &ein the window and close it to deliver (paid instantly at $" + fmt(o.price) + " each)");
    }

    void handleDeposit(Player p, Gui g) {
        Order o = g.ord;
        boolean valid = o != null && orders.contains(o) && o.left > 0;
        int total = 0;
        List<ItemStack> back = new ArrayList<>();
        for (ItemStack it : g.inv.getContents()) {
            if (it == null || it.getType().isAir()) continue;
            if (valid && it.getType() == o.mat && !it.hasItemMeta()) total += it.getAmount(); else back.add(it);
        }
        g.inv.clear();
        if (valid && total > 0) {
            int accept = Math.min(total, o.left);
            int excess = total - accept;
            o.left -= accept;
            o.delivered += accept;
            double pay = accept * o.price;
            add(p.getUniqueId(), pay);
            while (excess > 0) {
                int st = Math.min(excess, o.mat.getMaxStackSize());
                give(p, new ItemStack(o.mat, st));
                excess -= st;
            }
            msg(p, "You delivered " + accept + " " + pretty(o.mat) + " and received $" + fmt(pay));
            Player owner = Bukkit.getPlayer(o.owner);
            if (owner != null) msg(owner, "&aSomeone delivered " + o.mat.name() + " x" + accept + " to your order! Open /order > My Orders to collect.");
        }
        back.forEach(it -> give(p, it));
    }

    private List<Material> itemList;

    List<Material> allItems() {
        if (itemList == null) itemList = Arrays.stream(Material.values())
                .filter(m -> !m.isLegacy() && m.isItem() && !m.isAir())
                .sorted(Comparator.comparing(Enum::name)).collect(Collectors.toList());
        return itemList;
    }

    void openOrderPick(Player p, int page, String filter) {
        String f = filter == null ? "" : filter.toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Material> list = allItems().stream().filter(m -> f.isEmpty() || m.name().contains(f)).collect(Collectors.toList());
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("orderpick");
        g.page = page;
        g.filter = filter;
        g.inv = Bukkit.createInventory(g, 54, c("&8Choose an item to buy (" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(list.size(), page * 45 + 45); i++) {
            Material m = list.get(i);
            ItemStack it = new ItemStack(m);
            ItemMeta mt = it.getItemMeta();
            if (mt != null) { mt.setLore(List.of(c("&eClick to choose this item"))); it.setItemMeta(mt); }
            g.inv.setItem(i - page * 45, it);
            g.mats.add(m);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        g.inv.setItem(48, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        g.inv.setItem(49, item(Material.OAK_SIGN, "&eSearch Item", "&7Current: &f" + (f.isEmpty() ? "All" : f), "&7Click to type a name"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void startOrderCreate(Player p, Material m) {
        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Enter the amount", "received"}, priceText -> {
            double pr = parseAmount(priceText);
            if (pr <= 0) { msg(p, "&cInvalid price"); return; }
            signPrompt(p, new String[]{"", "Enter the", "quantity you wish", "to purchase"}, qtyText -> {
                double q = parseAmount(qtyText);
                int n = (int) Math.min(q, 2_000_000_000d);
                if (n <= 0) { msg(p, "&cInvalid amount"); return; }
                double cost = n * pr;
                if (!take(p.getUniqueId(), cost)) { msg(p, "&cNot enough money (need $" + fmt(cost) + ")"); return; }
                orders.add(new Order(nextOrderId++, p.getUniqueId(), m, n, pr));
                msg(p, "&aBuy order created: " + m.name() + " x" + n + " at $" + fmt(pr) + " each (charged $" + fmt(cost) + ")");
                openOrders(p, 0);
            });
        });
    }

    // ---------- /ah ----------
    void ahCmd(Player p, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("sell")) {
            if (a.length < 2) { msg(p, "&e/ah sell <price> &7(hold the item you want to sell)"); return; }
            double price = parseAmount(a[1]);
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (price <= 0) { msg(p, "&cInvalid price"); return; }
            if (hand == null || hand.getType().isAir()) { msg(p, "&cHold the item you want to sell"); return; }
            if (!canList(p)) return;
            listings.add(new Listing(nextListingId++, p.getUniqueId(), hand.clone(), price, System.currentTimeMillis()));
            notifyFollowers(p, "sell", "listed " + goodName(hand) + " on the auction house for $" + fmt(price));
            p.getInventory().setItemInMainHand(null);
            msg(p, "You listen " + hand.getAmount() + " " + goodName(hand) + " for $" + fmt(price));
            return;
        }
        openAh(p, 0);
    }

    boolean canList(Player p) {
        long mine = listings.stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
        int max = getConfig().getInt("ah.max-listings", 10);
        if (mine >= max) { msg(p, "&cYou can have at most " + max + " listings"); return false; }
        return true;
    }

    void openAh(Player p, int page) {
        UUID pid = p.getUniqueId();
        int mode = ahSort.getOrDefault(pid, 0);
        String q = ahSearch.get(pid);
        String qf = q == null ? "" : q.toUpperCase(Locale.ROOT).trim().replace(' ', '_');
        List<Listing> sorted = listings.stream()
                .filter(l -> qf.isEmpty() || l.item.getType().name().contains(qf)).collect(Collectors.toList());
        if (mode == 0) sorted.sort((x, y) -> Long.compare(y.time, x.time));
        else if (mode == 1) sorted.sort(Comparator.comparingDouble(l -> l.price));
        else sorted.sort((x, y) -> Double.compare(y.price, x.price));
        int pages = Math.max(1, (sorted.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Gui g = new Gui("ah");
        g.page = page;
        g.inv = Bukkit.createInventory(g, 54, c("&6&lAuction House &7(" + (page + 1) + "/" + pages + ")"));
        for (int i = page * 45; i < Math.min(sorted.size(), page * 45 + 45); i++) {
            Listing l = sorted.get(i);
            g.inv.setItem(g.shown.size(), listingIcon(l, pid));
            g.shown.add(l);
        }
        if (page > 0) g.inv.setItem(45, item(Material.ARROW, "&e\u00ab Previous page"));
        String[] modes = {"Newest first", "Lowest price", "Highest price"};
        String[] sortLore = new String[4];
        for (int i = 0; i < 3; i++) sortLore[i] = (i == mode ? "&a\u25b6 " : "&7  ") + modes[i];
        sortLore[3] = "&eClick to change";
        g.inv.setItem(47, item(Material.HOPPER, "&eSort", sortLore));
        g.inv.setItem(48, item(Material.CLOCK, "&bRefresh", "&7Reload the listings"));
        g.inv.setItem(49, item(Material.BOOK, "&aSell Item", "&7Put an item in the window and set a price"));
        g.inv.setItem(50, item(Material.OAK_SIGN, "&eSearch", "&7Current: &f" + (qf.isEmpty() ? "All" : qf), "&7Click to type an item name"));
        g.inv.setItem(51, item(Material.CHEST, "&6My Listings", "&7View or take back your listings"));
        if (page < pages - 1) g.inv.setItem(53, item(Material.ARROW, "&eNext page \u00bb"));
        p.openInventory(g.inv);
    }

    ItemStack listingIcon(Listing l, UUID viewer) {
        ItemStack d = l.item.clone();
        ItemMeta m = d.getItemMeta();
        List<String> lore = m.hasLore() && m.getLore() != null ? new ArrayList<>(m.getLore()) : new ArrayList<>();
        lore.add(c("&8\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"));
        lore.add(c("&7Price: &a$" + fmt(l.price)));
        lore.add(c("&7Seller: &f" + Optional.ofNullable(Bukkit.getOfflinePlayer(l.seller).getName()).orElse("?")));
        lore.add(c(l.seller.equals(viewer) ? "&eYour listing - click to manage" : "&aClick to buy"));
        m.setLore(lore);
        d.setItemMeta(m);
        return d;
    }

    void openAhMy(Player p) {
        Gui g = new Gui("ahmy");
        g.inv = Bukkit.createInventory(g, 54, c("&8My Listings"));
        for (Listing l : listings) {
            if (!l.seller.equals(p.getUniqueId())) continue;
            if (g.shown.size() >= 45) break;
            g.inv.setItem(g.shown.size(), listingIcon(l, p.getUniqueId()));
            g.shown.add(l);
        }
        g.inv.setItem(45, item(Material.RED_STAINED_GLASS_PANE, "&cBack"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void openAhManage(Player p, Listing l) {
        Gui g = new Gui("ahmanage");
        g.shown.add(l);
        g.inv = Bukkit.createInventory(g, 27, c("&8Manage Listing"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cBack", "&7Go back to My Listings"));
        g.inv.setItem(13, listingIcon(l, p.getUniqueId()));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aTake Back", "&7Remove the listing and get the item back"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        p.openInventory(g.inv);
    }

    void openAhSell(Player p) {
        Gui g = new Gui("ahsell");
        g.inv = Bukkit.createInventory(g, 27, c("&8Sell Item"));
        g.inv.setItem(4, item(Material.PAPER, "&eSell an Item", "&7Place the item in the middle slot", "&7then press the green button"));
        g.inv.setItem(11, item(Material.RED_STAINED_GLASS_PANE, "&cBack", "&7Cancel and get your item back"));
        g.inv.setItem(15, item(Material.LIME_STAINED_GLASS_PANE, "&aConfirm", "&7Continue and set the price"));
        fill(g.inv, Material.BLACK_STAINED_GLASS_PANE);
        g.inv.setItem(13, null);
        p.openInventory(g.inv);
    }

    void ahSellClick(InventoryClickEvent e, Gui g, Player p) {
        if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR) { e.setCancelled(true); return; }
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int s = e.getSlot();
        if (s == 13) return;
        e.setCancelled(true);
        if (s == 11) {
            Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); openAh(p, 0); });
            return;
        }
        if (s != 15) return;
        ItemStack put = g.inv.getItem(13);
        if (put == null || put.getType().isAir()) { msg(p, "&cPlace the item you want to sell in the middle slot first"); return; }
        if (!canList(p)) return;
        g.inv.setItem(13, null);
        g.filter = "done";
        UUID pid = p.getUniqueId();
        ahPending.put(pid, put);
        Bukkit.getScheduler().runTask(this, () -> {
            p.closeInventory();
            boolean ok = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Enter Price", ""}, text -> {
                ItemStack pend = ahPending.remove(pid);
                if (pend == null) return;
                double price = parseAmount(text);
                if (price <= 0) { give(p, pend); msg(p, "&cInvalid price. Your item was returned."); return; }
                listings.add(new Listing(nextListingId++, pid, pend, price, System.currentTimeMillis()));
                notifyFollowers(p, "sell", "listed " + goodName(pend) + " on the auction house for $" + fmt(price));
                msg(p, "You listen " + pend.getAmount() + " " + goodName(pend) + " for $" + fmt(price));
            });
            if (!ok) {
                ItemStack pend = ahPending.remove(pid);
                if (pend != null) give(p, pend);
                return;
            }
            Bukkit.getScheduler().runTaskLater(this, () -> {
                ItemStack stale = ahPending.remove(pid);
                if (stale != null) {
                    restoreSign(pid);
                    Player pp = Bukkit.getPlayer(pid);
                    if (pp != null) { give(pp, stale); msg(pp, "&cPrice entry timed out. Your item was returned."); }
                }
            }, 20L * 90);
        });
    }

    void buyListing(Player p, Listing l) {
        if (l.seller.equals(p.getUniqueId())) { msg(p, "&cYou cannot buy your own listing"); return; }
        if (!take(p.getUniqueId(), l.price)) { msg(p, "&cNot enough money (need $" + fmt(l.price) + ")"); return; }
        listings.remove(l);
        add(l.seller, l.price);
        give(p, l.item.clone());
        msg(p, "You bought " + l.item.getAmount() + " " + goodName(l.item) + " for $" + fmt(l.price));
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) msg(seller, p.getName() + " bought your " + goodName(l.item) + " for $" + fmt(l.price));
        notifyFollowers(p, "buy", "bought " + goodName(l.item) + " on the auction house for $" + fmt(l.price));
    }


    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) {
            if (e.getRawSlots().contains(SELL_BTN)) { e.setCancelled(true); return; }
            Bukkit.getScheduler().runTask(this, () -> refreshSellButton(g));
            return;
        }
        if (g.type.equals("orderdeposit")) return;
        if (g.type.equals("ahsell")) {
            for (int rs : e.getRawSlots()) if (rs < 27 && rs != 13) { e.setCancelled(true); return; }
            return;
        }
        e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Gui g)) return;
        if (g.type.equals("sell")) {
            if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR) { e.setCancelled(true); return; }
            if (e.getRawSlot() == SELL_BTN) {
                e.setCancelled(true);
                sellContents((Player) e.getWhoClicked(), g, true);
                refreshSellButton(g);
                return;
            }
            Bukkit.getScheduler().runTask(this, () -> refreshSellButton(g));
            return;   // the rest of the window = free item placement
        }
        if (g.type.equals("orderdeposit")) return; // free item placement
        Player p = (Player) e.getWhoClicked();
        if (g.type.equals("ahsell")) { ahSellClick(e, g, p); return; }
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || it.getType().isAir()) return;
        int slot = e.getSlot();
        UUID pid = p.getUniqueId();

        switch (g.type) {
            case "shop" -> {
                if (slot == 48 && it.getType() == Material.ARROW) { openShopPage(p, g.page - 1); return; }
                if (slot == 50 && it.getType() == Material.ARROW) { openShopPage(p, g.page + 1); return; }
                if (slot == 45) {
                    int cur = shopQty.getOrDefault(pid, 1);
                    shopQty.put(pid, cur == 1 ? 16 : cur == 16 ? 64 : 1);
                    openShopPage(p, g.page);
                    return;
                }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okS = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) shopSearch.remove(pid); else shopSearch.put(pid, text);
                            openShopPage(p, 0);
                        });
                        if (!okS) openShopPage(p, 0);
                    });
                    return;
                }
                Integer sci = g.slotIdx.get(slot);
                if (sci == null) return;
                String entry = g.names.get(sci);
                boolean searching = g.filter != null && !g.filter.isEmpty();
                if (isStaff(p) && !searching && (entry.equals("empty") || e.isShiftClick())) { openShopPick(p, g.page, slot, 0); return; }
                if (entry.startsWith("cfg:")) {
                    String body = entry.substring(4);
                    buyShopEntry(p, body.substring(0, body.indexOf('|')), body.substring(body.indexOf('|') + 1));
                } else if (entry.startsWith("cus:")) {
                    buyShopCustom(p, entry);
                }
            }
            case "shoppick" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                final int spg = g.counts.size() > 0 ? g.counts.get(0) : 0;
                final int ssl = g.counts.size() > 1 ? g.counts.get(1) : 0;
                final String sbase = "shopslots." + spg + "." + ssl;
                if (slot == 45 && it.getType() == Material.ARROW) { openShopPick(p, spg, ssl, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openShopPick(p, spg, ssl, g.page + 1); return; }
                if (slot == 48) { openShopPage(p, spg); return; }
                if (slot == 47 && it.getType() == Material.BARRIER) {
                    data.set(sbase, null);
                    saveData();
                    openShopPage(p, spg);
                    return;
                }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okS = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) shopPickSearch.remove(pid); else shopPickSearch.put(pid, text);
                            openShopPick(p, spg, ssl, 0);
                        });
                        if (!okS) openShopPick(p, spg, ssl, 0);
                    });
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    final Material pm = g.mats.get(slot);
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okQ = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Item quantity", "(e.g. 1, 64)"}, text -> {
                            double q = text == null ? -1 : parseAmount(text.trim());
                            if (q < 1) { msg(p, "&cInvalid quantity"); openShopPage(p, spg); return; }
                            int n = (int) Math.min(q, 2304d);
                            data.set(sbase + ".item", pm.name());
                            data.set(sbase + ".qty", n);
                            saveData();
                            msg(p, "&aSlot set: " + pretty(pm) + " x" + n);
                            openShopPage(p, spg);
                        });
                        if (!okQ) openShopPage(p, spg);
                    });
                }
            }
            case "shopcat" -> {
                if (slot == 45) { openShop(p); return; }
                if (slot == 49) {
                    int cur = shopQty.getOrDefault(pid, 1);
                    shopQty.put(pid, cur == 1 ? 16 : cur == 16 ? 64 : 1);
                    openShopCategory(p, g.filter);
                    return;
                }
                if (slot >= 45 || slot >= g.names.size()) return;
                String key = g.names.get(slot);
                double price = shopPrice(g.filter, key);
                if (price < 0) return;
                if (isSetKey(key)) {
                    String tier = key.substring(0, key.length() - "_ARMOR_SET".length());
                    if (!take(pid, price)) { msg(p, "&cNot enough money (need $" + fmt(price) + ")"); return; }
                    giveArmorSet(p, tier);
                    msg(p, pretty(Material.matchMaterial(tier + "_CHESTPLATE")).replace(" Chestplate", "") + " Armor Set for $" + fmt(price));
                    notifyFollowers(p, "buy", "bought a " + tier.toLowerCase(Locale.ROOT) + " armor set for $" + fmt(price));
                    return;
                }
                String variant = key.contains(":") ? key.substring(key.indexOf(':') + 1) : null;
                Material sm = Material.matchMaterial(key.contains(":") ? key.substring(0, key.indexOf(':')) : key);
                if (sm == null) return;
                List<String> ench = getConfig().getStringList("shop-enchants." + g.names.get(slot));
                int amt = ench.isEmpty() ? shopQty.getOrDefault(pid, 1) : 1;
                double total = price * amt;
                if (!take(pid, total)) { msg(p, "&cNot enough money (need $" + fmt(total) + ")"); return; }
                ItemStack bought = new ItemStack(sm, amt);
                if (!ench.isEmpty()) applyEnchants(bought, ench);
                give(p, bought);
                msg(p, (variant != null ? variantName(variant) + " " : "") + pretty(sm) + (amt > 1 ? " x" + amt : "") + " for $" + fmt(total));
                notifyFollowers(p, "buy", "bought " + pretty(sm) + (amt > 1 ? " x" + amt : "") + " for $" + fmt(total));
            }
            case "orders" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openOrders(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openOrders(p, g.page + 1); return; }
                if (slot == 47) { orderSort.put(pid, (orderSort.getOrDefault(pid, 0) + 1) % 3); openOrders(p, 0); return; }
                if (slot == 48) { openShardShop(p); return; }
                if (slot == 49) { openOrderPick(p, 0, null); return; }
                if (slot == 50) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Search orders", "(empty = all)"}, text -> {
                            orderSearch.put(pid, text);
                            openOrders(p, 0);
                        });
                    });
                    return;
                }
                if (slot == 51) { openMyOrders(p); return; }
                if (slot >= 45 || slot >= g.orders.size()) return;
                Order o = g.orders.get(slot);
                if (!orders.contains(o) || o.left <= 0) { openOrders(p, g.page); return; }
                if (o.owner.equals(pid)) openOrderManage(p, o); else openOrderDeposit(p, o);
            }
            case "orderpick" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openOrderPick(p, g.page - 1, g.filter); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openOrderPick(p, g.page + 1, g.filter); return; }
                if (slot == 48) { openOrders(p, 0); return; }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> openOrderPick(p, 0, text));
                    });
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    Material pm = g.mats.get(slot);
                    Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); startOrderCreate(p, pm); });
                }
            }
            case "myorders" -> {
                if (slot == 45) { openOrders(p, 0); return; }
                if (slot >= 45 || slot >= g.orders.size()) return;
                Order mo = g.orders.get(slot);
                if (!orders.contains(mo)) { openMyOrders(p); return; }
                openOrderManage(p, mo);
            }
            case "ordermanage" -> {
                Order mo = g.ord;
                if (mo == null) return;
                if (slot == 11) { openMyOrders(p); return; }
                if (!orders.contains(mo)) { openMyOrders(p); return; }
                if (slot == 15) { cancelOrder(p, mo); return; }
                if (slot == 22) openOrderClaim(p, mo);
            }
            case "orderclaim" -> {
                Order co = g.ord;
                if (co == null) return;
                if (slot == 45) { if (orders.contains(co)) openOrderManage(p, co); else openMyOrders(p); return; }
                if (slot == 49) {
                    int got = takeDelivered(p, co, Integer.MAX_VALUE);
                    if (got > 0) msg(p, "&aCollected " + got + " items");
                } else if (slot < 45) {
                    takeDelivered(p, co, it.getAmount());
                }
                if (orders.contains(co)) openOrderClaim(p, co); else openMyOrders(p);
            }
            case "spawnerfilter" -> {
                SpawnerData fs = g.sp;
                if (fs == null || !spawners.containsKey(fs.id)) { p.closeInventory(); return; }
                if (slot == 22) { openSpawner(p, fs, 0); return; }
                int fi = slot % 9;
                if (slot < 18 && fi < g.mats.size()) {
                    Material fm = g.mats.get(fi);
                    if (!fs.disabled.remove(fm)) fs.disabled.add(fm);
                    openSpawnerFilter(p, fs);
                }
            }
            case "rtp" -> {
                World.Environment env = slot == 11 ? World.Environment.NORMAL
                        : slot == 13 ? World.Environment.NETHER
                        : slot == 15 ? World.Environment.THE_END : null;
                if (env == null) return;
                Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); rtp(p, env); });
            }
            case "settings" -> {
                for (int i = 0; i < SETTING_SLOTS.length && i < SETTINGS.length; i++) {
                    if (SETTING_SLOTS[i] != slot) continue;
                    String skey = SETTINGS[i][0];
                    boolean cur = setting(pid, skey, Boolean.parseBoolean(SETTINGS[i][2]));
                    if (skey.equals("nv")) setNv(p, !cur); else setSetting(pid, skey, !cur);
                    break;
                }
                openSettings(p);
                updateBoard(p);
            }
            case "followset" -> {
                for (String[] fsr : FOLLOW_SETTINGS) {
                    if (Integer.parseInt(fsr[4]) != slot) continue;
                    setSetting(pid, fsr[0], !setting(pid, fsr[0], Boolean.parseBoolean(fsr[2])));
                    break;
                }
                openFollowSettings(p);
            }
            case "tpconfirm" -> {
                String who = g.filter;
                if (slot == 11) Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); tpRespond(p, false, who); });
                else if (slot == 15) Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f); tpRespond(p, true, who); });
            }
            case "rtpq" -> {
                if (slot == 11) Bukkit.getScheduler().runTask(this, () -> p.closeInventory());
                else if (slot == 15) Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); joinRtpQueue(p); });
            }
            case "bounty" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openBounty(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openBounty(p, g.page + 1); return; }
            }
            case "baltop" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openBaltop(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openBaltop(p, g.page + 1); return; }
                if (slot == 48) { openProfile(p, pid); return; }
                if (slot == 49) { msg(p, "&eYour balance: &a$" + fmt(bal(pid))); return; }
                if (slot == 50) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Player name", ""}, text -> searchPlayerProfile(p, text));
                    });
                    return;
                }
                if (slot < 45 && slot < g.uuids.size()) {
                    UUID tu = g.uuids.get(slot);
                    String tn = Optional.ofNullable(Bukkit.getOfflinePlayer(tu).getName()).orElse("?");
                    msg(p, "&f" + tn + " &7has &a$" + fmt(bal(tu)));
                    openProfile(p, tu);
                }
            }
            case "profile" -> {
                if (slot == 27) openBaltop(p, 0);
                else if (slot == 34 && g.filter != null) {
                    OfflinePlayer followTarget = findPlayer(g.filter);
                    if (followTarget != null && !followTarget.getUniqueId().equals(pid)) { toggleFollow(p, followTarget); openProfile(p, followTarget.getUniqueId()); }
                }
                else if ((slot == 30 || slot == 32) && g.filter != null) {
                    final boolean here = slot == 32;
                    final String tname = g.filter;
                    Bukkit.getScheduler().runTask(this, () -> { p.closeInventory(); tpaCmd(p, new String[]{tname}, here); });
                }
            }
            case "blessbook" -> {
                for (int bi = 0; bi < BLESS_SLOTS.length; bi++)
                    if (BLESS_SLOTS[bi] == slot) { blessSelect(p, bi); openBlessBook(p); break; }
            }
            case "homes" -> {
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okH = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Home name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) homeSearch.remove(pid); else homeSearch.put(pid, text);
                            openHomes(p);
                        });
                        if (!okH) openHomes(p);
                    });
                    return;
                }
                if (slot == 51 && it.getType() == Material.BARRIER) { homeSearch.remove(pid); openHomes(p); return; }
                if (slot >= 45) return;
                String hn = slot < g.names.size() ? g.names.get(slot) : null;
                if (hn != null) { openHomeManage(p, hn); return; }
                if ("search".equals(g.filter)) return;
                if (slot >= homeLimit(pid)) { msg(p, "&cYou cannot set a home here"); return; }
                String auto = "home" + (slot + 1);
                if (data.contains("homes." + pid + "." + auto)) auto = nextHomeName(pid);
                setHome(p, auto, slot);
                openHomes(p);
            }
            case "homemanage" -> {
                final String hname = g.filter;
                String path = "homes." + pid + "." + hname;
                if (slot == 22) { openHomes(p); return; }
                if (slot == 13) {
                    Location hl = data.getLocation(path);
                    if (hl == null) { openHomes(p); return; }
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        p.teleportAsync(hl);
                        msg(p, "&aTeleported to home &e" + hname);
                        notifyFollowers(p, "tp", "teleported to their home");
                    });
                    return;
                }
                if (slot == 10) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Home name", "(letters, numbers, _)"}, text -> {
                            String nn = cleanHomeName(text);
                            if (nn == null) {
                                msg(p, "&cInvalid name (use letters, numbers, _ or -, max 16 characters)");
                                openHomeManage(p, hname);
                            } else if (nn.equals(hname)) {
                                openHomeManage(p, hname);
                            } else if (data.contains("homes." + pid + "." + nn)) {
                                msg(p, "&cYou already have a home with that name");
                                openHomeManage(p, hname);
                            } else {
                                Location old = data.getLocation(path);
                                if (old == null) { openHomes(p); return; }
                                data.set("homes." + pid + "." + nn, old);
                                data.set(path, null);
                                for (int si = 0; si < HOME_MAX_ALL; si++)
                                    if (hname.equals(data.getString("homeslot." + pid + "." + si))) data.set("homeslot." + pid + "." + si, nn);
                                msg(p, "&aHome renamed to &e" + nn);
                                openHomeManage(p, nn);
                            }
                        });
                    });
                    return;
                }
                if (slot == 16) {
                    data.set(path, null);
                    for (int si = 0; si < HOME_MAX_ALL; si++)
                        if (hname.equals(data.getString("homeslot." + pid + "." + si))) data.set("homeslot." + pid + "." + si, null);
                    msg(p, "&aDeleted home &e" + hname);
                    openHomes(p);
                }
            }
            case "shardshop" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openShardShop(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openShardShop(p, g.page + 1); return; }
                Integer sidx = g.slotIdx.get(slot);
                if (sidx == null) return;
                long price = g.prices.get(sidx);
                long have = shards.getOrDefault(pid, 0L);
                if (have < price) { msg(p, "&cNot enough Shards (need " + fmt(price) + ")"); return; }
                shards.put(pid, have - price);
                for (ItemStack gi : g.goods.get(sidx)) give(p, gi.clone());
                msg(p, goodName(g.goods.get(sidx).get(0)) + " for " + fmt(price) + " Shards");
                openShardShop(p, g.page);
            }
            case "spawner" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openSpawner(p, sd, g.page + 1); return; }
                if (slot == 48) { openSpawnerSell(p, sd); return; }
                if (slot == 50) {
                    Location eye = p.getEyeLocation();
                    org.bukkit.util.Vector dir = eye.getDirection();
                    Location from = eye.clone().subtract(0, 0.3, 0);
                    int dropped = 0;
                    for (int ti = 0; ti < g.mats.size(); ti++) {
                        Material dm = g.mats.get(ti);
                        long have = sd.items.getOrDefault(dm, 0L);
                        int st = (int) Math.min(g.counts.get(ti), have);
                        if (st <= 0) continue;
                        org.bukkit.entity.Item dr = p.getWorld().dropItem(from, new ItemStack(dm, st));
                        dr.setVelocity(dir.clone().multiply(0.4));
                        dr.setPickupDelay(30);
                        long rem = have - st;
                        if (rem <= 0) sd.items.remove(dm); else sd.items.put(dm, rem);
                        dropped += st;
                    }
                    msg(p, dropped > 0 ? "&aDropped " + dropped + " items" : "&cNothing to drop");
                    openSpawner(p, sd, g.page);
                    return;
                }
                if (slot < 45 && slot < g.mats.size()) {
                    Material m = g.mats.get(slot);
                    takeFromSpawner(p, sd, m, g.counts.get(slot));
                    openSpawner(p, sd, g.page);
                }
            }
            case "sus" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openSus(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openSus(p, g.page + 1); return; }
                if (slot < 45 && slot < g.uuids.size()) {
                    Player st = Bukkit.getPlayer(g.uuids.get(slot));
                    if (st == null) { msg(p, "&cThat player is offline"); openSus(p, g.page); return; }
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        p.teleportAsync(st.getLocation());
                        msg(p, "Teleported to " + st.getName());
                    });
                }
            }
            case "settingall" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                if (slot == 11) openPriceMgr(p, 0);
                else if (slot == 13) openCfg(p, "", 0);
                else if (slot == 15) { reloadConfig(); msg(p, "&aConfig reloaded"); }
            }
            case "cfg" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                final String cpath = g.filter == null ? "" : g.filter;
                if (slot == 45 && it.getType() == Material.ARROW) { openCfg(p, cpath, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openCfg(p, cpath, g.page + 1); return; }
                if (slot == 48) {
                    if (cpath.isEmpty()) openSettingAll(p);
                    else openCfg(p, cpath.contains(".") ? cpath.substring(0, cpath.lastIndexOf('.')) : "", 0);
                    return;
                }
                if (slot < 45 && slot < g.names.size()) {
                    String ent = g.names.get(slot);
                    String kind = ent.substring(0, 1);
                    final String full = ent.substring(2);
                    final int pgc = g.page;
                    if (kind.equals("S")) { openCfg(p, full, 0); return; }
                    if (kind.equals("B")) {
                        getConfig().set(full, !getConfig().getBoolean(full));
                        saveConfig();
                        msg(p, "&aSet &e" + full + " &ato &f" + getConfig().getBoolean(full));
                        openCfg(p, cpath, pgc);
                        return;
                    }
                    if (kind.equals("N") || kind.equals("T")) {
                        final Object cur = getConfig().get(full);
                        String shortName = full.substring(full.lastIndexOf('.') + 1);
                        if (shortName.length() > 15) shortName = shortName.substring(0, 15);
                        final String hint = shortName;
                        Bukkit.getScheduler().runTask(this, () -> {
                            p.closeInventory();
                            boolean okC = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "New value", hint}, text -> {
                                if (text == null || text.isBlank()) { openCfg(p, cpath, pgc); return; }
                                Object nv;
                                if (cur instanceof Number) {
                                    double dv = parseAmount(text.trim());
                                    if (dv < 0) { msg(p, "&cInvalid number"); openCfg(p, cpath, pgc); return; }
                                    boolean whole = dv == Math.rint(dv) && dv < 9.0E15;
                                    if (cur instanceof Integer && whole && dv <= Integer.MAX_VALUE) nv = (int) dv;
                                    else if (cur instanceof Long && whole) nv = (long) dv;
                                    else nv = dv;
                                } else {
                                    nv = text;
                                }
                                getConfig().set(full, nv);
                                saveConfig();
                                msg(p, "&aSet &e" + full + " &ato &f" + nv + " &7(some settings need a restart)");
                                openCfg(p, cpath, pgc);
                            });
                            if (!okC) openCfg(p, cpath, pgc);
                        });
                    }
                }
            }
            case "pricemgr" -> {
                if (!isStaff(p)) { p.closeInventory(); return; }
                if (slot == 45 && it.getType() == Material.ARROW) { openPriceMgr(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openPriceMgr(p, g.page + 1); return; }
                if (slot == 47) { priceShopMode.put(pid, !priceShopMode.getOrDefault(pid, false)); openPriceMgr(p, 0); return; }
                if (slot == 51 && it.getType() == Material.BARRIER) { priceSearch.remove(pid); openPriceMgr(p, 0); return; }
                if (slot == 49) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okS = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Type an item name", "(empty = all)"}, text -> {
                            if (text == null || text.isBlank()) priceSearch.remove(pid); else priceSearch.put(pid, text);
                            openPriceMgr(p, 0);
                        });
                        if (!okS) openPriceMgr(p, 0);
                    });
                    return;
                }
                if (slot < 45 && slot < g.names.size()) {
                    final String pkey = g.names.get(slot);
                    final boolean shopM = "shop".equals(g.filter);
                    final int pg = g.page;
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        boolean okP = signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "New price", "reset = default"}, text -> {
                            String res = applyPriceEdit(shopM, pkey, text);
                            if (res != null) msg(p, res);
                            openPriceMgr(p, pg);
                        });
                        if (!okP) openPriceMgr(p, pg);
                    });
                }
            }
            case "spawnersell" -> {
                SpawnerData sd = g.sp;
                if (sd == null || !spawners.containsKey(sd.id)) { p.closeInventory(); return; }
                if (slot == 11) { openSpawner(p, sd, 0); return; }
                if (slot == 13) {
                    double total = spawnerTotalValue(sd);
                    msg(p, total > 0 ? "You will get $" + fmt(total) + " for selling everything in this spawner" : "Nothing to sell");
                    return;
                }
                if (slot == 15) {
                    double total = spawnerTotalValue(sd);
                    if (total <= 0) { msg(p, "&cNothing to sell"); openSpawner(p, sd, 0); return; }
                    sd.items.clear();
                    add(pid, total);
                    msg(p, "&aSold the spawner's items for &e$" + fmt(total));
                    notifyFollowers(p, "sell", "sold spawner items for $" + fmt(total));
                    openSpawner(p, sd, 0);
                }
            }
            case "ah" -> {
                if (slot == 45 && it.getType() == Material.ARROW) { openAh(p, g.page - 1); return; }
                if (slot == 53 && it.getType() == Material.ARROW) { openAh(p, g.page + 1); return; }
                if (slot == 47) { ahSort.put(pid, (ahSort.getOrDefault(pid, 0) + 1) % 3); openAh(p, 0); return; }
                if (slot == 48) { openAh(p, g.page); return; }
                if (slot == 49) { openAhSell(p); return; }
                if (slot == 50) {
                    Bukkit.getScheduler().runTask(this, () -> {
                        p.closeInventory();
                        signPrompt(p, new String[]{"", "^^^^^^^^^^^^^^", "Search listings", "(empty = all)"}, text -> {
                            ahSearch.put(pid, text);
                            openAh(p, 0);
                        });
                    });
                    return;
                }
                if (slot == 51) { openAhMy(p); return; }
                if (slot >= 45 || slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAh(p, g.page); return; }
                if (l.seller.equals(pid)) { openAhManage(p, l); return; }
                buyListing(p, l);
                openAh(p, g.page);
            }
            case "ahmy" -> {
                if (slot == 45) { openAh(p, 0); return; }
                if (slot >= 45 || slot >= g.shown.size()) return;
                Listing l = g.shown.get(slot);
                if (!listings.contains(l)) { openAhMy(p); return; }
                openAhManage(p, l);
            }
            case "ahmanage" -> {
                if (slot == 11) { openAhMy(p); return; }
                if (slot == 15) {
                    Listing l = g.shown.isEmpty() ? null : g.shown.get(0);
                    if (l != null && listings.remove(l)) {
                        give(p, l.item.clone());
                        msg(p, "You collected your item");
                    }
                    openAhMy(p);
                }
            }
        }
    }

    // ---------- /rtp ----------
    void rtpCmd(Player p, String[] a) {
        if (a.length == 0) { openRtp(p); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "overworld", "ow", "world", "normal" -> rtp(p, World.Environment.NORMAL);
            case "nether", "hell" -> rtp(p, World.Environment.NETHER);
            case "end", "the_end" -> rtp(p, World.Environment.THE_END);
            default -> openRtp(p);
        }
    }

    void openRtp(Player p) {
        Gui g = new Gui("rtp");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lRTP - Choose Dimension"));
        g.inv.setItem(11, item(Material.GRASS_BLOCK, "&aOverworld", "&7Click to teleport randomly"));
        g.inv.setItem(13, item(Material.NETHERRACK, "&cNether", "&7Click to teleport randomly"));
        g.inv.setItem(15, item(Material.END_STONE, "&dThe End", "&7Click to teleport randomly"));
        p.openInventory(g.inv);
    }

    World findWorld(World.Environment env) {
        return Bukkit.getWorlds().stream().filter(w -> w.getEnvironment() == env).findFirst().orElse(null);
    }

    void rtp(Player p, World.Environment env) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("rtp.cooldown", 10) * 1000;
        Long last = rtpCooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) { msg(p, "&cPlease wait " + ((cd - (now - last)) / 1000 + 1) + " more seconds"); return; }
        World w = findWorld(env);
        if (w == null) { msg(p, "&cThat dimension was not found on the server"); return; }
        rtpCooldown.put(p.getUniqueId(), now);
        msg(p, "&eFinding a random location...");
        tryRtp(p, w, 0, env == World.Environment.THE_END ? 80 : 20);
    }

    void tryRtp(Player p, World w, int tries, int maxTries) {
        if (tries >= maxTries) { msg(p, "&cCould not find a safe location, try again"); rtpCooldown.remove(p.getUniqueId()); return; }
        String key = switch (w.getEnvironment()) { case NETHER -> "nether"; case THE_END -> "end"; default -> "overworld"; };
        int defMin = switch (key) { case "nether" -> 300; case "end" -> 1200; default -> 500; };
        int defMax = switch (key) { case "nether" -> 2500; case "end" -> 4000; default -> 5000; };
        Location ctr = w.getWorldBorder().getCenter();
        int max = (int) Math.min(getConfig().getInt("rtp." + key + ".max", defMax), w.getWorldBorder().getSize() / 2 - 16);
        int min = Math.min(getConfig().getInt("rtp." + key + ".min", defMin), max / 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = min + r.nextDouble() * (max - min);
        int x = (int) (ctr.getX() + Math.cos(ang) * dist);
        int z = (int) (ctr.getZ() + Math.sin(ang) * dist);
        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(ch -> Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            Location loc = findSafe(w, x, z);
            if (loc == null) { tryRtp(p, w, tries + 1, maxTries); return; }
            p.teleportAsync(loc).thenAccept(ok -> {
                if (ok) { msg(p, "&aTeleported! &7X: " + x + " Z: " + z); notifyFollowers(p, "tp", "used /rtp"); }
            });
        }));
    }

    Location findSafe(World w, int x, int z) {
        if (w.getEnvironment() == World.Environment.NETHER) {
            for (int y = 120; y >= 33; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (isSafe(b)) return new Location(w, x + 0.5, y + 1, z + 0.5);
            }
            return null;
        }
        int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (y < w.getMinHeight()) return null;
        Block b = w.getBlockAt(x, y, z);
        return isSafe(b) ? new Location(w, x + 0.5, y + 1, z + 0.5) : null;
    }

    boolean isSafe(Block b) {
        Material t = b.getType();
        if (!t.isSolid() || Tag.LEAVES.isTagged(t)) return false;
        switch (t) {
            case MAGMA_BLOCK, CACTUS, CAMPFIRE, SOUL_CAMPFIRE, POWDER_SNOW, SWEET_BERRY_BUSH,
                 WITHER_ROSE, CHORUS_PLANT, CHORUS_FLOWER, BEDROCK -> { return false; }
            default -> { }
        }
        for (int i = 1; i <= 2; i++) {
            Block a = b.getRelative(0, i, 0);
            Material at = a.getType();
            if (!a.isPassable() || a.isLiquid() || at == Material.FIRE || at == Material.SOUL_FIRE || at == Material.LAVA) return false;
        }
        return true;
    }

    // ---------- Tab complete ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if (n.equals("register") || n.equals("login") || n.equals("loginauto")) return List.of();
        if (n.equals("follow")) {
            if (a.length == 1) { List<String> o = new ArrayList<>(List.of("list", "settings")); o.addAll(allNames(a[0])); return o.stream().filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList()); }
            return List.of();
        }
        if (n.equals("unfollow") && s instanceof Player fp) {
            if (a.length != 1) return List.of();
            List<String> o = new ArrayList<>();
            for (UUID u : following.getOrDefault(fp.getUniqueId(), Set.of())) { String nn = Bukkit.getOfflinePlayer(u).getName(); if (nn != null && nn.toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))) o.add(nn); }
            return o;
        }
        if (n.equals("createrank")) {
            if (a.length == 2) return COLOR_NAMES.keySet().stream().filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            if (a.length >= 3) return Stream.of("fly", "homes", "none").filter(k -> k.startsWith(a[a.length - 1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            return List.of();
        }
        if (n.equals("deleterank")) return a.length == 1 ? customRankNames().stream().filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList()) : List.of();
        if (n.equals("tia")) {
            if (a.length == 1) { List<String> o = new ArrayList<>(List.of("list", "give", "remove")); o.addAll(allNames(a[0])); return o.stream().filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList()); }
            if (a.length == 2 && (a[0].equalsIgnoreCase("give") || a[0].equalsIgnoreCase("remove"))) return allNames(a[1]);
            if (a.length == 3 && a[0].equalsIgnoreCase("give")) return TIER_ORDER.stream().filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            return List.of();
        }
        if (n.equals("unregister")) return a.length == 1 && isStaff(s) ? allNames(a[0]) : List.of();
        if ((n.equals("home") || n.equals("delhome")) && a.length == 1 && s instanceof Player p) {
            ConfigurationSection hs = data.getConfigurationSection("homes." + p.getUniqueId());
            return hs == null ? List.of() : hs.getKeys(false).stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if ((n.equals("pay") || n.equals("tpa") || n.equals("tphere")) && a.length == 1) return names(a[0]);
        if ((n.equals("balance") || n.equals("stats")) && a.length == 1) return allNames(a[0]);
        if (n.equals("dounty")) {
            if (a.length == 1) return Stream.of("add").filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            if (a.length == 2 && a[0].equalsIgnoreCase("add")) return allNames(a[1]);
            if (a.length == 3 && a[0].equalsIgnoreCase("add")) return List.of("1000", "10000", "100000", "1M");
            return List.of();
        }
        if (n.equals("eco")) {
            if (a.length == 1) return List.of("give", "take", "set", "reset", "proset");
            if (a.length == 2) { List<String> o = new ArrayList<>(List.of("@a", "@e", "@n", "@p", "@r", "@s")); o.addAll(allNames(a[1])); return o.stream().filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList()); }
            if (a.length == 3) return a[0].equalsIgnoreCase("proset") || a[0].equalsIgnoreCase("reset")
                    ? List.of("all", "money", "shard", "level", "kill", "death", "time") : List.of("money", "shard", "level", "kill", "death", "time");
        }
        if (n.equals("unoffend") && a.length == 1) {
            List<String> out = new ArrayList<>();
            for (UUID bu : bans.keySet()) {
                String bn = Bukkit.getOfflinePlayer(bu).getName();
                if (bn != null && bn.toLowerCase(Locale.ROOT).startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(bn);
            }
            return out;
        }
        if (n.equals("offend")) {
            if (a.length == 1) return allNames(a[0]);
            if (a.length == 2) return Arrays.stream(OFFENCES).filter(k -> k.toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            if (a.length == 3) return List.of("1d", "7d", "14d", "30d", "perm").stream().filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            return List.of();
        }
        if (n.equals("rtp") && a.length == 1) return List.of("overworld", "nether", "end");
        if (n.equals("afk")) {
            if (!s.hasPermission("donutsmp.admin")) return List.of();
            if (a.length == 1) return List.of("set", "reset").stream().filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            return List.of();
        }
        if (n.equals("givera")) {
            if (a.length >= 1 && a[0].equalsIgnoreCase("re")) {
                if (a.length == 2) { List<String> o = new ArrayList<>(List.of("all", "OWNER", "ADMIN", "CREATOR", "+", "++", "+++")); o.addAll(customRankNames()); return o; }
                if (a.length == 3) return allNames(a[2]);
                return List.of();
            }
            if (a.length == 1) { List<String> o = new ArrayList<>(allNames(a[0])); o.add("re"); return o; }
            if (a.length == 2) { List<String> o = new ArrayList<>(List.of("OWNER", "ADMIN", "CREATOR", "+", "++", "+++")); o.addAll(customRankNames()); return o; }
        }
        if (n.equals("shards")) {
            if (a.length == 1) return List.of("pay");
            if (a.length == 2 && a[0].equalsIgnoreCase("pay")) return names(a[1]);
        }
        if (n.equals("spawner")) {
            if (a.length == 1) return List.of("give", "fill");
            if (a.length == 2 && a[0].equalsIgnoreCase("fill")) return mobs(a[1]);
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return Arrays.stream(EntityType.values()).filter(EntityType::isAlive).map(t -> t.name().toLowerCase(Locale.ROOT))
                    .filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        if (n.equals("bless")) {
            if (a.length == 1) return List.of("give", "pack");
            if (a.length == 2) return names(a[1]);
            if (a.length == 3) return List.of("saw", "book", "all");
        }
        if (n.equals("protect")) {
            if (a.length == 1) return Stream.of("info", "show", "list", "tiers", "add", "remove", "give", "delete", "bypass").filter(k -> k.startsWith(a[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            if (a.length == 2 && (a[0].equalsIgnoreCase("add") || a[0].equalsIgnoreCase("remove") || a[0].equalsIgnoreCase("give"))) return names(a[1]);
            if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
                List<String> o = new ArrayList<>(List.of("protect"));
                protectTierIds().forEach(k -> o.add(k.toLowerCase(Locale.ROOT)));
                return o.stream().filter(k -> k.startsWith(a[2].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
            }
            if (a.length == 4 && a[0].equalsIgnoreCase("give")) return List.of("19", "39", "59", "99", "149");
        }
        if (n.equals("ah") && a.length == 1) return List.of("sell");
        if (n.equals("team")) {
            if (a.length == 1) return List.of("create", "invite", "accept", "leave", "info");
            if (a.length == 2 && a[0].equalsIgnoreCase("invite")) return names(a[1]);
        }
        if (n.equals("order")) {
            if (a.length == 1) return List.of("create", "claim");
            if (a.length == 2 && a[0].equalsIgnoreCase("create"))
                return Arrays.stream(Material.values()).filter(Material::isItem).map(m -> m.name().toLowerCase(Locale.ROOT))
                        .filter(k -> k.startsWith(a[1].toLowerCase(Locale.ROOT))).limit(40).collect(Collectors.toList());
        }
        return List.of();
    }


    // legacy-colour text -> component without the default italics
    Component plain(String legacy) {
        return LegacyComponentSerializer.legacySection().deserialize(c(legacy))
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);
    }

    // =====================================================================
    // ============== LAND PROTECTION (coral protection stones) ============
    // =====================================================================
    static class Protect {
        UUID owner; String world; int x, y, z; String tier; int half; boolean circle;
        Set<UUID> members = new HashSet<>();
        boolean contains(String w, int bx, int bz) {
            if (!world.equals(w)) return false;
            int dx = bx - x, dz = bz - z;
            if (circle) { double r = half + 0.5; return dx * dx + dz * dz <= r * r; }
            return Math.abs(dx) <= half && Math.abs(dz) <= half;
        }
        boolean overlaps(String w, int cx, int cz, int h, boolean c2) {
            if (!world.equals(w)) return false;
            int dx = cx - x, dz = cz - z;
            if (circle && c2) { double r = half + h + 1.0; return dx * dx + dz * dz <= r * r; }
            return Math.abs(dx) <= half + h && Math.abs(dz) <= half + h;
        }
        int size() { return half * 2 + 1; }
    }

    private final List<Protect> protects = new ArrayList<>();
    private final Map<UUID, Protect> protectInside = new HashMap<>();
    private NamespacedKey protectKey;

    NamespacedKey prk() {
        if (protectKey == null) protectKey = new NamespacedKey(this, "protect_tier");
        return protectKey;
    }

    // ---- tiers (config: protect.tiers.<ID>.{block,size,price,name}); defaults are used when the config has none ----
    static final String[][] DEF_TIERS = {
            // id, block, size, shard price, shop slot
            {"TUBE", "TUBE_CORAL_BLOCK", "19", "500", "37"},
            {"BRAIN", "BRAIN_CORAL_BLOCK", "39", "1500", "38"},
            {"BUBBLE", "BUBBLE_CORAL_BLOCK", "59", "3500", "40"},
            {"FIRE", "FIRE_CORAL_BLOCK", "99", "8000", "42"},
            {"HORN", "HORN_CORAL_BLOCK", "149", "15000", "43"}};

    List<String> protectTierIds() {
        ConfigurationSection cs = getConfig().getConfigurationSection("protect.tiers");
        if (cs != null && !cs.getKeys(false).isEmpty()) return new ArrayList<>(cs.getKeys(false));
        List<String> l = new ArrayList<>();
        for (String[] d : DEF_TIERS) l.add(d[0]);
        return l;
    }

    String[] tierDef(String id) {
        for (String[] d : DEF_TIERS) if (d[0].equals(id)) return d;
        return new String[]{id, "BRAIN_CORAL_BLOCK", "19", "1000", "-1"};
    }

    Material tierBlock(String id) {
        Material m = Material.matchMaterial(getConfig().getString("protect.tiers." + id + ".block", tierDef(id)[1]));
        return m == null || !m.isBlock() ? Material.BRAIN_CORAL_BLOCK : m;
    }

    int tierSize(String id) {
        int min = Math.max(19, getConfig().getInt("protect.min-size", 19));   // never smaller than 19x19
        int sz = Math.max(min, getConfig().getInt("protect.tiers." + id + ".size", Integer.parseInt(tierDef(id)[2])));
        return sz % 2 == 0 ? sz + 1 : sz;                                       // odd, so the stone is in the middle
    }

    long tierPrice(String id) { return getConfig().getLong("protect.tiers." + id + ".price", Long.parseLong(tierDef(id)[3])); }

    int tierShopSlot(String id) { return getConfig().getInt("protect.tiers." + id + ".shop-slot", Integer.parseInt(tierDef(id)[4])); }

    String tierName(String id) { return getConfig().getString("protect.tiers." + id + ".name", "&b&lProtection Stone"); }

    ItemStack protectItem(String id) { return protectItem(id, tierSize(id)); }

    // size = side length in blocks (made odd, never below the minimum)
    int fixSize(int sz) {
        int min = Math.max(19, getConfig().getInt("protect.min-size", 19));
        int max = Math.max(min, getConfig().getInt("protect.max-custom-size", 999));
        sz = Math.max(min, Math.min(max, sz));
        return sz % 2 == 0 ? sz + 1 : sz;
    }

    ItemStack protectItem(String id, int size) {
        ItemStack it = new ItemStack(tierBlock(id));
        ItemMeta mt = it.getItemMeta();
        int sz = fixSize(size);
        mt.getPersistentDataContainer().set(prsKey(), PersistentDataType.INTEGER, sz);
        mt.displayName(plain(tierName(id) + " &7(" + sz + "x" + sz + ")"));
        mt.lore(List.of(plain("&7Protects a &f" + sz + " &7block wide " + (getConfig().getString("protect.shape", "square").equalsIgnoreCase("square") ? "square" : "circle") + ", full height"),
                plain("&7Place it in the middle of your land"),
                plain("&7Place more stones inside your land to extend it"),
                plain("&7Only you and your members can build, break or open things"),
                plain("&e/protect &7to manage it")));
        mt.getPersistentDataContainer().set(prk(), PersistentDataType.STRING, id);
        it.setItemMeta(mt);
        return it;
    }

    private NamespacedKey protectSizeKey;

    NamespacedKey prsKey() {
        if (protectSizeKey == null) protectSizeKey = new NamespacedKey(this, "protect_size");
        return protectSizeKey;
    }

    int protectSizeOf(ItemStack it, String tier) {
        Integer v = it.getItemMeta().getPersistentDataContainer().get(prsKey(), PersistentDataType.INTEGER);
        return v == null ? tierSize(tier) : fixSize(v);
    }

    String protectTierOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(prk(), PersistentDataType.STRING);
    }

    // ---- lookup ----
    Protect protectAt(Location l) {
        if (l == null || l.getWorld() == null || protects.isEmpty()) return null;
        String w = l.getWorld().getName();
        int bx = l.getBlockX(), bz = l.getBlockZ();
        for (Protect pr : protects) if (pr.contains(w, bx, bz)) return pr;
        return null;
    }

    Protect protectAt(Block b) { return b == null ? null : protectAt(b.getLocation()); }

    private final Set<UUID> protectBypassOn = new HashSet<>();

    // staff are restricted like everyone else until they run /pt bypass
    boolean protectBypass(Player p) { return protectBypassOn.contains(p.getUniqueId()) && isStaff(p); }

    // two parts of the same owner's land count as one piece of land
    boolean sameOwner(Protect a, Protect b) { return a == b || (a != null && b != null && a.owner.equals(b.owner)); }

    // every part of this owner's land that touches (directly or through other parts) the given part
    List<Protect> landGroup(Protect start) {
        List<Protect> grp = new ArrayList<>(List.of(start));
        for (int i = 0; i < grp.size(); i++) {
            Protect c = grp.get(i);
            for (Protect o : protects)
                if (!grp.contains(o) && o.owner.equals(start.owner) && o.overlaps(c.world, c.x, c.z, c.half, c.circle)) grp.add(o);
        }
        return grp;
    }

    Protect stoneAt(Block b) {
        for (Protect o : protects)
            if (o.x == b.getX() && o.y == b.getY() && o.z == b.getZ() && o.world.equals(b.getWorld().getName())) return o;
        return null;
    }

    boolean protectMember(Protect pr, UUID id) { return pr.owner.equals(id) || pr.members.contains(id); }

    // may this player change things at this block?
    boolean canBuild(Player p, Block b) {
        Protect pr = protectAt(b);
        return pr == null || protectMember(pr, p.getUniqueId()) || protectBypass(p);
    }

    String ownerName(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "Unknown" : n;
    }

    void denyProtect(Player p, Protect pr) {
        p.sendActionBar(Component.text(w("This land is protected by " + ownerName(pr.owner)), NamedTextColor.RED));
    }

    int protectCount(UUID id) {
        int n = 0;
        for (Protect pr : protects) if (pr.owner.equals(id)) n++;
        return n;
    }

    // ---- storage ----
    void loadProtects() {
        protects.clear();
        ConfigurationSection ps = data.getConfigurationSection("protects");
        if (ps == null) return;
        for (String k : ps.getKeys(false)) {
            ConfigurationSection s = ps.getConfigurationSection(k);
            try {
                Protect pr = new Protect();
                pr.owner = UUID.fromString(s.getString("owner"));
                pr.world = s.getString("world");
                pr.x = s.getInt("x"); pr.y = s.getInt("y"); pr.z = s.getInt("z");
                pr.tier = s.getString("tier", "TUBE");
                pr.half = s.getInt("half", 9);
                pr.circle = s.getBoolean("circle", false);
                for (String m : s.getStringList("members")) pr.members.add(UUID.fromString(m));
                protects.add(pr);
            } catch (Exception ignored) { }
        }
    }

    void saveProtects() {
        data.set("protects", null);
        int i = 0;
        for (Protect pr : protects) {
            String b = "protects." + (i++) + ".";
            data.set(b + "owner", pr.owner.toString());
            data.set(b + "world", pr.world);
            data.set(b + "x", pr.x); data.set(b + "y", pr.y); data.set(b + "z", pr.z);
            data.set(b + "tier", pr.tier);
            data.set(b + "half", pr.half);
            data.set(b + "circle", pr.circle);
            data.set(b + "members", pr.members.stream().map(UUID::toString).collect(Collectors.toList()));
        }
    }

    // ---- place / break the protection stone ----
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlockPlaced();
        String tier = protectTierOf(e.getItemInHand());
        if (tier == null) {
            if (!canBuild(p, b)) { e.setCancelled(true); denyProtect(p, protectAt(b)); }
            return;
        }
        if (!getConfig().getBoolean("protect.enabled", true)) { e.setCancelled(true); msg(p, "&cProtection is disabled"); return; }
        List<String> worlds = getConfig().getStringList("protect.worlds");
        if (!worlds.isEmpty() && !worlds.contains(b.getWorld().getName())) { e.setCancelled(true); msg(p, "&cYou can't use protection in this world"); return; }
        int max = getConfig().getInt("protect.max-per-player", 3);
        if (max > 0 && protectCount(p.getUniqueId()) >= max && !protectBypass(p)) {
            e.setCancelled(true);
            msg(p, "&cYou already have " + max + " protected lands (the maximum)");
            return;
        }
        int sz = protectSizeOf(e.getItemInHand(), tier);
        int half = sz / 2;
        boolean circ = !getConfig().getString("protect.shape", "square").equalsIgnoreCase("square");
        List<Protect> mine = new ArrayList<>();
        for (Protect o : protects) {
            if (!o.overlaps(b.getWorld().getName(), b.getX(), b.getZ(), half, circ)) continue;
            if (o.owner.equals(p.getUniqueId())) { mine.add(o); continue; }   // your own land: allowed, it just grows
            e.setCancelled(true);
            msg(p, "&cThis overlaps land protected by " + ownerName(o.owner) + " - move further away");
            return;
        }
        Protect pr = new Protect();
        pr.owner = p.getUniqueId();
        pr.world = b.getWorld().getName();
        pr.x = b.getX(); pr.y = b.getY(); pr.z = b.getZ();
        pr.tier = tier;
        pr.half = half;
        pr.circle = circ;
        for (Protect o : mine) pr.members.addAll(o.members);          // friends carry over to the new part
        for (Protect o : mine) o.members.addAll(pr.members);
        protects.add(pr);
        msg(p, mine.isEmpty()
                ? "&aLand protected: &e" + sz + "x" + sz + " &a(full height). &7/protect add <player> lets a friend build, /protect show shows the border"
                : "&aYour protected land was extended with another &e" + sz + "x" + sz + " &astone");
        p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.2f);
        showProtect(p, pr);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();
        Protect stone = stoneAt(b);
        Protect pr = stone != null ? stone : protectAt(b);
        if (pr == null) return;
        if (stone != null) {
            if (!pr.owner.equals(p.getUniqueId()) && !protectBypass(p)) {
                e.setCancelled(true);
                msg(p, "&cOnly the owner can remove this protection stone");
                return;
            }
            // owner picks the stone up again; the land becomes unprotected
            e.setDropItems(false);
            e.setCancelled(true);
            b.setType(Material.AIR);
            protects.remove(pr);
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), protectItem(pr.tier, pr.size()));
            msg(p, "&eProtection removed. Pick up the stone to place it again");
            return;
        }
        if (!protectMember(pr, p.getUniqueId()) && !protectBypass(p)) { e.setCancelled(true); denyProtect(p, pr); }
    }

    // ---- interacting ----
    boolean protectedUse(Block b, ItemStack hand) {
        if (b.getState() instanceof org.bukkit.block.Container) return true;
        if (b.getBlockData() instanceof org.bukkit.block.data.Openable || b.getBlockData() instanceof org.bukkit.block.data.Powerable) return true;
        Material t = b.getType();
        if (t == Material.SPAWNER || t == Material.ANVIL || t == Material.CHIPPED_ANVIL || t == Material.DAMAGED_ANVIL
                || t == Material.ENCHANTING_TABLE || t == Material.BREWING_STAND || t == Material.JUKEBOX
                || t == Material.LECTERN || t == Material.CAKE || t == Material.COMPOSTER || t == Material.CAULDRON
                || t == Material.RESPAWN_ANCHOR || t == Material.FLOWER_POT || t.name().endsWith("_BED") || t.name().contains("SIGN")) return true;
        if (hand == null) return false;
        String h = hand.getType().name();
        return h.endsWith("_BUCKET") || h.equals("FLINT_AND_STEEL") || h.equals("FIRE_CHARGE") || h.endsWith("_SPAWN_EGG")
                || h.equals("ARMOR_STAND") || h.endsWith("ITEM_FRAME") || h.equals("PAINTING") || h.endsWith("_BOAT") || h.endsWith("MINECART")
                || h.equals("END_CRYSTAL") || h.endsWith("_DYE") || h.equals("BONE_MEAL") || h.endsWith("_HOE") || h.endsWith("_AXE") || h.endsWith("_SHOVEL");
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null) return;
        Player p = e.getPlayer();
        Protect pr = protectAt(b);
        if (pr == null || protectMember(pr, p.getUniqueId()) || protectBypass(p)) return;
        if (e.getAction() == Action.PHYSICAL) {
            if (b.getType() == Material.FARMLAND || b.getType() == Material.TURTLE_EGG) e.setCancelled(true);
            return;
        }
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && protectedUse(b, e.getItem())) {
            e.setCancelled(true);
            e.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);
            e.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
            denyProtect(p, pr);
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectBucket(org.bukkit.event.player.PlayerBucketEmptyEvent e) {
        Protect pr = protectAt(e.getBlock());
        if (pr != null && !protectMember(pr, e.getPlayer().getUniqueId()) && !protectBypass(e.getPlayer())) { e.setCancelled(true); denyProtect(e.getPlayer(), pr); }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectBucketFill(org.bukkit.event.player.PlayerBucketFillEvent e) {
        Protect pr = protectAt(e.getBlock());
        if (pr != null && !protectMember(pr, e.getPlayer().getUniqueId()) && !protectBypass(e.getPlayer())) { e.setCancelled(true); denyProtect(e.getPlayer(), pr); }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectEntityInteract(org.bukkit.event.player.PlayerInteractEntityEvent e) {
        Entity t = e.getRightClicked();
        if (!(t instanceof org.bukkit.entity.Hanging) && !(t instanceof org.bukkit.entity.ArmorStand)
                && !(t instanceof org.bukkit.entity.Animals) && !(t instanceof org.bukkit.entity.Villager)
                && !(t instanceof org.bukkit.entity.minecart.StorageMinecart) && !(t instanceof org.bukkit.entity.minecart.HopperMinecart)) return;
        Protect pr = protectAt(t.getLocation());
        if (pr != null && !protectMember(pr, e.getPlayer().getUniqueId()) && !protectBypass(e.getPlayer())) { e.setCancelled(true); denyProtect(e.getPlayer(), pr); }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectEntityDamage(org.bukkit.event.entity.EntityDamageByEntityEvent e) {
        Entity t = e.getEntity();
        if (t instanceof Player || t instanceof org.bukkit.entity.Monster) return;
        if (!(t instanceof org.bukkit.entity.Hanging) && !(t instanceof org.bukkit.entity.ArmorStand)
                && !(t instanceof org.bukkit.entity.Animals) && !(t instanceof org.bukkit.entity.Villager)
                && !(t instanceof org.bukkit.entity.Vehicle) && !(t instanceof EnderCrystal)) return;
        Entity d = e.getDamager();
        Player who = d instanceof Player pp ? pp : (d instanceof org.bukkit.entity.Projectile pj && pj.getShooter() instanceof Player sp ? sp : null);
        Protect pr = protectAt(t.getLocation());
        if (pr == null) return;
        if (who == null) {   // explosions etc. from outside
            if (d instanceof TNTPrimed || d instanceof org.bukkit.entity.Creeper || d instanceof EnderCrystal) e.setCancelled(true);
            return;
        }
        if (!protectMember(pr, who.getUniqueId()) && !protectBypass(who)) { e.setCancelled(true); denyProtect(who, pr); }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectHangingBreak(org.bukkit.event.hanging.HangingBreakByEntityEvent e) {
        Protect pr = protectAt(e.getEntity().getLocation());
        if (pr == null) return;
        Entity r = e.getRemover();
        Player who = r instanceof Player pp ? pp : (r instanceof org.bukkit.entity.Projectile pj && pj.getShooter() instanceof Player sp ? sp : null);
        if (who == null || (!protectMember(pr, who.getUniqueId()) && !protectBypass(who))) e.setCancelled(true);
    }

    // ---- explosions, fire, liquids, pistons ----
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectExplode(EntityExplodeEvent e) {
        if (protects.isEmpty()) return;
        e.blockList().removeIf(b -> protectAt(b) != null);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectBlockExplode(org.bukkit.event.block.BlockExplodeEvent e) {
        if (protects.isEmpty()) return;
        e.blockList().removeIf(b -> protectAt(b) != null);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectBurn(org.bukkit.event.block.BlockBurnEvent e) {
        if (protectAt(e.getBlock()) != null) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectIgnite(org.bukkit.event.block.BlockIgniteEvent e) {
        Protect pr = protectAt(e.getBlock());
        if (pr == null) return;
        Player who = e.getPlayer();
        if (who == null || (!protectMember(pr, who.getUniqueId()) && !protectBypass(who))) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectFlow(org.bukkit.event.block.BlockFromToEvent e) {
        if (protects.isEmpty()) return;
        Protect to = protectAt(e.getToBlock());
        if (to != null && !sameOwner(to, protectAt(e.getBlock()))) e.setCancelled(true);   // lava/water from outside
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectPistonExtend(org.bukkit.event.block.BlockPistonExtendEvent e) {
        if (protects.isEmpty()) return;
        Protect home = protectAt(e.getBlock());
        for (Block m : e.getBlocks()) {
            Protect a = protectAt(m), d = protectAt(m.getRelative(e.getDirection()));
            if ((a != null && !sameOwner(a, home)) || (d != null && !sameOwner(d, home))) { e.setCancelled(true); return; }
        }
        Protect front = protectAt(e.getBlock().getRelative(e.getDirection()));
        if (front != null && !sameOwner(front, home)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onProtectPistonRetract(org.bukkit.event.block.BlockPistonRetractEvent e) {
        if (protects.isEmpty()) return;
        Protect home = protectAt(e.getBlock());
        for (Block m : e.getBlocks()) {
            Protect a = protectAt(m), d = protectAt(m.getRelative(e.getDirection()));
            if ((a != null && !sameOwner(a, home)) || (d != null && !sameOwner(d, home))) { e.setCancelled(true); return; }
        }
    }

    // ---- entering / leaving message ----
    @EventHandler
    public void onProtectMove(org.bukkit.event.player.PlayerMoveEvent e) {
        Location f = e.getFrom(), t = e.getTo();
        if (t == null || (f.getBlockX() == t.getBlockX() && f.getBlockZ() == t.getBlockZ() && f.getWorld() == t.getWorld())) return;
        Player p = e.getPlayer();
        Protect now = protectAt(t);
        Protect before = protectInside.get(p.getUniqueId());
        if (now == before) return;
        if (now != null && sameOwner(now, before)) { protectInside.put(p.getUniqueId(), now); return; }   // moving inside the same land
        if (now == null) protectInside.remove(p.getUniqueId()); else protectInside.put(p.getUniqueId(), now);
        if (now != null) {
            boolean mine = protectMember(now, p.getUniqueId());
            String em = getConfig().getString("protect.enter-message", "{player} Entering protection mode {owner}")
                    .replace("{player}", p.getName()).replace("{owner}", ownerName(now.owner));
            p.sendActionBar(Component.text(w(em), mine ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
        } else {
            p.sendActionBar(Component.text(w("You left the protected land"), NamedTextColor.GRAY));
        }
    }

    @EventHandler
    public void onProtectQuit(PlayerQuitEvent e) { protectInside.remove(e.getPlayer().getUniqueId()); protectBypassOn.remove(e.getPlayer().getUniqueId()); }

    // ---- show the border with particles (only the player sees it) ----
    void showProtect(Player p, Protect pr) {
        World w = Bukkit.getWorld(pr.world);
        if (w == null || !p.getWorld().equals(w)) return;
        final int[] pulses = {10};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!p.isOnline() || pulses[0]-- <= 0) { task.cancel(); return; }
            double y = p.getLocation().getY() + 1.0;
            if (pr.circle) {
                double cx = pr.x + 0.5, cz = pr.z + 0.5, r = pr.half + 0.5;
                int pts = (int) Math.max(48, Math.min(240, r * 4));
                for (int i = 0; i < pts; i++) {
                    double ang = 2 * Math.PI * i / pts;
                    double px = cx + Math.cos(ang) * r, pz = cz + Math.sin(ang) * r;
                    p.spawnParticle(Particle.END_ROD, px, y, pz, 1, 0, 0, 0, 0);
                    if (i % Math.max(1, pts / 8) == 0)
                        for (double dy = -1; dy <= 3; dy += 1) p.spawnParticle(Particle.HAPPY_VILLAGER, px, y + dy, pz, 1, 0, 0, 0, 0);
                }
            } else {
                double minX = pr.x - pr.half, maxX = pr.x + pr.half + 1, minZ = pr.z - pr.half, maxZ = pr.z + pr.half + 1;
                int step = Math.max(1, pr.size() / 40);
                for (double i = 0; i <= pr.size(); i += step) {
                    p.spawnParticle(Particle.END_ROD, minX + i, y, minZ, 1, 0, 0, 0, 0);
                    p.spawnParticle(Particle.END_ROD, minX + i, y, maxZ, 1, 0, 0, 0, 0);
                    p.spawnParticle(Particle.END_ROD, minX, y, minZ + i, 1, 0, 0, 0, 0);
                    p.spawnParticle(Particle.END_ROD, maxX, y, minZ + i, 1, 0, 0, 0, 0);
                }
                for (double dy = -1; dy <= 3; dy += 1) {
                    p.spawnParticle(Particle.HAPPY_VILLAGER, minX, y + dy, minZ, 1, 0, 0, 0, 0);
                    p.spawnParticle(Particle.HAPPY_VILLAGER, maxX, y + dy, minZ, 1, 0, 0, 0, 0);
                    p.spawnParticle(Particle.HAPPY_VILLAGER, minX, y + dy, maxZ, 1, 0, 0, 0, 0);
                    p.spawnParticle(Particle.HAPPY_VILLAGER, maxX, y + dy, maxZ, 1, 0, 0, 0, 0);
                }
            }
        }, 0L, 10L);
    }

    // ---- /protect ----
    void protectCmd(Player p, String[] a) {
        String sub = a.length == 0 ? "info" : a[0].toLowerCase(Locale.ROOT);
        UUID id = p.getUniqueId();
        Protect here = protectAt(p.getLocation());
        switch (sub) {
            case "info" -> {
                if (here == null) { msg(p, "&7You are not standing in protected land. &e/protect list &7shows yours, &e/protect tiers &7the sizes"); return; }
                String mem = here.members.isEmpty() ? "-" : here.members.stream().map(this::ownerName).collect(Collectors.joining(", "));
                msg(p, "&eOwner: &f" + ownerName(here.owner) + " &7| &eSize: &f" + here.size() + (here.circle ? " (circle)" : "x" + here.size()) + " &7| &eMembers: &f" + mem);
            }
            case "show" -> {
                Protect pr = here;
                if (pr == null) for (Protect o : protects) if (o.owner.equals(id) && o.world.equals(p.getWorld().getName())) { pr = o; break; }
                if (pr == null) { msg(p, "&cStand inside a protected land first"); return; }
                showProtect(p, pr);
                msg(p, "&aShowing the border for 5 seconds");
            }
            case "list" -> {
                int n = 0;
                for (Protect o : protects) if (o.owner.equals(id)) {
                    n++;
                    msg(p, "&e#" + n + " &f" + o.size() + "x" + o.size() + " &7at &f" + o.world + " " + o.x + ", " + o.y + ", " + o.z + " &7(members: " + o.members.size() + ")");
                }
                if (n == 0) msg(p, "&7You have no protected land. Buy a protection stone in &e/shardshop");
            }
            case "tiers" -> {
                for (String t : protectTierIds()) msg(p, "&e" + pretty(tierBlock(t)) + " &7= &f" + tierSize(t) + "x" + tierSize(t) + " &7(" + fmt(tierPrice(t)) + " Shards)");
            }
            case "add", "remove" -> {
                if (a.length < 2) { msg(p, "&e/protect " + sub + " <player>"); return; }
                if (here == null || (!here.owner.equals(id) && !protectBypass(p))) { msg(p, "&cStand inside YOUR protected land first"); return; }
                OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(a[1]);
                if (op == null) op = Bukkit.getPlayerExact(a[1]);
                if (op == null) { msg(p, "&cPlayer not found"); return; }
                if (op.getUniqueId().equals(here.owner)) { msg(p, "&cThat's the owner"); return; }
                if (sub.equals("add")) {
                    int lim = getConfig().getInt("protect.max-members", 10);
                    if (here.members.size() >= lim && !here.members.contains(op.getUniqueId())) { msg(p, "&cMax " + lim + " members"); return; }
                    for (Protect g2 : landGroup(here)) g2.members.add(op.getUniqueId());
                    msg(p, "&a" + a[1] + " can now build in this land");
                } else {
                    for (Protect g2 : landGroup(here)) g2.members.remove(op.getUniqueId());
                    msg(p, "&e" + a[1] + " was removed from this land");
                }
            }
            case "bypass" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return; }
                if (!protectBypassOn.remove(id)) { protectBypassOn.add(id); msg(p, "&aProtection bypass ON (you can build everywhere). Run /pt bypass again to turn it off"); }
                else msg(p, "&eProtection bypass OFF");
            }
            case "delete" -> {
                if (!protectBypass(p)) { msg(p, "&cYou do not have permission (break the stone to remove your own land)"); return; }
                if (here == null) { msg(p, "&cStand inside a protected land first"); return; }
                protects.remove(here);
                protectInside.clear();
                msg(p, "&eProtection removed (the stone block is still there)");
            }
            case "give" -> {
                if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return; }
                List<String> ids = protectTierIds();
                if (a.length < 3) { msg(p, "&e/pt give <player> <protect|" + String.join("|", ids).toLowerCase(Locale.ROOT) + "> [size]"); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) { msg(p, "&cPlayer offline"); return; }
                String tier = a[2].equalsIgnoreCase("protect") ? ids.get(0) : a[2].toUpperCase(Locale.ROOT);
                if (!ids.contains(tier)) { msg(p, "&cUnknown block. Use: protect, " + String.join(", ", ids).toLowerCase(Locale.ROOT)); return; }
                int size = tierSize(tier);
                if (a.length >= 4) {
                    try { size = Integer.parseInt(a[3]); } catch (NumberFormatException ex) { msg(p, "&cSize must be a number (e.g. 19)"); return; }
                }
                size = fixSize(size);
                give(t, protectItem(tier, size));
                msg(p, "&aGave " + t.getName() + " a " + pretty(tierBlock(tier)) + " protection stone (" + size + "x" + size + ")");
            }
            default -> msg(p, "&e/protect info | show | list | tiers | add <player> | remove <player>");
        }
    }

    // =====================================================================
    // ================= BLESSING: Blessing Saw + Book of Powers ============
    // =====================================================================
    static final String[] BLESS_IDS = {"AURORA", "VOID_BOLT", "SOLAR_BEAM", "PIXEL_WAVE", "CRIMSON_RUSH", "CRIMSON_DOMAIN"};
    static final int[] BLESS_SLOTS = {10, 11, 12, 14, 15, 16};
    static final String[] BLESS_NAMES = {"&b&lAurora Burst", "&5&lVoid Lightning", "&6&lSolar Beam", "&d&lPixel Shockwave", "&c&lCrimson Rush", "&4&lCrimson Domain"};
    static final Material[] BLESS_ICONS = {Material.END_ROD, Material.LIGHTNING_ROD, Material.BLAZE_ROD, Material.AMETHYST_SHARD, Material.NETHERITE_SWORD, Material.REDSTONE_BLOCK};
    static final String[] BLESS_DESC = {
            "A huge flash of aurora light where you aim - blinds and launches enemies",
            "Purple lightning strikes where you aim",
            "A piercing orange beam straight ahead",
            "A magenta pixel shockwave that spreads out from you",
            "Dash forward and slash everything in your path",
            "A blood-red dome around YOU that follows you and hurts everything inside"};
    static final int[] BLESS_CD = {12, 10, 12, 14, 8, 30};
    static final double[] BLESS_DMG = {10, 12, 14, 8, 10, 3};

    private NamespacedKey blessKey;
    private final Map<UUID, long[]> blessCd = new HashMap<>();

    NamespacedKey bkey() {
        if (blessKey == null) blessKey = new NamespacedKey(this, "bless_item");
        return blessKey;
    }

    String blessKind(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(bkey(), PersistentDataType.STRING);
    }

    int blessSel(UUID id) { return Math.max(0, Math.min(BLESS_IDS.length - 1, data.getInt("blessing." + id, 0))); }

    long blessCooldown(int i) { return getConfig().getLong("blessing.powers." + BLESS_IDS[i] + ".cooldown", BLESS_CD[i]); }

    double blessDamage(int i) { return getConfig().getDouble("blessing.powers." + BLESS_IDS[i] + ".damage", BLESS_DMG[i]); }

    ItemStack blessItem(String kind) {
        boolean saw = kind.equals("saw");
        Material base = saw ? Material.matchMaterial(getConfig().getString("blessing.weapon-material", "DIAMOND_SWORD")) : Material.BOOK;
        if (base == null) base = Material.DIAMOND_SWORD;
        ItemStack it = new ItemStack(base);
        ItemMeta mt = it.getItemMeta();
        if (saw) {
            mt.displayName(plain("&d&lBlessing Saw"));
            mt.lore(List.of(plain("&7A weapon blessed with power"), plain(""),
                    plain("&eRight-click &7- cast your selected power"),
                    plain("&eSneak + right-click &7- switch power"),
                    plain("&7Choose powers with the &dBook of Powers")));
            mt.setUnbreakable(true);
            mt.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_UNBREAKABLE, org.bukkit.inventory.ItemFlag.HIDE_ATTRIBUTES);
        } else {
            mt.displayName(plain("&5&lBook of Powers"));
            mt.lore(List.of(plain("&7Contains 5 powers"), plain(""), plain("&eRight-click &7- choose your power")));
        }
        if (getConfig().getBoolean("blessing.use-model", false)) {
            NamespacedKey mk = NamespacedKey.fromString(saw ? getConfig().getString("blessing.saw-model", "ghost:ghostblade") : "donutsmp:power_book");
            if (mk != null) mt.setItemModel(mk);
        }
        mt.getPersistentDataContainer().set(bkey(), PersistentDataType.STRING, kind);
        it.setItemMeta(mt);
        return it;
    }

    void openBlessBook(Player p) {
        Gui g = new Gui("blessbook");
        g.inv = Bukkit.createInventory(g, 27, c("&8&lBook of Powers"));
        int sel = blessSel(p.getUniqueId());
        for (int i = 0; i < BLESS_IDS.length; i++) {
            ItemStack it = new ItemStack(BLESS_ICONS[i]);
            ItemMeta mt = it.getItemMeta();
            mt.displayName(plain(BLESS_NAMES[i]));
            mt.lore(List.of(plain("&7" + BLESS_DESC[i]), plain(""),
                    plain("&7Damage: &f" + fmt(blessDamage(i)) + " &7| Cooldown: &f" + blessCooldown(i) + "s"), plain(""),
                    plain(i == sel ? "&a✔ Selected" : "&eClick to select")));
            mt.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ATTRIBUTES);
            if (i == sel) mt.setEnchantmentGlintOverride(true);
            it.setItemMeta(mt);
            g.inv.setItem(BLESS_SLOTS[i], it);
        }
        p.openInventory(g.inv);
    }

    void blessSelect(Player p, int idx) {
        data.set("blessing." + p.getUniqueId(), idx);
        p.sendActionBar(plain("&dPower: " + BLESS_NAMES[idx]));
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.3f);
    }

    // NOT ignoreCancelled: Bukkit reports every right-click on AIR as "cancelled", which is why the power only worked when aiming at a block
    @EventHandler
    public void onBlessUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        String kind = blessKind(e.getItem());
        if (kind == null) return;
        if (e.getClickedBlock() != null && e.isCancelled()) return;   // a block click that protection/another plugin denied
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (kind.equals("book")) { openBlessBook(p); return; }
        if (p.isSneaking()) {
            int next = (blessSel(p.getUniqueId()) + 1) % BLESS_IDS.length;
            blessSelect(p, next);
            return;
        }
        castBless(p);
    }

    void castBless(Player p) {
        UUID id = p.getUniqueId();
        int idx = blessSel(id);
        long[] cd = blessCd.computeIfAbsent(id, k -> new long[BLESS_IDS.length]);
        long now = System.currentTimeMillis();
        if (cd[idx] > now) {
            p.sendActionBar(Component.text(w("Cooldown " + ((cd[idx] - now + 999) / 1000) + "s"), NamedTextColor.RED));
            return;
        }
        cd[idx] = now + blessCooldown(idx) * 1000;
        switch (idx) {
            case 0 -> blessAurora(p);
            case 1 -> blessVoid(p);
            case 2 -> blessBeam(p);
            case 3 -> blessWave(p);
            case 4 -> blessRush(p);
            default -> blessDomain(p);
        }
    }

    // ---- model effects (Display entities with the resource-pack models; only when blessing.use-model is true) ----
    boolean fxOn() { return getConfig().getBoolean("blessing.use-model", false); }

    org.bukkit.entity.ItemDisplay fx(Location l, String model, float sx, float sy, float sz, org.bukkit.entity.Display.Billboard bb) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta mt = it.getItemMeta();
        mt.setItemModel(new NamespacedKey("donutsmp", model));
        it.setItemMeta(mt);
        return l.getWorld().spawn(l, org.bukkit.entity.ItemDisplay.class, d -> {
            d.setItemStack(it);
            d.setBillboard(bb);
            d.setBrightness(new org.bukkit.entity.Display.Brightness(15, 15));   // full-bright = glows
            d.setViewRange(2.0f);
            d.setPersistent(false);
            d.setTransformation(new org.bukkit.util.Transformation(new org.joml.Vector3f(), new org.joml.AxisAngle4f(),
                    new org.joml.Vector3f(sx, sy, sz), new org.joml.AxisAngle4f()));
        });
    }

    // smoothly scale the effect to (sx,sy,sz) over `ticks`, then remove it after `life` ticks
    void fxAnim(org.bukkit.entity.ItemDisplay d, float sx, float sy, float sz, int ticks, int life) {
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!d.isValid()) return;
            d.setInterpolationDelay(0);
            d.setInterpolationDuration(ticks);
            d.setTransformation(new org.bukkit.util.Transformation(new org.joml.Vector3f(), new org.joml.AxisAngle4f(),
                    new org.joml.Vector3f(sx, sy, sz), new org.joml.AxisAngle4f()));
        }, 2L);
        Bukkit.getScheduler().runTaskLater(this, () -> { if (d.isValid()) d.remove(); }, life);
    }

    Location blessAim(Player p, double range) {
        Location eye = p.getEyeLocation();
        World w = p.getWorld();
        org.bukkit.util.Vector dir = eye.getDirection();
        RayTraceResult rt = w.rayTrace(eye, dir, range, FluidCollisionMode.NEVER, true, 0.3, en -> !en.equals(p));
        if (rt != null) {
            if (rt.getHitEntity() != null) return rt.getHitEntity().getLocation();
            return rt.getHitPosition().toLocation(w).subtract(dir.clone().multiply(0.3));
        }
        Location pt = eye.clone().add(dir.clone().multiply(range));   // aiming at the sky / far away
        RayTraceResult down = w.rayTraceBlocks(pt, new org.bukkit.util.Vector(0, -1, 0), 60, FluidCollisionMode.NEVER, true);
        return down != null ? down.getHitPosition().toLocation(w) : pt;
    }

    List<org.bukkit.entity.LivingEntity> blessTargets(Player p, Location c, double r) {
        List<org.bukkit.entity.LivingEntity> l = new ArrayList<>();
        for (Entity en : c.getWorld().getNearbyEntities(c, r, r, r)) {
            if (!(en instanceof org.bukkit.entity.LivingEntity le) || le.equals(p) || le.isDead() || le instanceof org.bukkit.entity.ArmorStand) continue;
            if (le instanceof Player pl && (pl.getGameMode() == GameMode.SPECTATOR || pl.getGameMode() == GameMode.CREATIVE)) continue;
            l.add(le);
        }
        return l;
    }

    void dust(Location l, int r, int g, int b, float size, int count, double spread) {
        l.getWorld().spawnParticle(Particle.DUST, l, count, spread, spread, spread, 0, new Particle.DustOptions(Color.fromRGB(r, g, b), size));
    }

    // 1) Aurora Burst: cyan/white flash that expands where you aim
    void blessAurora(Player p) {
        Location at = blessAim(p, 24);
        World w = at.getWorld();
        w.playSound(at, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 1.5f);
        w.playSound(at, Sound.BLOCK_BEACON_ACTIVATE, 1.5f, 1.8f);
        if (fxOn()) {
            fxAnim(fx(at.clone().add(0, 1, 0), "fx_orb", 1f, 1f, 1f, org.bukkit.entity.Display.Billboard.CENTER), 15f, 15f, 15f, 8, 22);
            fxAnim(fx(at.clone().add(0, 0.05, 0), "fx_ring_cyan", 2f, 1f, 2f, org.bukkit.entity.Display.Billboard.FIXED), 14f, 1f, 14f, 8, 22);
        }
        final double dmg = blessDamage(0);
        final int[] step = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            step[0]++;
            double r = step[0] * 0.8;
            java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();
            for (int i = 0; i < 70; i++) {
                double th = rnd.nextDouble(Math.PI * 2), ph = Math.acos(rnd.nextDouble(-1, 1));
                Location q = at.clone().add(r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph) * 0.7 + 1, r * Math.sin(ph) * Math.sin(th));
                if (i % 2 == 0) dust(q, 60 + rnd.nextInt(60), 220, 255, 1.6f, 1, 0.05);
                else w.spawnParticle(Particle.END_ROD, q, 1, 0, 0, 0, 0.02);
            }
            if (step[0] == 2) {
                for (org.bukkit.entity.LivingEntity t : blessTargets(p, at, 6)) {
                    t.damage(dmg, p);
                    t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 50, 0));
                    t.setVelocity(t.getLocation().toVector().subtract(at.toVector()).setY(0.5).normalize().multiply(0.9).setY(0.6));
                }
            }
            if (step[0] >= 9) task.cancel();
        }, 0L, 2L);
    }

    // 2) Void Lightning: purple lightning where you aim
    void blessVoid(Player p) {
        Location at = blessAim(p, 40);
        World w = at.getWorld();
        w.strikeLightningEffect(at);
        w.playSound(at, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2.0f, 1.2f);
        if (fxOn()) {
            fxAnim(fx(at.clone().add(0, 9, 0), "fx_bolt", 3f, 18f, 1f, org.bukkit.entity.Display.Billboard.VERTICAL), 0.6f, 18f, 1f, 10, 14);
            fxAnim(fx(at.clone().add(0, 0.05, 0), "fx_ring_magenta", 1f, 1f, 1f, org.bukkit.entity.Display.Billboard.FIXED), 9f, 1f, 9f, 6, 14);
        }
        final double dmg = blessDamage(1);
        for (int y = 0; y < 18; y++) {
            Location q = at.clone().add(0, y, 0);
            dust(q, 170, 40, 255, 1.8f, 4, 0.15);
            w.spawnParticle(Particle.ELECTRIC_SPARK, q, 2, 0.2, 0.2, 0.2, 0.1);
        }
        w.spawnParticle(Particle.EXPLOSION_EMITTER, at, 1);
        dust(at, 255, 60, 255, 2.2f, 60, 1.6);
        for (org.bukkit.entity.LivingEntity t : blessTargets(p, at, 4)) {
            t.damage(dmg, p);
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
        }
    }

    // 3) Solar Beam: orange piercing beam
    void blessBeam(Player p) {
        Location eye = p.getEyeLocation().subtract(0, 0.3, 0);
        org.bukkit.util.Vector dir = eye.getDirection().normalize();
        World w = eye.getWorld();
        w.playSound(eye, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.8f);
        w.playSound(eye, Sound.ITEM_TRIDENT_THUNDER, 1.5f, 0.6f);
        final double dmg = blessDamage(2);
        Set<UUID> hit = new HashSet<>();
        double endD = 30;
        for (double d = 1; d <= 30; d += 0.5) {
            Location q = eye.clone().add(dir.clone().multiply(d));
            if (q.getBlock().getType().isSolid()) { w.spawnParticle(Particle.EXPLOSION_EMITTER, q, 1); endD = d; break; }
            dust(q, 255, 140, 0, 2.0f, 3, 0.12);
            w.spawnParticle(Particle.FLAME, q, 2, 0.1, 0.1, 0.1, 0.01);
            for (org.bukkit.entity.LivingEntity t : blessTargets(p, q, 1.6)) {
                if (hit.add(t.getUniqueId())) { t.damage(dmg, p); t.setFireTicks(60); t.setVelocity(dir.clone().multiply(0.8).setY(0.3)); }
            }
        }
        if (fxOn()) {
            Location mid = eye.clone().add(dir.clone().multiply(endD / 2));
            mid.setDirection(dir);
            fxAnim(fx(mid, "fx_beam", 1.8f, 1.8f, (float) endD, org.bukkit.entity.Display.Billboard.FIXED), 0.2f, 0.2f, (float) endD, 8, 10);
        }
    }

    // 4) Pixel Shockwave: magenta ring expanding from you
    void blessWave(Player p) {
        Location c = p.getLocation().add(0, 0.2, 0);
        World w = c.getWorld();
        w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.6f);
        w.playSound(c, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 2.0f, 0.5f);
        if (fxOn())
            fxAnim(fx(c.clone().add(0, 0.05, 0), "fx_ring_magenta", 2f, 1f, 2f, org.bukkit.entity.Display.Billboard.FIXED), 28f, 1f, 28f, 12, 16);
        final double dmg = blessDamage(3);
        Set<UUID> hit = new HashSet<>();
        final double[] r = {1};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            r[0] += 1.0;
            int pts = (int) (r[0] * 10);
            for (int i = 0; i < pts; i++) {
                double ang = 2 * Math.PI * i / pts;
                Location q = c.clone().add(Math.cos(ang) * r[0], 0, Math.sin(ang) * r[0]);
                dust(q, 255, 0, 255, 1.7f, 1, 0.05);
                if (i % 3 == 0) dust(q.clone().add(0, 0.6, 0), 90, 0, 140, 1.5f, 1, 0.1);
            }
            for (org.bukkit.entity.LivingEntity t : blessTargets(p, c, r[0] + 1)) {
                double d = t.getLocation().distance(c);
                if (d >= r[0] - 1.6 && d <= r[0] + 0.6 && hit.add(t.getUniqueId())) {
                    t.damage(dmg, p);
                    t.setVelocity(t.getLocation().toVector().subtract(c.toVector()).setY(0).normalize().multiply(1.1).setY(0.45));
                }
            }
            if (r[0] >= 13) task.cancel();
        }, 0L, 1L);
    }

    // 5) Crimson Rush: dash forward and slash
    void blessRush(Player p) {
        org.bukkit.util.Vector dir = p.getEyeLocation().getDirection().normalize();
        if (dir.getY() < -0.25) dir.setY(-0.25).normalize();   // do not dig into the floor
        World w = p.getWorld();
        w.playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.6f);
        w.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.2f, 1.6f);
        p.setVelocity(dir.multiply(2.0));
        final double dmg = blessDamage(4);
        Set<UUID> hit = new HashSet<>();
        final int[] t0 = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!p.isOnline() || t0[0]++ >= 7) { task.cancel(); return; }
            Location c = p.getLocation().add(0, 1, 0);
            if (fxOn())
                fxAnim(fx(c, "fx_cross", 1.4f, 1.4f, 1.4f, org.bukkit.entity.Display.Billboard.CENTER), 0.1f, 0.1f, 0.1f, 8, 10);
            for (int i = 0; i < 4; i++) {   // red "+" crosses trailing behind
                Location q = c.clone().add((Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.2);
                dust(q, 255, 20, 80, 1.8f, 1, 0);
                dust(q.clone().add(0.25, 0, 0), 20, 0, 10, 1.4f, 1, 0);
                dust(q.clone().add(-0.25, 0, 0), 20, 0, 10, 1.4f, 1, 0);
                dust(q.clone().add(0, 0.25, 0), 255, 20, 80, 1.4f, 1, 0);
                dust(q.clone().add(0, -0.25, 0), 255, 20, 80, 1.4f, 1, 0);
            }
            w.spawnParticle(Particle.SWEEP_ATTACK, c, 2, 0.6, 0.3, 0.6, 0);
            for (org.bukkit.entity.LivingEntity t : blessTargets(p, c, 2.6)) {
                if (hit.add(t.getUniqueId())) { t.damage(dmg, p); w.spawnParticle(Particle.CRIT, t.getLocation().add(0, 1, 0), 20, 0.3, 0.4, 0.3, 0.3); }
            }
        }, 0L, 1L);
    }


    // smoothly scale an effect (no automatic removal)
    void fxScale(org.bukkit.entity.ItemDisplay d, float sx, float sy, float sz, int ticks) {
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!d.isValid()) return;
            d.setInterpolationDelay(0);
            d.setInterpolationDuration(ticks);
            d.setTransformation(new org.bukkit.util.Transformation(new org.joml.Vector3f(), new org.joml.AxisAngle4f(),
                    new org.joml.Vector3f(sx, sy, sz), new org.joml.AxisAngle4f()));
        }, 2L);
    }

    // ---- Crimson Domain particle layer (like the clip): cyan ice dome + sparkles -> explosive ring -> dome, vortex, lightning ----
    int[] domainRgb() {
        String s = getConfig().getString("blessing.domain.color", "red").trim().toLowerCase(Locale.ROOT);
        switch (s) {
            case "cyan": case "aurora": return new int[]{90, 230, 255};
            case "purple": case "void": return new int[]{170, 60, 255};
            case "orange": case "gold": case "solar": return new int[]{255, 150, 30};
            case "pink": case "pixel": return new int[]{255, 90, 200};
            case "red": case "crimson": return new int[]{255, 25, 35};
            default:
                try {
                    int v = Integer.parseInt(s.replace("#", ""), 16);
                    return new int[]{(v >> 16) & 255, (v >> 8) & 255, v & 255};
                } catch (NumberFormatException ex) {
                    return new int[]{255, 25, 35};
                }
        }
    }

    BlockData domainDebris(int[] rgb) {
        Material[] mats = {Material.RED_CONCRETE, Material.CYAN_CONCRETE, Material.PURPLE_CONCRETE, Material.ORANGE_CONCRETE, Material.PINK_CONCRETE};
        int[][] cols = {{255, 25, 35}, {90, 230, 255}, {170, 60, 255}, {255, 150, 30}, {255, 90, 200}};
        int best = 0;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < cols.length; i++) {
            double dd = Math.pow(rgb[0] - cols[i][0], 2) + Math.pow(rgb[1] - cols[i][1], 2) + Math.pow(rgb[2] - cols[i][2], 2);
            if (dd < bd) { bd = dd; best = i; }
        }
        return mats[best].createBlockData();
    }

    static int[] mixRgb(int[] a, int[] b, double k) {
        return new int[]{(int) (a[0] + (b[0] - a[0]) * k), (int) (a[1] + (b[1] - a[1]) * k), (int) (a[2] + (b[2] - a[2]) * k)};
    }

    // phase 1 (the warning): a pale cyan ice dome grows around you with sparkling arcs
    void domainWarnFx(Location c, int t, int warn, double warnW) {
        World w = c.getWorld();
        java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();
        double k = Math.min(1.0, t / (double) warn);
        double dr = k * (warnW / 2) * 0.9;
        if (t % 2 == 0) {
            for (int i = 0; i < 45; i++) {   // the bubble
                double a = rnd.nextDouble(Math.PI * 2), el = Math.asin(rnd.nextDouble());
                dust(c.clone().add(Math.cos(a) * Math.cos(el) * dr, Math.sin(el) * dr, Math.sin(a) * Math.cos(el) * dr), 120, 235, 255, 1.2f, 1, 0.02);
            }
            for (int i = 0; i < 24; i++) {   // ice shards along the rim
                double a = 2 * Math.PI * i / 24 + t * 0.03;
                w.spawnParticle(Particle.SNOWFLAKE, c.clone().add(Math.cos(a) * dr, 0.2, Math.sin(a) * dr), 1, 0.05, 0.15, 0.05, 0.01);
            }
        }
        for (int i = 0; i < 2; i++) {   // sparkle arcs spiralling up
            double a = t * 0.35 + i * Math.PI, rad = 1.5 + k * (warnW / 2) * 0.7;
            w.spawnParticle(Particle.END_ROD, c.clone().add(Math.cos(a) * rad, k * 5, Math.sin(a) * rad), 1, 0, 0, 0, 0);
        }
    }

    // the burst (once): flash, debris, sonic boom
    void domainBurstFx(Location c, int[] rgb) {
        World w = c.getWorld();
        w.spawnParticle(Particle.SONIC_BOOM, c.clone().add(0, 1, 0), 1, 0, 0, 0, 0);
        w.spawnParticle(Particle.BLOCK, c.clone().add(0, 0.5, 0), 70, 2.5, 0.6, 2.5, 0.35, domainDebris(rgb));   // pixel debris like the clip
        dust(c.clone().add(0, 1, 0), 255, 255, 255, 2.4f, 40, 1.5);                                             // white flash core
    }

    // phase 2, every tick: shock ring(s), dome, vortex, lightning, sparkle arcs
    void domainLoopFx(Location c, int k2, int[] rgb, double r) {
        World w = c.getWorld();
        java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();
        int[] light = mixRgb(rgb, new int[]{255, 255, 255}, 0.55);
        int[] dark = mixRgb(rgb, new int[]{0, 0, 0}, 0.55);
        // 1) the explosive rings: fast, ease-out, thick, with a wall of particles
        if (k2 >= 1 && k2 <= 14) {
            double e = 1 - Math.pow(1 - k2 / 14.0, 3);
            double rr = r * 1.2 * e;
            int pts = (int) Math.max(60, rr * 9);
            for (int i = 0; i < pts; i++) {
                double a = 2 * Math.PI * i / pts;
                double cx = Math.cos(a), sz = Math.sin(a);
                dust(c.clone().add(cx * rr, 0.2, sz * rr), rgb[0], rgb[1], rgb[2], 2.4f, 1, 0.02);
                if (k2 <= 8 && i % 2 == 0) {
                    dust(c.clone().add(cx * rr, 1.0, sz * rr), light[0], light[1], light[2], 1.8f, 1, 0.05);
                    dust(c.clone().add(cx * rr * 0.82, 0.3, sz * rr * 0.82), light[0], light[1], light[2], 1.6f, 1, 0.02);
                }
            }
        }
        // 2) the dome shell grows to full size in 10 ticks, then shimmers
        if (k2 % 2 == 0) {
            double dr = r * Math.min(1.0, k2 / 10.0);
            for (int i = 0; i < 60; i++) {
                double a = rnd.nextDouble(Math.PI * 2), el = Math.asin(rnd.nextDouble());
                int[] cc = rnd.nextInt(4) == 0 ? light : rgb;
                dust(c.clone().add(Math.cos(a) * Math.cos(el) * dr, Math.sin(el) * dr, Math.sin(a) * Math.cos(el) * dr), cc[0], cc[1], cc[2], 1.6f, 1, 0.02);
            }
            // 3) the whirling vortex on the ground: four dark spiral arms
            for (int j = 0; j < 4; j++)
                for (int s = 1; s <= 12; s++) {
                    double rad = r * s / 12.0;
                    double a = k2 * 0.12 + j * Math.PI / 2 + rad * 0.35;
                    dust(c.clone().add(Math.cos(a) * rad, 0.15, Math.sin(a) * rad), dark[0], dark[1], dark[2], 1.7f, 1, 0.03);
                }
        }
        // 4) white lightning strikes around the rim (visual only, no damage or fire)
        if (k2 % 10 == 3 && getConfig().getBoolean("blessing.domain.lightning", true)) {
            double a = rnd.nextDouble(Math.PI * 2), d = r * (0.4 + rnd.nextDouble(0.6));
            w.strikeLightningEffect(c.clone().add(Math.cos(a) * d, 0, Math.sin(a) * d));
        }
        // 5) cyan sparkle arcs and drifting pixel debris
        for (int i = 0; i < 2; i++) {
            double a = k2 * 0.25 + i * Math.PI, rad = r * 0.8;
            w.spawnParticle(Particle.END_ROD, c.clone().add(Math.cos(a) * rad, (k2 * 0.15) % 6, Math.sin(a) * rad), 1, 0, 0, 0, 0);
            w.spawnParticle(Particle.SNOWFLAKE, c.clone().add(Math.cos(a + 0.4) * rad, (k2 * 0.15) % 6 + 0.4, Math.sin(a + 0.4) * rad), 1, 0.1, 0.1, 0.1, 0.01);
        }
        if (k2 % 4 == 0) {
            double a = rnd.nextDouble(Math.PI * 2), d = rnd.nextDouble(r);
            w.spawnParticle(Particle.BLOCK, c.clone().add(Math.cos(a) * d, 0.3, Math.sin(a) * d), 6, 0.4, 0.2, 0.4, 0.25, domainDebris(rgb));
        }
    }

    // 6) Crimson Domain, two phases, both centred on YOU (they follow you, they are not aimed):
    //    phase 1 = a red gradient floor (17 blocks wide, 2 s) that shrinks away,
    //    phase 2 = it BURSTS into a red dome with whirling claws + red lightning that hurts and slows everything inside.
    void blessDomain(Player p) {
        final double r = getConfig().getDouble("blessing.domain.radius", 12);
        final int warn = getConfig().getInt("blessing.domain.warning-seconds", 2) * 20;
        final double warnW = getConfig().getDouble("blessing.domain.warning-width", 17);
        final boolean square = "square".equalsIgnoreCase(getConfig().getString("blessing.domain.warning-shape", "circle"));
        final int dur = getConfig().getInt("blessing.domain.seconds", 6) * 20;
        final double dmg = blessDamage(5);
        final int[] rgb = domainRgb();
        final boolean models = fxOn() && rgb[0] > 200 && rgb[1] < 80 && rgb[2] < 80;   // the pack models are red, other colours use particles only
        World w = p.getWorld();
        w.playSound(p.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1.5f, 0.7f);
        final org.bukkit.entity.ItemDisplay[] warnD = {null}, disc = {null}, dome = {null};
        final List<org.bukkit.entity.ItemDisplay> claws = new ArrayList<>();
        final Set<UUID> inside = new HashSet<>();
        final int[] t = {0};
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!p.isOnline() || p.isDead() || t[0] >= warn + dur) {
                if (warnD[0] != null) warnD[0].remove();
                if (disc[0] != null) disc[0].remove();
                if (dome[0] != null) dome[0].remove();
                claws.forEach(org.bukkit.entity.Entity::remove);
                if (p.isOnline() && t[0] >= warn) p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1.5f, 0.5f);
                task.cancel();
                return;
            }
            t[0]++;
            Location c = p.getLocation();
            World cw = c.getWorld();
            java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();

            // ---------------- phase 1: red gradient floor ----------------
            if (t[0] < warn) {
                if (models) {
                    Location gl = c.clone().add(0, 0.05, 0);
                    gl.setYaw(0); gl.setPitch(0);
                    if (warnD[0] == null) {
                        warnD[0] = fx(gl, square ? "fx_warn_square" : "fx_warn_disc", 1f, 1f, 1f, org.bukkit.entity.Display.Billboard.FIXED);
                        warnD[0].setTeleportDuration(2);
                        fxScale(warnD[0], (float) warnW, 1f, (float) warnW, 6);
                    } else {
                        warnD[0].teleport(gl);
                        if (t[0] == warn - 4) fxScale(warnD[0], 0.1f, 1f, 0.1f, 4);   // vanishes just before the burst
                    }
                } else if (t[0] % 2 == 0) {   // no models: gradient made of dust, dark in the middle -> bright at the rim
                    for (int i = 0; i < 70; i++) {
                        double a = rnd.nextDouble(Math.PI * 2), d = Math.sqrt(rnd.nextDouble()) * warnW / 2;
                        double k = d / (warnW / 2);
                        dust(c.clone().add(Math.cos(a) * d, 0.1, Math.sin(a) * d), (int) (rgb[0] * (0.25 + 0.75 * k)), (int) (rgb[1] * (0.25 + 0.75 * k)), (int) (rgb[2] * (0.25 + 0.75 * k)), 1.4f, 1, 0.02);
                    }
                }
                domainWarnFx(c, t[0], warn, warnW);
                if (t[0] % 10 == 0) cw.playSound(c, Sound.ENTITY_WARDEN_HEARTBEAT, 1.2f, 0.7f + t[0] * 0.01f);
                return;
            }

            // ---------------- the burst (once) ----------------
            if (t[0] == warn) {
                if (warnD[0] != null) { warnD[0].remove(); warnD[0] = null; }
                cw.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.6f);
                cw.playSound(c, Sound.ENTITY_WITHER_SPAWN, 1.2f, 0.6f);
                cw.playSound(c, Sound.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.5f);
                cw.spawnParticle(Particle.EXPLOSION_EMITTER, c.clone().add(0, 1, 0), 3, 1.5, 0.5, 1.5, 0);
                dust(c.clone().add(0, 1, 0), rgb[0], rgb[1], rgb[2], 2.4f, 120, 3.0);
                domainBurstFx(c, rgb);
                for (org.bukkit.entity.LivingEntity e : blessTargets(p, c, r)) {
                    if (e.getLocation().distance(c) > r) continue;
                    e.damage(dmg * 2, p);
                    e.setVelocity(e.getLocation().toVector().subtract(c.toVector()).setY(0).normalize().multiply(1.0).setY(0.5));
                }
                if (models) {
                    Location base = c.clone().add(0, 0.05, 0);
                    base.setYaw(0); base.setPitch(0);
                    disc[0] = fx(base, "fx_domain_disc", 2f, 1f, 2f, org.bukkit.entity.Display.Billboard.FIXED);
                    dome[0] = fx(base, "fx_domain_dome", 2f, 2f, 2f, org.bukkit.entity.Display.Billboard.FIXED);
                    fxScale(disc[0], (float) (2 * r), 1f, (float) (2 * r), 8);     // quick = explosive
                    fxScale(dome[0], (float) (2 * r), (float) (2 * r), (float) (2 * r), 8);
                    disc[0].setTeleportDuration(2);
                    dome[0].setTeleportDuration(2);
                    for (int i = 0; i < 6; i++) {
                        org.bukkit.entity.ItemDisplay cl = fx(base, "fx_tendril", 7f, 7f, 7f, org.bukkit.entity.Display.Billboard.FIXED);
                        cl.setTeleportDuration(2);
                        claws.add(cl);
                    }
                }
                return;
            }

            // ---------------- phase 2: the dome ----------------
            final int k2 = t[0] - warn;
            domainLoopFx(c, k2, rgb, r);
            if (models) {   // everything stays glued to the player
                Location gl = c.clone().add(0, 0.05, 0);
                gl.setYaw(0); gl.setPitch(0);
                disc[0].teleport(gl);
                dome[0].teleport(gl);
                for (int i = 0; i < claws.size(); i++) {
                    double ang = k2 * 0.13 + i * 2 * Math.PI / claws.size();
                    double rad = r * 0.55 + Math.sin(k2 * 0.09 + i) * r * 0.2;
                    Location cl = c.clone().add(Math.cos(ang) * rad, 2.2 + Math.sin(k2 * 0.15 + i) * 1.2, Math.sin(ang) * rad);
                    cl.setYaw((float) Math.toDegrees(ang) + 90f);
                    cl.setPitch(0);
                    claws.get(i).teleport(cl);
                }
                if (k2 % 6 == 0) {   // red lightning inside the dome
                    double a = rnd.nextDouble(Math.PI * 2), d = rnd.nextDouble(r * 0.8);
                    Location bl = c.clone().add(Math.cos(a) * d, r * 0.5, Math.sin(a) * d);
                    fxAnim(fx(bl, "fx_bolt_red", 2.5f, (float) r, 1f, org.bukkit.entity.Display.Billboard.VERTICAL), 0.4f, (float) r, 1f, 4, 7);
                }
            }
            if (k2 % 2 == 0) {   // particles: red rim on the ground + drifting red specks
                int pts = (int) Math.max(40, r * 4);
                for (int i = 0; i < pts; i++) {
                    double ang = 2 * Math.PI * i / pts + k2 * 0.02;
                    dust(c.clone().add(Math.cos(ang) * r, 0.2, Math.sin(ang) * r), rgb[0], rgb[1], rgb[2], 1.6f, 1, 0.02);
                }
                for (int i = 0; i < 14; i++) {
                    double a = rnd.nextDouble(Math.PI * 2), d = rnd.nextDouble(r);
                    dust(c.clone().add(Math.cos(a) * d, rnd.nextDouble(0.2, 4), Math.sin(a) * d), rgb[0] * 140 / 255, rgb[1] * 140 / 255, rgb[2] * 140 / 255, 1.3f, 1, 0.1);
                }
            }
            if (k2 % 40 == 1) cw.playSound(c, Sound.ENTITY_WITHER_AMBIENT, 0.8f, 0.5f);
            if (k2 % 10 == 0) {   // pulse: damage + slow everything inside
                for (org.bukkit.entity.LivingEntity e : blessTargets(p, c, r)) {
                    if (e.getLocation().distance(c) > r) continue;
                    e.damage(dmg, p);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, 1));
                    cw.spawnParticle(Particle.CRIT, e.getLocation().add(0, 1, 0), 8, 0.3, 0.5, 0.3, 0.2);
                    if (inside.add(e.getUniqueId())) cw.playSound(e.getLocation(), Sound.ENTITY_WITHER_HURT, 0.6f, 0.6f);
                }
            }
        }, 0L, 1L);
    }

    // ---- resource pack: sent AFTER the player is in the game (optional: the player can accept or decline) ----
    void sendBlessPack(Player p) {
        String url = getConfig().getString("blessing.resource-pack.url", "");
        String sha = getConfig().getString("blessing.resource-pack.sha1", "");
        if (url == null || url.isEmpty()) return;
        byte[] hash = null;
        if (sha != null && sha.length() == 40) {
            try { hash = java.util.HexFormat.of().parseHex(sha); } catch (Exception ignored) { }
        }
        UUID packId = UUID.nameUUIDFromBytes(url.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        p.setResourcePack(packId, url, hash, Component.text("Accept to see the Blessing Saw and power effects"), false);
    }

    @EventHandler
    public void onBlessPackJoin(org.bukkit.event.player.PlayerJoinEvent e) {
        if (!getConfig().getBoolean("blessing.resource-pack.enabled", false)) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> { if (p.isOnline()) sendBlessPack(p); }, 60L);
    }

    void blessCmd(Player p, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("pack")) { sendBlessPack(p); return; }   // anyone: ask for the pack again
        if (!isStaff(p)) { msg(p, "&cYou do not have permission"); return; }
        if (a.length >= 3 && a[0].equalsIgnoreCase("give")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { msg(p, "&cPlayer offline"); return; }
            String k = a[2].toLowerCase(Locale.ROOT);
            if (k.equals("saw") || k.equals("all")) give(t, blessItem("saw"));
            if (k.equals("book") || k.equals("all")) give(t, blessItem("book"));
            if (!List.of("saw", "book", "all").contains(k)) { msg(p, "&e/bless give <player> <saw|book|all>"); return; }
            msg(p, "&aGave " + k + " to " + t.getName());
            return;
        }
        msg(p, "&e/bless give <player> <saw|book|all>");
    }
}
